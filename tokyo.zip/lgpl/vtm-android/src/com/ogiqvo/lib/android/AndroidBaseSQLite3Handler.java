package com.ogiqvo.lib.android;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.oscim.android.AndroidAssets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by xor on 15/11/30.
 */
public class AndroidBaseSQLite3Handler {
    static final Logger log = LoggerFactory.getLogger(AndroidBaseSQLite3Handler.class);
    protected SQLiteDatabase dbh;

    public AndroidBaseSQLite3Handler(Context context, String inPathPrefix, String outPathDir, String outPathFileName) {
        File dirPath = context.getDir(outPathDir, 0);
        File extractedDbPath = new File(dirPath, outPathFileName);
//        if (extractedDbPath.exists()) {
//            extractedDbPath.delete();
//        }

        if (!extractedDbPath.exists()) {
            joinChunksAndSave(extractedDbPath, inPathPrefix);
            log.info("Extracted files in " + inPathPrefix + " to " + extractedDbPath.getAbsolutePath());
        } else {
            log.info("Extracted file " + extractedDbPath.getAbsolutePath() + " exists with size " + extractedDbPath.length());
        }
        File journalDbPath = new File(dirPath, outPathFileName+"-journal");
        if (journalDbPath.exists()) {
            journalDbPath.delete();
        }

        SQLiteOpenHelper openHelper = new SQLiteOpenHelper(context, extractedDbPath.getAbsolutePath(), null, 1) {
            @Override
            public void onCreate(SQLiteDatabase sqLiteDatabase) {

            }

            @Override
            public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

            }
        };
        this.dbh = openHelper.getReadableDatabase();
    }

    private void joinChunksAndSave(File outFilePath, String inPathPrefix) {
        // http://stackoverflow.com/questions/2860157/load-files-bigger-than-1m-from-assets-folder
        try {
            OutputStream outstream = new FileOutputStream(outFilePath);
            outFilePath.createNewFile();
            byte[] b = new byte[1024];
            int i, r;
            for (i = 0; i < 676; i++) {
                int d0 = i / 26;
                int d1 = i % 26;
                String filePath = inPathPrefix + "/x" + Character.toString((char) (d0 + 97)) + Character.toString((char) (d1 + 97));

                log.debug("Appended {}", filePath);
                try {
                    InputStream is = AndroidAssets.readFileAsStream(filePath);
                    if (is == null) {
                        break;
                    }
                    while ((r = is.read(b)) != -1) {
                        outstream.write(b, 0, r);
                    }
                    is.close();
                } catch (FileNotFoundException e) {
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            outstream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
