package com.ogiqvo.lib.android;

import android.content.Context;
import android.database.Cursor;

import com.ogiqvo.lib.Cube;
import com.ogiqvo.lib.Tile;
import com.ogiqvo.lib.bean.Agency;
import com.ogiqvo.lib.bean.Calendar;
import com.ogiqvo.lib.bean.Carmodel;
import com.ogiqvo.lib.bean.Gradient;
import com.ogiqvo.lib.bean.Lnglat;
import com.ogiqvo.lib.loader.BezierCidAndT;
import com.ogiqvo.lib.loader.InputStreamLoader;
import com.ogiqvo.lib.loader.SQLite3Handler;
import com.ogiqvo.lib.pool.CommitCube;
import com.ogiqvo.lib.pool.CommitTile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import static com.ogiqvo.lib.loader.InputStreamLoader.StringRefEdgeInEdgeSet;

/**
 * Created by xor on 15/11/11.
 */
public class AndroidSQLite3Handler extends AndroidBaseSQLite3Handler implements SQLite3Handler {
    static final Logger log = LoggerFactory.getLogger(AndroidSQLite3Handler.class);

    // http://d.hatena.ne.jp/itog/20091228/1262016898
    public AndroidSQLite3Handler(Context context, String inPathPrefix, String outPathDir, String outPathFileName) {
        super(context, inPathPrefix, outPathDir, outPathFileName);
    }

    @Override
    public void addBezierCidsInTile(CommitTile tileId, Set<String> cids) {
        this.dbh.beginTransaction();
        try {
            int x = tileId.getTile().x;
            int y = -tileId.getTile().y - 1;
            // TODO: Temporary loading ALL beziers at once! You should let it load only the required beziers later!
//            Cursor cur = this.dbh.rawQuery("SELECT bezier_id FROM tiles_beziers WHERE x=? AND y=?",
//                    new String[]{String.valueOf(x), String.valueOf(y)});
            Cursor cur = this.dbh.rawQuery("SELECT bezier_id FROM beziers", new String[]{});
            try {
                if (cur.moveToFirst()) {
                    do {
                        String bezierCid = cur.getString(0);
                        cids.add(bezierCid);
                    } while (cur.moveToNext());
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    public int findMinTimechunkForTile(CommitTile tileId) {
        this.dbh.beginTransaction();
        try {
            int x = tileId.getTile().x;
            int y = -tileId.getTile().y - 1;
            Cursor cur = this.dbh.rawQuery("SELECT min_tc FROM cube_timechunk_ranges WHERE x=? AND y=?",
                    new String[]{String.valueOf(x), String.valueOf(y)});
            try {
                if (cur.moveToFirst()) {
                    return cur.getInt(0);
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
        return Integer.MAX_VALUE;
    }

    public int findMaxTimechunkForTile(CommitTile tileId) {
        this.dbh.beginTransaction();
        try {
            int x = tileId.getTile().x;
            int y = -tileId.getTile().y - 1;
            Cursor cur = this.dbh.rawQuery("SELECT max_tc FROM cube_timechunk_ranges WHERE x=? AND y=?",
                    new String[]{String.valueOf(x), String.valueOf(y)});
            try {
                if (cur.moveToFirst()) {
                    return cur.getInt(0);
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
        return Integer.MIN_VALUE;
    }

    @Override
    public void addInstructionCidsInCube(CommitCube cubeId, Set<String> cids) {
        Cube c = cubeId.getCube();
        Tile tile = cubeId.getCube().tile;
//        log.debug("Request waits in cube x={},y={},z={},t={}", new Object[]{tile.x, tile.y, tile.z, c.timechunk});
        int x = tile.x;
        int y = -tile.y - 1;
        int tc = cubeId.getCube().timechunk;
        this.dbh.beginTransaction();
        try {
            Cursor cur = this.dbh.rawQuery("SELECT instruction_id FROM cubes_instructions WHERE x=? AND y=? AND tc=?",
                    new String[]{String.valueOf(x), String.valueOf(y), String.valueOf(tc)});
            try {
                if (cur.moveToFirst()) {
                    do {
                        String instructionCid = cur.getString(0);
                        cids.add(instructionCid);
                    } while (cur.moveToNext());
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addWaitCidsInCube(CommitCube cubeId, Set<String> cids) {
        Cube c = cubeId.getCube();
        Tile tile = cubeId.getCube().tile;
//        log.debug("Request waits in cube x={},y={},z={},t={}", new Object[]{tile.x, tile.y, tile.z, c.timechunk});
        int x = tile.x;
        int y = -tile.y - 1;
        int tc = cubeId.getCube().timechunk;
        this.dbh.beginTransaction();
        try {
            Cursor cur = this.dbh.rawQuery("SELECT wait_id FROM cubes_waits WHERE x=? AND y=? AND tc=?",
                    new String[]{String.valueOf(x), String.valueOf(y), String.valueOf(tc)});
            try {
                if (cur.moveToFirst()) {
                    do {
                        String waitCid = cur.getString(0);
                        cids.add(waitCid);
                    } while (cur.moveToNext());
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public Collection<String> findAllBezierCids() {
        Collection<String> cids = new HashSet<>();
        this.dbh.beginTransaction();
        try {
            Cursor cur = this.dbh.rawQuery("SELECT bezier_id FROM beziers", new String[]{});
            try {
                if (cur.moveToFirst()) {
                    do {
                        String bezierCid = cur.getString(0);
                        cids.add(bezierCid);
                    } while (cur.moveToNext());
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
        return cids;
    }

    @Override
    public String findEdgeCidForBezierCid(String bezierCid) {
        log.debug("Find edge for bezier {}", new Object[]{ bezierCid});
        this.dbh.beginTransaction();
        try {
            Cursor cur = this.dbh.rawQuery("SELECT edge_id FROM beziers WHERE bezier_id=?", new String[]{bezierCid});
            try {
                if (cur.moveToFirst()) {
                    do {
                        String edgeCid = cur.getString(0);
                        log.debug("Found edge {} for bezier {}", new Object[]{ edgeCid,bezierCid});
                        return edgeCid;
                    } while (cur.moveToNext());
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
        return null;
    }

    @Override
    public Collection<String> findAllBezierCidsForEdgeCid(String edgeCid) {
        Collection<String> bezierCids = new HashSet<>();
        this.dbh.beginTransaction();
        try {
            Cursor cur = this.dbh.rawQuery("SELECT bezier_id FROM beziers WHERE edge_id=?", new String[]{edgeCid});
            try {
                if (cur.moveToFirst()) {
                    do {
                        String bezierCid = cur.getString(0);
                        bezierCids.add(bezierCid);
                    } while (cur.moveToNext());
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
        return bezierCids;
    }

    @Override
    public Collection<String> findAllInstructionCidsForEdgeCid(String edgeCid) {
        Collection<String> instructionCids = new HashSet<>();
        this.dbh.beginTransaction();
        try {
            Cursor cur = this.dbh.rawQuery("SELECT instruction_id FROM instructions_edges WHERE edge_id=?", new String[]{edgeCid});
            try {
                if (cur.moveToFirst()) {
                    do {
                        String instructionCid = cur.getString(0);
                        instructionCids.add(instructionCid);
                    } while (cur.moveToNext());
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
        return instructionCids;
    }

    @Override
    public Collection<String> findAllWaitCidsForEdgeCid(String edgeCid) {
        Collection<String> waitCids = new HashSet<>();
        this.dbh.beginTransaction();
        try {
            Cursor cur = this.dbh.rawQuery("SELECT wait_id FROM waits_edges WHERE edge_id=?", new String[]{edgeCid});
            try {
                if (cur.moveToFirst()) {
                    do {
                        String waitCid = cur.getString(0);
                        waitCids.add(waitCid);
                    } while (cur.moveToNext());
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
        return waitCids;
    }

    @Override
    public void addAgencies(Collection<String> cids, Map<String, Agency> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT agency_id,agency_name,agency_url,agency_timezone,agency_lang,agency_phone" +
                        " FROM agency WHERE agency_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Agency for ID=" + cid + " not found");
                    }
                    String agencyCid = cur.getString(0);
                    String agencyName = cur.getString(1);
                    String agencyUrl = cur.getString(2);
                    String agencyTimezone = cur.getString(3);
                    String agencyLang = cur.getString(4);
                    String agencyPhone = cur.getString(5);
                    TimeZone tz = TimeZone.getTimeZone(agencyTimezone);
                    Agency a = new Agency(agencyCid, agencyName, agencyUrl, tz, agencyLang, agencyPhone);
                    results.put(cid, a);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addBeziers(Collection<String> cids, Map<String, InputStreamLoader.StringRefBezier> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT bezier_id,gradient0_id,distance0,gradient3_id,distance3,edge_id,from_distance,to_distance,sign" +
                        " FROM beziers WHERE bezier_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Bezier for ID=" + cid + " not found");
                    }
                    String bezierCid = cur.getString(0);
                    String gradient0id = cur.getString(1);
                    double distance0 = cur.getDouble(2);
                    String gradient3id = cur.getString(3);
                    double distance3 = cur.getDouble(4);
                    String edgeId = cur.getString(5);
                    double fromDistance = cur.getDouble(6);
                    double toDistance = cur.getDouble(7);
                    int sgn = cur.getInt(8);
                    InputStreamLoader.StringRefBezier br = new InputStreamLoader.StringRefBezier(bezierCid, gradient0id, distance0, gradient3id, distance3, edgeId, fromDistance, toDistance, sgn > 0);
                    results.put(cid, br);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addCalendars(Collection<String> cids, Map<String, Calendar> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,start_date,end_date,name" +
                        " FROM calendar WHERE service_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Calendar for ID=" + cid + " not found");
                    }
                    String serviceCid = cur.getString(0);
                    boolean monday = cur.getInt(1) == 1;
                    boolean tuesday = cur.getInt(2) == 1;
                    boolean wednesday = cur.getInt(3) == 1;
                    boolean thursday = cur.getInt(4) == 1;
                    boolean friday = cur.getInt(5) == 1;
                    boolean saturday = cur.getInt(6) == 1;
                    boolean sunday = cur.getInt(7) == 1;
                    int startDate = cur.getInt(8);
                    int endDate = cur.getInt(9);
                    String name = cur.getString(10);

                    boolean[] weeklyCalendarRules = new boolean[]{sunday, monday, tuesday, wednesday, thursday, friday, saturday};
                    Map<Integer, Boolean> ex = new HashMap<>();

                    cur = this.dbh.rawQuery("SELECT service_id,date,exception_type" +
                            " FROM calendar_dates WHERE service_id=?", new String[]{cid});
                    if (cur.moveToFirst()) {
                        do {
                            int day1970 = cur.getInt(1);
                            int etype = cur.getInt(2);
                            ex.put(day1970, etype == 1);
                        } while (cur.moveToNext());
                    }
                    Calendar cr = new Calendar(serviceCid, weeklyCalendarRules, ex, startDate, endDate);
                    results.put(cid, cr);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addCars(Collection<String> cids, Map<String, InputStreamLoader.StringRefCar> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT car_id,car_name,carmodel_id" +
                        " FROM cars WHERE car_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Car for ID=" + cid + " not found");
                    }
                    String carCid = cur.getString(0);
                    String carName = cur.getString(1);
                    String carmodelId = cur.getString(2);
                    InputStreamLoader.StringRefCar cr = new InputStreamLoader.StringRefCar(carCid, carmodelId, carName);
                    results.put(cid, cr);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addCarmodels(Collection<String> cids, Map<String, Carmodel> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT carmodel_id,carmodel_name,carmodel_length,carmodel_width,carmodel_height,carmodel_wheelheight,carmodel_bogielengthdelta,carmodel_couplinglengthdelta,carmodel_3dmodel,carmodel_3dmodel_mime" +
                        " FROM carmodels WHERE carmodel_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Carmodel for ID=" + cid + " not found");
                    }
                    String carmodelCid = cur.getString(0);
                    String carmodelName = cur.getString(1);
                    double carmodelLength = cur.getDouble(2);
                    double carmodelWidth = cur.getDouble(3);
                    double carmodelHeight = cur.getDouble(4);
                    double carmodelWheelHeight = cur.getDouble(5);
                    double carmodelBogieLengthDelta = cur.getDouble(6);
                    double carmodelCouplingLengthDelta = cur.getDouble(7);
                    byte[] carmodel3dModel = cur.getBlob(8);
                    String carmodel3dModelMime = cur.getString(9);
                    Carmodel cm = new Carmodel(carmodelCid, carmodelName, carmodelLength, carmodelWidth, carmodelHeight, carmodelWheelHeight, carmodelBogieLengthDelta, carmodelCouplingLengthDelta, carmodel3dModel, carmodel3dModelMime);
                    results.put(cid, cm);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addFormations(Collection<String> cids, Map<String, InputStreamLoader.StringRefFormation> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                String formationCid = null;
                String explicitName = null;

                Cursor cur = this.dbh.rawQuery("SELECT formation_id,explicit_name" +
                        " FROM formations WHERE formation_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Formation for ID=" + cid + " not found");
                    }
                    formationCid = cur.getString(0);
                    explicitName = cur.getString(1);
                } finally {
                    cur.close();
                }

                List<String> carIds = new ArrayList<>();
                List<Boolean> direction1s = new ArrayList<>();
                List<String> labels = new ArrayList<>();

                cur = this.dbh.rawQuery("SELECT formation_id,sequence,car_id,direction,label" +
                        " FROM formations_cars WHERE formation_id=? ORDER BY sequence", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Car-in-formation for formation ID=" + cid + " not found");
                    }

                    do {
                        String carId = cur.getString(2);
                        boolean directionIs1 = cur.getInt(3) == 1;
                        String label = cur.getString(4);

                        carIds.add(carId);
                        direction1s.add(directionIs1);
                        labels.add(label);
                    } while (cur.moveToNext());

                    InputStreamLoader.StringRefFormation fr = new InputStreamLoader.StringRefFormation(formationCid, carIds, direction1s, labels, explicitName);
                    results.put(cid, fr);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addGradients(Collection<String> cids, Map<String, Gradient> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT gradient_id,gradient_lat,gradient_lon,gradient_altitude,gradient_bearing,gradient_slope,gradient_cant" +
                        " FROM gradients WHERE gradient_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Gradient for ID=" + cid + " not found");
                    }
                    String gradientCid = cur.getString(0);
                    double gradientLat = cur.getDouble(1);
                    double gradientLon = cur.getDouble(2);
                    double gradientAlt = cur.getDouble(3);
                    double gradientBearing = cur.getDouble(4);
                    double gradientSlope = cur.getDouble(5);
                    double gradientCant = cur.getDouble(6);
                    Lnglat ll = new Lnglat(gradientLon, gradientLat);
                    Gradient g = new Gradient(gradientCid, ll, gradientBearing, gradientAlt, gradientSlope, gradientCant);
                    results.put(cid, g);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addInstructions(Collection<String> cids, Map<String, InputStreamLoader.StringRefInstruction> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT instruction_id,trip_id,formation_id,first_car_distance,last_car_distance,flat_coeffs" +
                        " FROM instructions WHERE instruction_id=?", new String[]{cid});

                String instructionCid = null;
                String tripCid = null;
                String formationCid = null;
                double firstCarDistance = 0;
                double lastCarDistance = 0;
                String flatCoeffs = null;
                List<Double> flatCoeffsBoxed = null;
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Instruction for ID=" + cid + " not found");
                    }
                    instructionCid = cur.getString(0);
                    tripCid = cur.getString(1);
                    formationCid = cur.getString(2);
                    firstCarDistance = cur.getDouble(3);
                    lastCarDistance = cur.getDouble(4);
                    flatCoeffs = cur.getString(5);
                    String[] flatCoeffsSplitted = flatCoeffs.split(",");
                    flatCoeffsBoxed = new ArrayList<>(flatCoeffsSplitted.length);
                    for (int i = 0; i < flatCoeffsSplitted.length; i++) {
                        flatCoeffsBoxed.add(Double.parseDouble(flatCoeffsSplitted[i]));
                    }
                } finally {
                    cur.close();
                }

                List<StringRefEdgeInEdgeSet> eies = new ArrayList<>();
                cur = this.dbh.rawQuery("SELECT edge_id,from_distance,to_distance,sign" +
                        " FROM instructions_edges WHERE instruction_id=? ORDER BY seq", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Edge-in-instruction for instruction ID=" + cid + " not found");
                    }
                    do {
                        String edgeCid = cur.getString(0);
                        double fromDistance = cur.getDouble(1);
                        double toDistance = cur.getDouble(2);
                        int sgn = cur.getInt(3);
                        StringRefEdgeInEdgeSet eie = new StringRefEdgeInEdgeSet();
                        eie.edgeCid = edgeCid;
                        eie.fromDistance = fromDistance;
                        eie.toDistance = toDistance;
                        eie.sgn = sgn;
                        eies.add(eie);
                    } while (cur.moveToNext());
                } finally {
                    cur.close();
                }

                InputStreamLoader.StringRefInstruction ir = new InputStreamLoader.StringRefInstruction(instructionCid, formationCid, tripCid, firstCarDistance, lastCarDistance, eies, flatCoeffsBoxed);
                results.put(cid, ir);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addPlatforms(Collection<String> cids, Map<String, InputStreamLoader.StringRefPlatform> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT platform_id,platform_name,station_id" +
                        " FROM platforms WHERE platform_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Platform for ID=" + cid + " not found");
                    }
                    String platformCid = cur.getString(0);
                    String platformName = cur.getString(1);
                    String stationCid = cur.getString(2);

                    InputStreamLoader.StringRefPlatform pr = new InputStreamLoader.StringRefPlatform(platformCid, stationCid, platformName, null);
                    results.put(cid, pr);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addRoutes(Collection<String> cids, Map<String, InputStreamLoader.StringRefRoute> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT route_id,agency_id,route_short_name,route_long_name,route_desc,route_type,route_url,route_color,route_text_color" +
                        " FROM routes WHERE route_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Route for ID=" + cid + " not found");
                    }
                    String routeCid = cur.getString(0);
                    String agencyCid = cur.getString(1);
                    String routeShortName = cur.getString(2);
                    String routeLongName = cur.getString(3);
                    String routeDesc = cur.getString(4);
                    int routeType = cur.getInt(5);
                    String routeUrl = cur.getString(6);
                    String routeColor = cur.getString(7);
                    String routeTextColor = cur.getString(8);
                    if (routeColor != null && routeColor.equals("")) {
                        routeColor = null;
                    }
                    if (routeTextColor != null && routeTextColor.equals("")) {
                        routeTextColor = null;
                    }

                    InputStreamLoader.StringRefRoute rr = new InputStreamLoader.StringRefRoute(routeCid, agencyCid, routeShortName, routeLongName, routeDesc, routeUrl, routeColor, routeTextColor);
                    results.put(cid, rr);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addStations(Collection<String> cids, Map<String, InputStreamLoader.StringRefStation> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT station_id,station_code,station_name,station_desc,station_lat,station_lon,station_url,station_timezone" +
                        " FROM stations WHERE station_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Station for ID=" + cid + " not found");
                    }
                    String stationCid = cur.getString(0);
                    String stationCode = cur.getString(1);
                    String stationName = cur.getString(2);
                    String stationDesc = cur.getString(3);
                    double stationLat = cur.getDouble(4);
                    double stationLon = cur.getDouble(5);
                    String stationUrl = cur.getString(6);
                    String stationTimezone = cur.getString(7);
                    TimeZone tz = TimeZone.getTimeZone(stationTimezone);

                    InputStreamLoader.StringRefStation sr = new InputStreamLoader.StringRefStation(stationCid, stationCode, stationName, stationDesc, stationLat, stationLon, tz, stationUrl);
                    results.put(cid, sr);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addTrips(Collection<String> cids, Map<String, InputStreamLoader.StringRefTrip> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }
                Cursor cur = this.dbh.rawQuery("SELECT trip_id,explicit_name,route_id,service_id,trip_headsign,trip_short_name,direction_id,rank_name,rank_color,rank_text_color" +
                        " FROM trips WHERE trip_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Trip for ID=" + cid + " not found");
                    }
                    String tripCid = cur.getString(0);
                    String explicitName = cur.getString(1);
                    String routeCid = cur.getString(2);
                    String serviceCid = cur.getString(3);
                    String tripHeadsign = cur.getString(4);
                    String tripShortName = cur.getString(5);
                    boolean directionIs1 = cur.getInt(6) == 1;
                    String rankName = cur.getString(7);
                    String rankColor = cur.getString(8);
                    String rankTextColor = cur.getString(9);
                    if (rankColor != null && rankColor.equals("")) {
                        rankColor = null;
                    }
                    if (rankTextColor != null && rankTextColor.equals("")) {
                        rankTextColor = null;
                    }

                    InputStreamLoader.StringRefTrip tr = new InputStreamLoader.StringRefTrip(tripCid, explicitName, routeCid, serviceCid, tripHeadsign, tripShortName, directionIs1, rankName, rankColor, rankTextColor);
                    results.put(cid, tr);
                } finally {
                    cur.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }

    @Override
    public void addWaits(Collection<String> cids, Map<String, InputStreamLoader.StringRefWait> results) {
        this.dbh.beginTransaction();
        try {
            for (String cid : cids) {
                if (results.containsKey(cid)) {
                    continue;
                }

                String waitCid = null;
                String tripCid = null;
                String formationCid = null;
                String platformCid = null;
                double firstBogieDistance = 0;
                double firstCarDistance = 0;
                double lastCarDistance = 0;
                double fromUtcSeconds = 0;
                double toUtcSeconds = 0;
                boolean isServing = false;

                Cursor cur = this.dbh.rawQuery("SELECT w.wait_id,w.trip_id,w.formation_id,o.platform_id,w.first_bogie_distance,w.first_car_distance,w.last_car_distance,w.from_utc_seconds,w.to_utc_seconds,w.is_serving" +
                        " FROM waits w LEFT OUTER JOIN objectives o ON w.objective_id=o.objective_id WHERE w.wait_id=?", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Wait for ID=" + cid + " not found");
                    }
                    waitCid = cur.getString(0);
                    tripCid = cur.getString(1);
                    formationCid = cur.getString(2);
                    platformCid = cur.getString(3);
                    firstBogieDistance = cur.getDouble(4);
                    firstCarDistance = cur.getDouble(5);
                    lastCarDistance = cur.getDouble(6);
                    fromUtcSeconds = cur.getDouble(7);
                    toUtcSeconds = cur.getDouble(8);
                    isServing = cur.getInt(9) == 1;
                } finally {
                    cur.close();
                }

                List<StringRefEdgeInEdgeSet> eies = new ArrayList<>();
                cur = this.dbh.rawQuery("SELECT edge_id,from_distance,to_distance,sign" +
                        " FROM waits_edges WHERE wait_id=? ORDER BY seq", new String[]{cid});
                try {
                    if (!cur.moveToFirst()) {
                        throw new Exception("Edge-in-wait for ID=" + cid + " not found");
                    }
                    do {
                        String edgeCid = cur.getString(0);
                        double fromDistance = cur.getDouble(1);
                        double toDistance = cur.getDouble(2);
                        int sgn = cur.getInt(3);
                        StringRefEdgeInEdgeSet eie = new StringRefEdgeInEdgeSet();
                        eie.edgeCid = edgeCid;
                        eie.fromDistance = fromDistance;
                        eie.toDistance = toDistance;
                        eie.sgn = sgn;
                        eies.add(eie);
                    } while (cur.moveToNext());
                } finally {
                    cur.close();
                }

                InputStreamLoader.StringRefWait ir = new InputStreamLoader.StringRefWait(waitCid, formationCid, tripCid, platformCid, fromUtcSeconds, toUtcSeconds, firstCarDistance, lastCarDistance, firstBogieDistance, isServing, eies);
                results.put(cid, ir);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
    }
}
