/*
 * Copyright 2013 Hannes Janetzek
 *
 * This file is part of the OpenScienceMap project (http://www.opensciencemap.org).
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package org.oscim.android.cache.sqlite3;

import android.annotation.TargetApi;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDoneException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.os.Build;
import android.os.ParcelFileDescriptor;

import com.ogiqvo.ICubeCache;

import org.oscim.core.Cube;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class CubeCache implements ICubeCache {

    final static org.slf4j.Logger log = LoggerFactory.getLogger(CubeCache.class);
    final static boolean IS_DEBUG_MODE = false;

    class CacheCubeReader implements CubeReader {
        final InputStream inputStream;
        final Cube cube;

        public CacheCubeReader(Cube cube, InputStream inputStream) {
            this.cube = cube;
            this.inputStream = inputStream;
        }

        @Override
        public Cube getCube() {
            return cube;
        }

        @Override
        public InputStream getInputStream() {
            return inputStream;
        }
    }

    class CacheCubeWriter implements CubeWriter {
        final ByteArrayOutputStream outputStream;
        final Cube cube;

        CacheCubeWriter(Cube cube, ByteArrayOutputStream os) {
            this.cube = cube;
            outputStream = os;
        }

        @Override
        public Cube getCube() {
            return cube;
        }

        @Override
        public OutputStream getOutputStream() {
            return outputStream;
        }

        @Override
        public void complete(boolean success) {
            saveCube(cube, outputStream, success);
        }
    }

    private final ArrayList<ByteArrayOutputStream> cacheBuffers;
    private final SQLiteHelper dbHelper;
    private final SQLiteDatabase database;
    private final SQLiteStatement statementGetCube;
    private final SQLiteStatement statementPutCube;

    //private final SQLiteStatement mStmtUpdateCube;

    public void dispose() {
        if (database.isOpen())
            database.close();
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public CubeCache(Context context, String cacheDirectory, String dbName) {
        if (IS_DEBUG_MODE)
            log.debug("open cache {}, {}", cacheDirectory, dbName);

        dbHelper = new SQLiteHelper(context, dbName);

        if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN)
            dbHelper.setWriteAheadLoggingEnabled(true);

        database = dbHelper.getWritableDatabase();

        statementGetCube = database.compileStatement("" +
                "SELECT " + COLUMN_DATA +
                " FROM " + TABLE_NAME +
                " WHERE x=? AND y=? AND z=? AND tc=?");

        statementPutCube = database.compileStatement("" +
                "INSERT INTO " + TABLE_NAME +
                " (x, y, z, tc, time, last_access, data)" +
                " VALUES(?,?,?,?,?,?,?)");

        //mStmtUpdateCube = database.compileStatement("" +
        //        "UPDATE " + TABLE_NAME +
        //        "  SET last_access=?" +
        //        "  WHERE x=? AND y=? AND z=?");

        cacheBuffers = new ArrayList<ByteArrayOutputStream>();
    }

    @Override
    public CubeWriter writeCubeOnLoadingThread(Cube cube) {
        ByteArrayOutputStream os;

        synchronized (cacheBuffers) {
            if (cacheBuffers.size() == 0)
                os = new ByteArrayOutputStream(32 * 1024);
            else
                os = cacheBuffers.remove(cacheBuffers.size() - 1);
        }
        return new CacheCubeWriter(cube, os);
    }

    static final String TABLE_NAME = "cubes";
    static final String COLUMN_TIME = "time";
    static final String COLUMN_ACCESS = "last_access";
    static final String COLUMN_DATA = "data";

    //static final String COLUMN_SIZE = "size";

    class SQLiteHelper extends SQLiteOpenHelper {

        //private static final String DATABASE_NAME = "Cube.db";
        private static final int DATABASE_VERSION = 1;

        private static final String Cube_SCHEMA =
                "CREATE TABLE "
                        + TABLE_NAME + "("
                        + "x INTEGER NOT NULL,"
                        + "y INTEGER NOT NULL,"
                        + "z INTEGER NOT NULL,"
                        + "tc INTEGER NOT NULL,"
                        + COLUMN_TIME + " LONG NOT NULL,"
                        //+ COLUMN_SIZE + " LONG NOT NULL,"
                        + COLUMN_ACCESS + " LONG NOT NULL,"
                        + COLUMN_DATA + " BLOB,"
                        + "PRIMARY KEY(x,y,z,tc));";

        public SQLiteHelper(Context context, String dbName) {
            super(context, dbName, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            log.debug("create table");
            db.execSQL(Cube_SCHEMA);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            log.debug("drop table");
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }

        @Override
        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }
    }

    public void saveCube(Cube cube, ByteArrayOutputStream data, boolean success) {
        byte[] bytes = null;

        if (success)
            bytes = data.toByteArray();

        synchronized (cacheBuffers) {
            data.reset();
            cacheBuffers.add(data);
        }

        if (IS_DEBUG_MODE)
            log.debug("store cube {} {}", cube, Boolean.valueOf(success));

        if (!success)
            return;

        synchronized (statementPutCube) {
            statementPutCube.bindLong(1, cube.tileX);
            statementPutCube.bindLong(2, cube.tileY);
            statementPutCube.bindLong(3, cube.zoomLevel);
            statementPutCube.bindLong(4, cube.timechunk);
            statementPutCube.bindLong(5, 0);
            statementPutCube.bindLong(6, 0);
            statementPutCube.bindBlob(7, bytes);

            statementPutCube.execute();
            statementPutCube.clearBindings();
        }
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public CubeReader getCubeApi11(Cube cube) {
        InputStream in = null;

        statementGetCube.bindLong(1, cube.tileX);
        statementGetCube.bindLong(2, cube.tileY);
        statementGetCube.bindLong(3, cube.zoomLevel);
        statementGetCube.bindLong(4, cube.timechunk);

        try {
            ParcelFileDescriptor result = statementGetCube.simpleQueryForBlobFileDescriptor();
            in = new FileInputStream(result.getFileDescriptor());
        } catch (SQLiteDoneException e) {
            log.debug("not in cache {}", cube);
            return null;
        } finally {
            statementGetCube.clearBindings();
        }

        if (IS_DEBUG_MODE)
            log.debug("load cube {}", cube);

        return new CacheCubeReader(cube, in);
    }

    private final String[] mQueryVals = new String[4];

    @Override
    public synchronized CubeReader getCubeOnLoadingThread(Cube cube) {
        //if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB)
        //	return getCubeApi11(Cube);

        mQueryVals[0] = String.valueOf(cube.zoomLevel);
        mQueryVals[1] = String.valueOf(cube.tileX);
        mQueryVals[2] = String.valueOf(cube.tileY);
        mQueryVals[3] = String.valueOf(cube.timechunk);

        Cursor cursor = database.rawQuery("SELECT " + COLUMN_DATA +
                " FROM " + TABLE_NAME +
                " WHERE z=? AND x=? AND y=? AND tc=?", mQueryVals);

        if (!cursor.moveToFirst()) {
            if (IS_DEBUG_MODE)
                log.debug("not in cache {}", cube);

            cursor.close();
            return null;
        }

        InputStream in = new ByteArrayInputStream(cursor.getBlob(0));
        cursor.close();

        if (IS_DEBUG_MODE)
            log.debug("load Cube {}", cube);

        return new CacheCubeReader(cube, in);
    }

    @Override
    public void setCacheSize(long size) {
    }
}
