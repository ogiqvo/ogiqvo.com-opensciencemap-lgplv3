/*
 * Copyright 2013 Hannes Janetzek
 *
 * This file is part of the OpenScienceMap project (http://www.opensciencemap.org).
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package org.oscim.android;

import android.widget.RelativeLayout.LayoutParams;

import org.oscim.android.gl.GLView;
import org.oscim.map.Map;

public class AndroidMap extends Map {

	private final MapView mapView;
	final GLView glView;

	private volatile boolean isWaitingRedraw;
	private volatile boolean isPausing;

	public AndroidMap(MapView mapView) {
		super();

		this.mapView = mapView;
		glView = new GLView(mapView.getContext(), this);

		LayoutParams params =
		        new LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT,
		                         android.view.ViewGroup.LayoutParams.MATCH_PARENT);

		mapView.addView(glView, params);
	}

	@Override
	public int getWidth() {
		return mapView.getWidth();
	}

	@Override
	public int getHeight() {
		return mapView.getHeight();
	}

	@Override
	public void requestMapUpdateOnMainThread(boolean redraw) {
		//if (redraw && !isMapClearingRequired && !isPausing)
		//	glView.requestRender();

		if (!isWaitingRedraw) {
			isWaitingRedraw = true;

			// Redraw on UI thread
			mapView.post(redrawingMapOnMainThreadRunnable);
		}
	}

	private final Runnable redrawingMapOnMainThreadRunnable = new Runnable() {
		@Override
		public void run() {
			redrawMapOnMainThread();
		}
	};

	void redrawMapOnMainThread() {
		isWaitingRedraw = false;

		updateLayersOnMainThreadBeforeRenderingFrame();

		glView.requestRender();
	}

	@Override
	public void addRenderingRequestToMainThread() {
		if (isPausing)
			return;

		if (isMapClearingRequired)
			requestMapUpdateOnMainThread(false);
		else
			glView.requestRender();
	}

	@Override
	public boolean addRunnableToRunOnMainThread(Runnable runnable) {
		return mapView.post(runnable);
	}

	@Override
	public boolean addRunnableToRunDelayedOnMainThread(Runnable action, long delay) {
		return mapView.postDelayed(action, delay);
	}

	public void pause(boolean pause) {
		isPausing = pause;
	}
}
