/*
 * Copyright 2012 Hannes Janetzek
 *
 * This file is part of the OpenScienceMap project (http://www.opensciencemap.org).
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package org.oscim.android;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.widget.RelativeLayout;

import org.oscim.android.canvas.AndroidGraphics;
import org.oscim.android.gl.AndroidGL;
import org.oscim.android.input.AndroidMotionEvent;
import org.oscim.android.input.GestureHandler;
import org.oscim.backend.CanvasAdapter;
import org.oscim.backend.GLAdapter;
import org.oscim.map.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MapView extends RelativeLayout {

	static {
		System.loadLibrary("vtm-jni");
	}

	static final Logger log = LoggerFactory.getLogger(MapView.class);

	protected final AndroidMap map;
	protected final GestureDetector gestureDetector;
	protected final AndroidMotionEvent motionEvent;

	public MapView(Context context) {
		this(context, null);
	}

	public MapView(Context context, AttributeSet attributeSet) {
		super(context, attributeSet);
		this.setWillNotDraw(true);
		this.setClickable(true);
		this.setFocusable(true);

		AndroidGraphics.init();
		AndroidGraphics.loadFontFromContext(context);
		GLAdapter.init(new AndroidGL());

		DisplayMetrics metrics = getResources().getDisplayMetrics();
		CanvasAdapter.dpi = (int) Math.max(metrics.xdpi, metrics.ydpi);

		map = new AndroidMap(this);

		if (context instanceof MapActivity)
			((MapActivity) context).registerMapView(this);

		map.clearMapOnMainThread();
		map.requestMapUpdateOnMainThread(false);

		GestureHandler gestureHandler = new GestureHandler(map);
		gestureDetector = new GestureDetector(context, gestureHandler);
		gestureDetector.setOnDoubleTapListener(gestureHandler);

		motionEvent = new AndroidMotionEvent();
	}

	public void onStop() {

	}

	void onPause() {
		map.pause(true);
	}

	void onResume() {
		map.pause(false);
	}

	@SuppressLint("ClickableViewAccessibility")
	@Override
	public boolean onTouchEvent(android.view.MotionEvent motionEvent) {

		if (!isClickable())
			return false;

		if (gestureDetector.onTouchEvent(motionEvent))
			return true;

		map.inputEventDispatcher.fire(null, this.motionEvent.wrap(motionEvent));
		return true;
	}

	@Override
	protected void onSizeChanged(int width, int height,
								 int oldWidth, int oldHeight) {

		super.onSizeChanged(width, height, oldWidth, oldHeight);

		if (width > 0 && height > 0)
			map.viewport().setScreenSize(width, height);
	}

	public Map map() {
		return map;
	}
}
