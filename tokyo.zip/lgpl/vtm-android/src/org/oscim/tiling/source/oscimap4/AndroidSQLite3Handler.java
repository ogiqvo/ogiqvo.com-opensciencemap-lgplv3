package org.oscim.tiling.source.oscimap4;

import android.content.Context;
import android.database.Cursor;

import com.ogiqvo.ISQLite3Tile2blobHandler;
import com.ogiqvo.lib.android.AndroidBaseSQLite3Handler;

import org.oscim.core.Tile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

/**
 * Created by xor on 15/11/30.
 */
public class AndroidSQLite3Handler extends AndroidBaseSQLite3Handler implements ISQLite3Tile2blobHandler {
    static final Logger log = LoggerFactory.getLogger(AndroidSQLite3Handler.class);
    byte[] emptyByteArray = new byte[0];

    public AndroidSQLite3Handler(Context context, String inPathPrefix, String outPathDir, String outPathFileName) {
        super(context, inPathPrefix, outPathDir, outPathFileName);
    }

    @Override
    public InputStream inputStreamForTile(Tile tile) {
        this.dbh.beginTransaction();
        try {
            int x = tile.tileX;
            int y = tile.tileY;
            int z = tile.zoomLevel;
            Cursor cur = this.dbh.rawQuery("SELECT b FROM a WHERE x=? AND y=? AND z=?", new String[]{x + "", y + "", z + ""});
            try {
                if (cur.moveToFirst()) {
                    byte[] bs = cur.getBlob(0);
                    log.debug("x={},y={},z={} .. {} bytes", new Object[]{x + "", y + "", z + "", bs.length + ""});
                    return new ByteArrayInputStream(bs);
                }
            } finally {
                cur.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.dbh.endTransaction();
        }
        return new ByteArrayInputStream(emptyByteArray);
    }
}
