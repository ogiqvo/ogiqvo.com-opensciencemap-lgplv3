package org.poly2tri.triangulation;

public enum TriangulationMode
{
    UNCONSTRAINED,CONSTRAINED,POLYGON;
}
