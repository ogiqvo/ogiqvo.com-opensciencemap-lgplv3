package org.poly2tri.triangulation.delaunay.sweep;

public class PointOnEdgeException extends RuntimeException
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public PointOnEdgeException( String msg )
    {
        super(msg);
    }
}
