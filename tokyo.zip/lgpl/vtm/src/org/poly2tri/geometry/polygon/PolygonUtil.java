package org.poly2tri.geometry.polygon;

public class PolygonUtil
{
    /**
     * TODO
     * @param polygon
     */
    public static void validate( Polygon polygon )
    {
        // TODO: implement
        // 1. Check for duplicate points
        // 2. Check for intersecting sides
    }
}
