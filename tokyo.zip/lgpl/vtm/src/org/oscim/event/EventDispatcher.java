package org.oscim.event;

import org.oscim.utils.pool.LList;

/**
 * The Class EventDispatcher.
 * 
 * Events MUST be dispatched from main-loop! To add mapEventOnMainThreadDispatcher from other
 * threads use:
 * Map.addRunnableToRunOnMainThread(new Runnable(){ public void run(onFired(event,data);)};);
 * 
 * @param <T> the event source geometryType
 * @param <E> the event 'data' geometryType
 */
public abstract class EventDispatcher<E extends EventListener, T> {
	/** The list of listeners. */
	protected LList<E> mListeners;

	/**
	 * Bind listener for event notifications.
	 */
	public void listen(E listener) {
        if (LList.find(mListeners, listener) != null) {
            return;
        }
        mListeners = LList.push(mListeners, new LList<E>(listener));
    }

	/**
	 * Remove listener.
	 */
	public void unlisten(E listener) {
		mListeners = LList.remove(mListeners, listener);
	}

	/**
	 * Tell listeners whats going on.
	 * 
	 * @param event the event
	 * @param data the data
	 */
	public abstract void onFired(E listener, Event event, T data);

	public void fire(Event event, T data) {
		for (LList<E> l = mListeners; l != null; l = l.next) {
			onFired(l.data, event, data);
		}
	}
}
