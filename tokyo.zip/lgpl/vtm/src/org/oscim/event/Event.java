package org.oscim.event;

/**
 * The Class Event to be sub-classed by event-producers. Should be used
 * to distinguish the geometryType of event when more than one is produced.
 */
public class Event {

}
