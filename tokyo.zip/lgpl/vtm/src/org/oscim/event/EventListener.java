package org.oscim.event;

/**
 * Event-listener interface.
 */
public interface EventListener {

}
