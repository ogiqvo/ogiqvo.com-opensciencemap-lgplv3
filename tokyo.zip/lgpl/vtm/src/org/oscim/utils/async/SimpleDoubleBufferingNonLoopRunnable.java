package org.oscim.utils.async;

import org.oscim.map.Map;

/**
 * Simple 'Double Buffering' worker for running Tasks on AsyncExecutor
 * thread.
 */
public abstract class SimpleDoubleBufferingNonLoopRunnable<T> implements Runnable {

	protected final Map map;

	protected boolean isRunning;
	protected boolean isWaiting;
	protected boolean isCancelling;
	protected boolean isDelayed;

	protected long minDelay;

	/** Stuff which can be processed on the worker thread. */
	protected T waitingTask;

	/** Stuff that is done an ready for being fetched by pop(). */
	protected T doneTask;

	/** Stuff that is ready - will not be modified in the worker. */
	protected T lockedTask;

	public SimpleDoubleBufferingNonLoopRunnable(Map map, long minDelay, T t1, T t2) {
		this.map = map;
		this.minDelay = minDelay;

		waitingTask = t1;
		lockedTask = t2;
	}

	@Override
	public void run() {

		synchronized (this) {
			if (isCancelling) {
				isCancelling = false;
				isRunning = false;
				isDelayed = false;
				isWaiting = false;
				if (waitingTask != null)
					cleanup(waitingTask);
				finish();
				return;
			}

			// FIXME: waitingTask == null?
			if (isDelayed || waitingTask == null) {

				if (isDelayed && waitingTask != null)
					onMainLoop(waitingTask);

				// entered on main-loop
				isDelayed = false;
				// unset running temporarily
				isRunning = false;
				submit(0);
				return;
			}
		}

		boolean done = runTaskOnce(waitingTask);

		synchronized (this) {
			isRunning = false;

			if (isCancelling) {
				cleanup(waitingTask);
				finish();
				isCancelling = false;
			} else if (done) {
				doneTask = waitingTask;
				waitingTask = null;
			} else if (isWaiting) {
				// only submit if not 'done'
				// as otherwise there is no
				// mStuffTodo
				submit(minDelay);
				isWaiting = false;
			}
		}
	}

	public abstract boolean runTaskOnce(T task);

	public abstract void cleanup(T task);

	public void finish() {

	}

	/** do stuff on main-loop before executing the task */
	public void onMainLoop(T task) {

	}

	/**
	 * If delay > 0 onMainLoop will be called before Task
	 * is passed to worker-thread
	 */
	public synchronized void submit(long delayMilliseconds) {

		if (isRunning) {
			isWaiting = true;
			return;
		}

		isRunning = true;
		if (delayMilliseconds <= 0) {
			map.addRunnableToRunOnWorkerThread(this);
			return;
		}

		if (!isDelayed) {
			isDelayed = true;
			map.addRunnableToRunDelayedOnMainThread(this, delayMilliseconds);
		}
	}

	public synchronized T poll() {
		if (doneTask == null)
			return null;

		cleanup(lockedTask);
		waitingTask = lockedTask;

		lockedTask = doneTask;
		doneTask = null;

		if (isWaiting) {
			submit(minDelay);
			isWaiting = false;
		}

		return lockedTask;
	}

	public synchronized void cancel(boolean clear) {
		if (isRunning) {
			isCancelling = true;
			return;
		}

		cleanup(waitingTask);
		finish();
	}

	public synchronized boolean isRunning() {
		return isRunning;
	}

}
