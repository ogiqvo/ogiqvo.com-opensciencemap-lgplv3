package com.owens.oobjloader.lwjgl;

// Written by Sean R. Owens, sean at guild dot net, released to the
// public domain. Share and enjoy. Since some people argue that it is
// impossible to release software to the public domain, you are also free
// to use this code under any version of the GPL, LPGL, Apache, or BSD
// licenses, or contact me for use of another license.

import com.ogiqvo.PrimitiveShader;
import com.owens.oobjloader.builder.Face;
import com.owens.oobjloader.builder.FaceVertex;

import org.oscim.backend.GL;
import org.oscim.backend.canvas.Color;
import org.oscim.renderer.GLState;
import org.oscim.renderer.GLUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Collection;

import static org.oscim.backend.GLAdapter.gl;

public class VBO {
    static final Logger log = LoggerFactory.getLogger(VBO.class);

    // sizeof float/sizeof int
    public final static int FL_SIZE = 4;
    public final static int INDICE_SIZE_BYTES = 4;
    // Vertex Attribute Data - i.e. x,y,z then normalx, normaly, normalz, then texture u,v - so 8 floats.
    public final static int ATTR_V_FLOATS_PER = 3;
    public final static int ATTR_N_FLOATS_PER = 3;
    public final static int ATTR_T_FLOATS_PER = 2;
    public final static int ATTR_SZ_FLOATS = ATTR_V_FLOATS_PER + ATTR_N_FLOATS_PER + ATTR_T_FLOATS_PER;
    public final static int ATTR_SZ_BYTES = ATTR_SZ_FLOATS * FL_SIZE;
    public final static int ATTR_V_OFFSET_BYTES = 0;
    public final static int ATTR_V_OFFSET_FLOATS = 0;
    public final static int ATTR_N_OFFSET_FLOATS = ATTR_V_FLOATS_PER;
    public final static int ATTR_N_OFFSET_BYTES = ATTR_N_OFFSET_FLOATS * FL_SIZE;
    ;

    public final static int ATTR_T_OFFSET_FLOATS = ATTR_V_FLOATS_PER + ATTR_N_FLOATS_PER;
    public final static int ATTR_T_OFFSET_BYTES = ATTR_T_OFFSET_FLOATS * FL_SIZE;
    public final static int ATTR_V_STRIDE2_BYTES = ATTR_SZ_FLOATS * FL_SIZE;
    public final static int ATTR_N_STRIDE2_BYTES = ATTR_SZ_FLOATS * FL_SIZE;
    public final static int ATTR_T_STRIDE2_BYTES = ATTR_SZ_FLOATS * FL_SIZE;

    Collection<Face> faces;
    private FloatBuffer verticesBuffer;
    private int verticesBuffersLength;
    private IntBuffer indicesBuffer;
    private int indicesBuffersLength;

    private boolean isVboCreated = false;

    private int vboId;
    private int iboId;

    public VBO(Collection<Face> faces) {
        this.faces = faces;
        int faceVerticesSize = 0;
        for (Face face : faces) {
            faceVerticesSize += face.vertices.size();
        }
        float[] vertices = new float[faceVerticesSize * 3];
        int[] indices = new int[faceVerticesSize];
        int faceIndex = 0;
        for (Face face : faces) {
            int index = 0;
            for (FaceVertex v : face.vertices) {
                int localIndex = faceIndex + index;
                vertices[localIndex * 3] = v.v.x;
                vertices[localIndex * 3 + 1] = v.v.y;
                vertices[localIndex * 3 + 2] = v.v.z;
                indices[localIndex] = (int) localIndex;
                index++;
            }
            faceIndex += index;
        }

        verticesBuffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        verticesBuffer.put(vertices).position(0);

        verticesBuffersLength = vertices.length;

        indicesBuffer = ByteBuffer.allocateDirect(indices.length * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
        indicesBuffer.put(indices).position(0);

        indicesBuffersLength = indices.length;
    }

    private void createVboIfNotExists() {
        if (isVboCreated) {
            return;
        }

        int[] bufferIds = GLUtils.glGenBuffers(2);
        vboId = bufferIds[0];
        iboId = bufferIds[1];

        GLState.bindVertexBuffer(vboId);
        gl.bufferData(GL.ARRAY_BUFFER,
                verticesBuffersLength * 4, verticesBuffer,
                GL.STATIC_DRAW);
        GLState.bindVertexBuffer(0);

        GLState.bindElementBuffer(iboId);
        gl.bufferData(GL.ELEMENT_ARRAY_BUFFER,
                indicesBuffersLength * 4, indicesBuffer,
                GL.STATIC_DRAW);
        GLState.bindElementBuffer(0);

        isVboCreated = true;
    }

    public void render(PrimitiveShader shader) {
        this.createVboIfNotExists();

        GLState.bindVertexBuffer(vboId);
        GLState.enableVertexArrays(shader.aPos, -1);
        gl.vertexAttribPointer(shader.aPos, 3, GL.FLOAT, false, 0, 0);

        GLState.bindElementBuffer(iboId);
        GLUtils.setColor(shader.uColor, Color.DKGRAY, 0.9f);
        gl.drawElements(gl.TRIANGLES, indicesBuffersLength, gl.UNSIGNED_INT, 0);

        GLUtils.setColor(shader.uColor, Color.GREEN, 0.7f);
        gl.drawElements(gl.LINES, indicesBuffersLength, gl.UNSIGNED_INT, 0);
    }
}
