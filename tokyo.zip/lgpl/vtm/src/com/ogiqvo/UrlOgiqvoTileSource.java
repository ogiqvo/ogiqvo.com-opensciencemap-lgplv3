package com.ogiqvo;

import com.ogiqvo.lib.Pool;
import com.ogiqvo.lib.loader.ITileLoadable;

import org.oscim.tiling.ITileDataSource;
import org.oscim.tiling.source.UrlTileDataSource;
import org.oscim.tiling.source.UrlTileSource;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by xor on 15/11/29.
 */
public class UrlOgiqvoTileSource extends UrlTileSource {
    private Pool pool;
    private String commitId;
    private ITileLoadable loader;

    public UrlOgiqvoTileSource(String urlPrefix, String commitId, Pool pool, ITileLoadable loader) {
        super(urlPrefix, commitId + "/tile/{Z}/{X}/{Y}", 0, OgiqvoTileLayer.SRC_MAX_ZOOM);
        setUrlFormatter(UrlTileSource.URL_FORMATTER);

        this.pool = pool;
        this.commitId = commitId;
        this.loader = loader;
        Map<String, String> opt = new HashMap<>();
        setHttpRequestHeaders(opt);
    }

    @Override
    /**
     * @param tileY
     * @return
     */
    public int tileYToUrlY(int tileY) {
        return -tileY - 1;
    }

    @Override
    public ITileDataSource getDataSourceOnMainThread() {
        return new UrlTileDataSource(this,
                new OgiqvoTileDecoder(this.pool, this.commitId, this.loader),
                getHttpEngine());
    }
}
