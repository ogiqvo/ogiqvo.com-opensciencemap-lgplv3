package com.ogiqvo;

import com.ogiqvo.lib.bean.Formation;
import com.ogiqvo.lib.bean.Lnglat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by xor on 15/05/06.
 */
public class FormationContext implements Comparable<FormationContext>{
    static final Logger log = LoggerFactory.getLogger(FormationContext.class);

    private boolean isAvailable;
    private int dayDelta;
    private Object previousInstructionOrWait;
    private Formation formation;
    private double[] bogieDistances;
    private Lnglat[] bogieLnglats;
    private double[] bogieAltitudes;
    private Lnglat[] carCenterLnglats;
    private double[] carBearings;
    private double[] carWidths;
    private double[] carLengths;
    private double[] carPureHeight;
    private double[] carHeightUntilCenter;
    private double[] carAltitudes;
    private double[] carSlopes;
    private int carCount;
    private float alpha;
    private com.ogiqvo.lib.bean.instruction.FromServer currentInstruction;
    private com.ogiqvo.lib.bean.wait.FromServer currentWait;

    public FormationContext(Formation formation) {
        this.formation = formation;
        this.carCount = formation.getCars().size();
        this.allocateArrayForCarLength(this.carCount);
    }

    public Object getPreviousInstructionOrWait() {
        return previousInstructionOrWait;
    }

    public void setPreviousInstructionOrWait(Object previousInstructionOrWait) {
        this.previousInstructionOrWait = previousInstructionOrWait;
    }

    public int getDayDelta() {
        return dayDelta;
    }

    public void setDayDelta(int dayDelta) {
        this.dayDelta = dayDelta;
    }

    public com.ogiqvo.lib.bean.instruction.FromServer getCurrentInstruction() {
        return currentInstruction;
    }

    public void setCurrentInstruction(com.ogiqvo.lib.bean.instruction.FromServer currentInstruction) {
        this.currentInstruction = currentInstruction;
    }

    public void setCurrentWait(com.ogiqvo.lib.bean.wait.FromServer currentWait) {
        this.currentWait = currentWait;
    }

    public com.ogiqvo.lib.bean.wait.FromServer getCurrentWait() {
        return currentWait;
    }

    public int getCarCount() {
        return this.carCount;
    }

    public void allocateArrayForCarLength(int carCount) {
        this.bogieDistances = new double[carCount * 2];
        this.bogieLnglats = new Lnglat[carCount * 2];
        for (int i = 0; i < carCount * 2; i++) {
            this.bogieLnglats[i] = new Lnglat(0, 0);
            this.bogieDistances[i] = Double.NaN;
        }
        this.bogieAltitudes = new double[carCount * 2];
        this.isAvailable = false;

        this.carCenterLnglats = new Lnglat[carCount];
        for (int i = 0; i < carCount; i++) {
            this.carCenterLnglats[i] = new Lnglat(0, 0);
        }
        this.carBearings = new double[carCount];
        this.carWidths = new double[carCount];
        this.carLengths = new double[carCount];
        this.carPureHeight = new double[carCount];
        this.carHeightUntilCenter = new double[carCount];
        this.carAltitudes = new double[carCount];
        this.carSlopes = new double[carCount];
    }

    public void deepCopyBogieDistancesTo(FormationContext target) {
        assert this.carCount == target.getCarCount();
        System.arraycopy(this.bogieDistances, 0, target.getBogieDistances(), 0, this.bogieDistances.length);
    }

    public void deepCopyBogieLnglatsTo(FormationContext target) {
        assert this.carCount == target.getCarCount();
        for (int i = 0; i < this.bogieLnglats.length; i++) {
            Lnglat thisLl = this.bogieLnglats[i];
            if (thisLl == null) {
                continue;
            }
            Lnglat targetLl = target.getBogieLnglats()[i];
            if (targetLl == null) {
                targetLl = new Lnglat(thisLl.get4326lng(), thisLl.get4326lat());
                target.getBogieLnglats()[i] = targetLl;
            } else {
                targetLl.setLnglat4326(thisLl.get4326lng(), thisLl.get4326lat());
            }
        }
    }

    public void deepCopyBogieAltitudesTo(FormationContext target) {
        assert this.carCount == target.getCarCount();
        System.arraycopy(this.bogieAltitudes, 0, target.getBogieAltitudes(), 0, this.bogieAltitudes.length);
    }

    public void deepCopyIsAvailableTo(FormationContext target) {
        target.setIsAvailable(this.getIsAvailable());
    }

    public void deepCopyCarCenterLnglatsTo(FormationContext target) {
        assert this.carCount == target.getCarCount();
        for (int i = 0; i < this.carCenterLnglats.length; i++) {
            Lnglat thisLl = this.carCenterLnglats[i];
            if (thisLl == null) {
                continue;
            }
            Lnglat targetLl = target.getCarCenterLnglats()[i];
            if (targetLl == null) {
                targetLl = new Lnglat(thisLl.get4326lng(), thisLl.get4326lat());
                target.getBogieLnglats()[i] = targetLl;
            } else {
                targetLl.setLnglat4326(thisLl.get4326lng(), thisLl.get4326lat());
            }
        }
    }

    public void deepCopyCarBearingsTo(FormationContext target) {
        assert this.carCount == target.getCarCount();
        System.arraycopy(this.carBearings, 0, target.getCarBearings(), 0, this.carBearings.length);
    }

    public void deepCopyCarWidthsTo(FormationContext target) {
        assert this.carCount == target.getCarCount();
        System.arraycopy(this.carWidths, 0, target.getCarWidths(), 0, this.carWidths.length);
    }

    public void deepCopyCarLengthsTo(FormationContext target) {
        assert this.carCount == target.getCarCount();
        System.arraycopy(this.carLengths, 0, target.getCarLengths(), 0, this.carLengths.length);
    }

    public void deepCopyCarPureHeightsTo(FormationContext target) {
        assert this.carCount == target.getCarCount();
        System.arraycopy(this.carPureHeight, 0, target.getCarPureHeights(), 0, this.carPureHeight.length);
    }

    public void deepCopyCarHeightsUntilCenterTo(FormationContext target) {
        assert this.carCount == target.getCarCount();
        System.arraycopy(this.carHeightUntilCenter, 0, target.getCarHeightsUntilCenter(), 0, this.carHeightUntilCenter.length);
    }

    public Lnglat[] getCarCenterLnglats() {
        return carCenterLnglats;
    }

    public void setCarCenterLnglats(Lnglat[] carCenterLnglats) {
        this.carCenterLnglats = carCenterLnglats;
    }

    public double[] getBogieAltitudes() {
        return bogieAltitudes;
    }

    public void setBogieAltitudes(double[] bogieAltitudes) {
        this.bogieAltitudes = bogieAltitudes;
    }

    public double[] getCarBearings() {
        return carBearings;
    }

    public void setCarBearings(double[] carBearings) {
        this.carBearings = carBearings;
    }

    public double[] getCarWidths() {
        return carWidths;
    }

    public void setCarWidths(double[] carWidths) {
        this.carWidths = carWidths;
    }

    public double[] getCarLengths() {
        return carLengths;
    }

    public void setCarLengths(double[] carLengths) {
        this.carLengths = carLengths;
    }

    public double[] getCarPureHeights() {
        return carPureHeight;
    }

    public void setCarPureHeight(double[] carPureHeight) {
        this.carPureHeight = carPureHeight;
    }

    public double[] getCarHeightsUntilCenter() {
        return carHeightUntilCenter;
    }

    public void setCarHeightUntilCenter(double[] carHeightUntilCenter) {
        this.carHeightUntilCenter = carHeightUntilCenter;
    }

    public boolean getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public Formation getFormation() {
        return formation;
    }

    public void setFormation(Formation formation) {
        this.formation = formation;
    }

    public double[] getBogieDistances() {
        return bogieDistances;
    }

    public void setBogieDistances(double[] bogieDistances) {
        this.bogieDistances = bogieDistances;
    }

    public Lnglat[] getBogieLnglats() {
        return bogieLnglats;
    }

    public void setBogieLnglats(Lnglat[] bogieLnglats) {
        this.bogieLnglats = bogieLnglats;
    }

    public double[] getCarAltitudes() {
        return carAltitudes;
    }

    public void setCarAltitudes(double[] carAltitudes) {
        this.carAltitudes = carAltitudes;
    }

    public double[] getCarSlopes() {
        return carSlopes;
    }

    public void setCarSlopes(double[] carSlopes) {
        this.carSlopes = carSlopes;
    }

    public float getAlpha() {
        return alpha;
    }

    public void setAlpha(float alpha) {
        this.alpha = alpha;
    }

    @Override
    public int compareTo(FormationContext formationContext) {
        return this.formation.compareTo(formationContext.getFormation());
    }
}
