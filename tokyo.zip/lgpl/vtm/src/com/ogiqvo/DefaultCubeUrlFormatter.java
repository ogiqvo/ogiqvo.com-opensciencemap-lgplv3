package com.ogiqvo;

import org.oscim.core.Cube;
import org.oscim.tiling.source.UrlTileSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by xor on 15/05/06.
 */
public class DefaultCubeUrlFormatter  implements CubeUrlFormatter {
    static final Logger log = LoggerFactory.getLogger(DefaultCubeUrlFormatter.class);

    @Override
    public String formatCubePath(UrlTileSource tileSource, Cube cube) {

        StringBuilder sb = new StringBuilder();
        for (String b : tileSource.getTilePath()) {
            log.debug("Something like " + b);
            if (b.length() == 1) {
                switch (b.charAt(0)) {
                    case 'X':
                        sb.append(cube.tileX);
                        continue;
                    case 'Y':
                        sb.append(cube.tileY);
                        continue;
                    case 'Z':
                        sb.append(cube.zoomLevel);
                        continue;
                    case 'T':
                        sb.append(cube.timechunk);
                        continue;
                    default:
                        break;
                }
            }
            sb.append(b);
            log.debug("  became " + sb.toString());
        }
        return sb.toString();
    }
}
