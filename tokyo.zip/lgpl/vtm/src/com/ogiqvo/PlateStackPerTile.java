package com.ogiqvo;

import com.ogiqvo.platestack.bean.Amenity;
import com.ogiqvo.platestack.bean.Elevator;
import com.ogiqvo.platestack.bean.Escalator;
import com.ogiqvo.platestack.bean.Floor;
import com.ogiqvo.platestack.bean.Platform;
import com.ogiqvo.platestack.bean.Slope;
import com.ogiqvo.platestack.bean.Stair;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by xor on 15/08/29.
 */
public class PlateStackPerTile {
    Map<String, Floor> floors;
    Map<String, Escalator> escalators;
    Map<String, Stair> stairs;
    Map<String, Elevator> elevators;
    Map<String, Slope> slopes;
    Map<String, Platform> platforms;
    Map<String, Amenity> amenities;

    public PlateStackPerTile() {
        floors = new HashMap<>();
        escalators = new HashMap<>();
        stairs = new HashMap<>();
        elevators = new HashMap<>();
        slopes = new HashMap<>();
        platforms = new HashMap<>();
        amenities = new HashMap<>();
    }

    public Map<String, Floor> getFloors() {
        return floors;
    }

    public void setFloors(Map<String, Floor> floors) {
        this.floors = floors;
    }

    public Map<String, Escalator> getEscalators() {
        return escalators;
    }

    public void setEscalators(Map<String, Escalator> escalators) {
        this.escalators = escalators;
    }

    public Map<String, Stair> getStairs() {
        return stairs;
    }

    public void setStairs(Map<String, Stair> stairs) {
        this.stairs = stairs;
    }

    public Map<String, Elevator> getElevators() {
        return elevators;
    }

    public void setElevators(Map<String, Elevator> elevators) {
        this.elevators = elevators;
    }

    public Map<String, Slope> getSlopes() {
        return slopes;
    }

    public void setSlopes(Map<String, Slope> slopes) {
        this.slopes = slopes;
    }

    public Map<String, Platform> getPlatforms() {
        return platforms;
    }

    public void setPlatforms(Map<String, Platform> platforms) {
        this.platforms = platforms;
    }

    public Map<String, Amenity> getAmenities() {
        return amenities;
    }

    public void setAmenities(Map<String, Amenity> amenities) {
        this.amenities = amenities;
    }
}
