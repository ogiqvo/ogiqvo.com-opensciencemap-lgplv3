package com.ogiqvo;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ogiqvo.platestack.bean.Amenity;
import com.ogiqvo.platestack.bean.Elevator;
import com.ogiqvo.platestack.bean.Escalator;
import com.ogiqvo.platestack.bean.Floor;
import com.ogiqvo.platestack.bean.Platform;
import com.ogiqvo.platestack.bean.Slope;
import com.ogiqvo.platestack.bean.Stair;
import com.ogiqvo.platestack.bean.Wc;

import org.oscim.core.GeometryBuffer;
import org.oscim.core.MapElement;
import org.oscim.core.Tag;
import org.oscim.core.Tile;
import org.oscim.tiling.ITileDataLoadCallbackable;
import org.oscim.tiling.source.ITileDecoder;
import org.oscim.utils.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.fasterxml.jackson.core.JsonToken.END_ARRAY;
import static com.fasterxml.jackson.core.JsonToken.END_OBJECT;
import static com.fasterxml.jackson.core.JsonToken.FIELD_NAME;
import static com.fasterxml.jackson.core.JsonToken.START_ARRAY;
import static com.fasterxml.jackson.core.JsonToken.START_OBJECT;
import static com.fasterxml.jackson.core.JsonToken.VALUE_FALSE;
import static com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT;
import static com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_INT;
import static com.fasterxml.jackson.core.JsonToken.VALUE_STRING;
import static com.fasterxml.jackson.core.JsonToken.VALUE_TRUE;
import static org.oscim.core.MercatorProjection.latitudeToY;
import static org.oscim.core.MercatorProjection.longitudeToX;

/**
 * Created by xor on 15/08/28.
 */
public class PlateStackTileDecoder implements ITileDecoder {
    static final Logger log = LoggerFactory.getLogger(PlateStackTileDecoder.class);

    private final JsonFactory mJsonFactory;

    private final static char[] FLOORS = "floors".toCharArray();
    private final static char[] STAIRS = "stairs".toCharArray();
    private final static char[] ESCALATORS = "escalators".toCharArray();
    private final static char[] ELEVATORS = "elevators".toCharArray();
    private final static char[] SLOPES = "slopes".toCharArray();
    private final static char[] PLATFORMS = "platforms".toCharArray();
    private final static char[] AMENITIES = "amenities".toCharArray();

    private final static char[] NAME = "name".toCharArray();
    private final static char[] COORDS = "coords".toCharArray();

    private final static char[] ID = "id".toCharArray();

    private final static char[] FROM_LATITUDE = "from_latitude".toCharArray();
    private final static char[] TO_LATITUDE = "to_latitude".toCharArray();
    private final static char[] FROM_LONGITUDE = "from_longitude".toCharArray();
    private final static char[] TO_LONGITUDE = "to_longitude".toCharArray();
    private final static char[] FROM_ALTITUDE = "from_altitude".toCharArray();
    private final static char[] TO_ALTITUDE = "to_altitude".toCharArray();
    private final static char[] EXTRUSION_BEARING = "extrusion_bearing".toCharArray();
    private final static char[] EXTRUSION_WIDTH = "extrusion_width".toCharArray();
    private final static char[] STEPS_PER_SLOPE = "steps_per_slope".toCharArray();
    private final static char[] KNOT_RS = "knot_rs".toCharArray();

    private final static char[] SHAPE = "shape".toCharArray();

    private final static char[] IS_DIRECTION_FROM_TO_TO = "is_direction_from_to_to".toCharArray();
    private final static char[] VELOCITY = "velocity".toCharArray();
    private final static char[] PLATE_DEPTH = "plate_depth".toCharArray();
    private final static char[] VERTICAL_ACCEL_HORIZONTAL_DISTANCE = "vertical_accel_horizontal_distance".toCharArray();

    private final static char[] FIELD_ALTITUDE = "altitude".toCharArray();
    private final static char[] FIELD_GEOJSON = "geojson".toCharArray();

    private final static char[] FIELD_WCS_GEOJSON = "wcs_geojson".toCharArray();
    private final static char[] FIELD_LADY = "lady".toCharArray();
    private final static char[] FIELD_GENTLEMAN = "gentleman".toCharArray();
    private final static char[] FIELD_WHEELCHAIR = "wheelchair".toCharArray();

    private final static char[] FIELD_FEATURES = "features".toCharArray();
    private final static char[] FIELD_GEOMETRY = "geometry".toCharArray();
    private final static char[] FIELD_PROPERTIES = "properties".toCharArray();
    private final static char[] FIELD_COORDINATES = "coordinates".toCharArray();
    private final static char[] FIELD_TYPE = "type".toCharArray();

    private final static char[] LINETRING = "LineString".toCharArray();
    private final static char[] POLYGON = "Polygon".toCharArray();
    private final static char[] POINT = "Point".toCharArray();
    private final static char[] MULTI_LINESTRING = "MultiLineString".toCharArray();
    private final static char[] MULTI_POLYGON = "MultiPolygon".toCharArray();
    private final static char[] MULTI_POINT = "MultiPoint".toCharArray();

    private double mTileY, mTileX, mTileScale;


    public PlateStackTileDecoder() {
        mJsonFactory = new JsonFactory();
    }

    @Override
    public boolean decodeOnLoadingThread(Tile tile, ITileDataLoadCallbackable sink, InputStream is) throws IOException {
        mTileScale = 1 << tile.zoomLevel;
        mTileX = tile.tileX / mTileScale;
        mTileY = tile.tileY / mTileScale;
        mTileScale *= Tile.SIZE;

//        log.debug("decodeOnLoadingThread");

        JsonParser jp = mJsonFactory.createParser(new InputStreamReader(is));

        PlateStackPerTile perTile = new PlateStackPerTile();
        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
//                log.debug("decodeOnLoadingThread::{}", jp.getText());
                if (match(jp, FLOORS)) {
                    while ((t = jp.nextToken()) != null) {
                        if (t == START_OBJECT) {
                            parseFloors(jp, perTile);
                        }
                        break;
                    }
                }
                if (match(jp, STAIRS)) {
                    while ((t = jp.nextToken()) != null) {
                        if (t == START_OBJECT) {
                            parseStairs(jp, perTile);
                        }
                        break;
                    }
                }
                if (match(jp, ESCALATORS)) {
                    while ((t = jp.nextToken()) != null) {
                        if (t == START_OBJECT) {
                            parseEscalators(jp, perTile);
                        }
                        break;
                    }
                }
                if (match(jp, ELEVATORS)) {
                    while ((t = jp.nextToken()) != null) {
                        if (t == START_OBJECT) {
                            parseElevators(jp, perTile);
                        }
                        break;
                    }
                }
                if (match(jp, SLOPES)) {
                    while ((t = jp.nextToken()) != null) {
                        if (t == START_OBJECT) {
                            parseSlopes(jp, perTile);
                        }
                        break;
                    }
                }
                if (match(jp, PLATFORMS)) {
                    while ((t = jp.nextToken()) != null) {
                        if (t == START_OBJECT) {
                            parsePlatforms(jp, perTile);
                        }
                        break;
                    }
                }
                if (match(jp, AMENITIES)) {
                    while ((t = jp.nextToken()) != null) {
                        if (t == START_OBJECT) {
                            parseAmenities(jp, perTile);
                        }
                        break;
                    }
                }
                continue;
            }

            if (t == END_OBJECT) {
                break;
            }
        }

//        log.debug("done.");
        sink.setPlateStackPerTileOnLoadingThread(perTile);

        return true;
    }

    private void parseFloors(JsonParser jp, PlateStackPerTile perTile) throws IOException {
//        log.debug("parseFloors");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
                String floorId = jp.getText();
                log.debug("floorId={}", floorId);

                t = jp.nextToken();
                if (t == START_OBJECT) {
                    Floor floor = new Floor();
                    this.parseFloor(jp, floor);
                    perTile.getFloors().put(floorId, floor);
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseFloors");
                break;
            }
        }
    }

    private void parseFloor(JsonParser jp, Floor floor) throws IOException {
//        log.debug("parseFloor");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
//                log.debug("parseFloor::{}", jp.getText());

                if (match(jp, FIELD_ALTITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        floor.setAltitude(this.parseNumberForJp(jp));
                    }
                }
                if (match(jp, FIELD_GEOJSON)) {
                    MapElement mapElement = new MapElement();
                    mapElement.tags.add(new Tag("indoor", "area"));

                    t = jp.nextToken();
                    if (t == START_OBJECT) {
                        this.parseFeature(jp, mapElement);
                        floor.setGeojsonObj(mapElement);
                    }
                }
                if (match(jp, FIELD_WCS_GEOJSON)) {
                    t = jp.nextToken();
                    if (t == START_OBJECT) {
                        this.parseWcs(jp, floor);
                    }
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseFloor");
                break;
            }
        }
    }

    private void parseWcs(JsonParser jp, Floor floor) throws IOException {
//        log.debug("parseWcs");
        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
                Wc.Type foundType = null;
                if (match(jp, FIELD_LADY)) {
                    foundType = Wc.Type.LADY;
                } else if (match(jp, FIELD_GENTLEMAN)) {
                    foundType = Wc.Type.GENTLEMAN;
                } else if (match(jp, FIELD_WHEELCHAIR)) {
                    foundType = Wc.Type.WHEELCHAIR;
                } else {
                    String typeName = jp.getText();
//                    log.error("Unknown type {}", typeName);
                }

                t = jp.nextToken();
                if (t == START_OBJECT) {
                    Wc wc = new Wc();
                    wc.setType(foundType);
                    this.parseWc(jp, wc);
                    floor.addWcs(foundType, wc);
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseWcs");
                break;
            }
        }
    }

    private void parseWc(JsonParser jp, Wc wc) throws IOException {
//        log.debug("parseWc");

        MapElement mapElement = new MapElement();
        String tagName = null;
        switch (wc.getType()) {
            case LADY:
                tagName = "wc-lady";
                break;
            case GENTLEMAN:
                tagName = "wc-gentleman";
                break;
            case WHEELCHAIR:
                tagName = "wc-wheelchair";
                break;
        }
        mapElement.tags.add(new Tag("indoor", tagName));
        this.parseFeature(jp, mapElement);
        wc.setGeojsonObj(mapElement);
    }

    private void parseFeature(JsonParser jp, MapElement mapElement)
            throws IOException {
        Map<String, Object> hashMap = new HashMap<>();
//        log.debug("parseFeature");
        for (JsonToken t; (t = jp.nextToken()) != null; ) {
//            log.debug("parseFeature::{}", jp.getText());

            if (t == FIELD_NAME) {
                if (match(jp, FIELD_GEOMETRY)) {
                    if (jp.nextToken() == START_OBJECT)
                        parseGeometry(jp, mapElement);
                }

                if (match(jp, FIELD_PROPERTIES)) {
                    if (jp.nextToken() == START_OBJECT) {
                        parseProperties(jp, hashMap);
                        t = jp.nextToken();
                    }
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseFeature");
                break;
            }
        }

        if (mapElement.geometryType == GeometryBuffer.GeometryType.NONE)
            return;
    }

    private void parseProperties(JsonParser jp, Map<String, Object> tagMap)
            throws IOException {
//        log.debug("parseProperties");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
                String text = jp.getCurrentName();
//                log.debug("Property {}", text);

                t = jp.nextToken();
                if (t == VALUE_STRING) {
                    tagMap.put(text, jp.getText());
                } else if (t == VALUE_NUMBER_INT) {
                    tagMap.put(text, jp.getNumberValue());
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseProperties");
                break;
            }
        }
    }

    private void parseGeometry(JsonParser jp, MapElement mapElement)
            throws IOException {
//        log.debug("parseGeometry");

        boolean multi = false;
        GeometryBuffer.GeometryType type = GeometryBuffer.GeometryType.NONE;

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
//                log.debug("parseGeometry::{}", jp.getText());

                if (match(jp, FIELD_COORDINATES)) {
                    if (jp.nextToken() != START_ARRAY)
                        continue;
                    if (multi) {
                        parseMulti(jp, type, mapElement);
                    } else {
                        if (type == GeometryBuffer.GeometryType.POLY)
                            parsePolygon(jp, mapElement);

                        if (type == GeometryBuffer.GeometryType.LINE)
                            parseLineString(jp, mapElement);

                        if (type == GeometryBuffer.GeometryType.POINT)
                            parseCoordinate(jp, mapElement);

                    }
                } else if (match(jp, FIELD_TYPE)) {
                    multi = false;

                    jp.nextToken();
//                    log.debug("parseGeometry::type::{}", jp.getText());

                    if (match(jp, LINETRING))
                        type = GeometryBuffer.GeometryType.LINE;
                    else if (match(jp, POLYGON))
                        type = GeometryBuffer.GeometryType.POLY;
                    else if (match(jp, POINT))
                        type = GeometryBuffer.GeometryType.POINT;
                    else if (match(jp, MULTI_LINESTRING)) {
                        type = GeometryBuffer.GeometryType.LINE;
                        multi = true;
                    } else if (match(jp, MULTI_POLYGON)) {
                        type = GeometryBuffer.GeometryType.POLY;
                        multi = true;
                    } else if (match(jp, MULTI_POINT)) {
                        type = GeometryBuffer.GeometryType.POINT;
                        multi = true;
                    }

                    if (type == GeometryBuffer.GeometryType.POINT)
                        mapElement.startPoints();
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseGeometry");
                break;
            }
        }
    }

    private void parseMulti(JsonParser jp, GeometryBuffer.GeometryType type, MapElement mapElement)
            throws IOException {

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == END_ARRAY)
                break;

            if (t == START_ARRAY) {
                if (type == GeometryBuffer.GeometryType.POLY)
                    parsePolygon(jp, mapElement);

                else if (type == GeometryBuffer.GeometryType.LINE)
                    parseLineString(jp, mapElement);

                else if (type == GeometryBuffer.GeometryType.POINT)
                    parseCoordinate(jp, mapElement);
                ;

            } else {
                //....
            }
        }
    }

    private void parsePolygon(JsonParser jp, MapElement mapElement)
            throws IOException {
//        log.debug("parsePolygon");
        int ring = 0;

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == START_ARRAY) {
                if (ring == 0) {
//                    log.debug("startPolygon");
                    mapElement.startPolygon();
                } else {
//                    log.debug("startHole");
                    mapElement.startHole();
                }

                ring++;
                parseCoordSequence(jp, mapElement);
                removeLastPoint(mapElement);
                continue;
            }

            if (t == END_ARRAY) {
//                log.debug("~parsePolygon");
                break;
            }
        }
    }

    private void removeLastPoint(MapElement mapElement) {
        mapElement.pointPos -= 2;
        mapElement.index[mapElement.indexPos] -= 2;
    }

    private void parseLineString(JsonParser jp, MapElement mapElement)
            throws IOException {
        mapElement.startLine();
        parseCoordSequence(jp, mapElement);
    }

    private void parseCoordSequence(JsonParser jp, MapElement mapElement)
            throws IOException {
//        log.debug("parseCoordSequence");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {

            if (t == START_ARRAY) {
                parseCoordinate(jp, mapElement);
                continue;
            }

            if (t == END_ARRAY) {
//                log.debug("~parseCoordSequence");
                break;
            }
        }
    }

    private void parseCoordinate(JsonParser jp, MapElement mapElement)
            throws IOException {
        int pos = 0;
        double x = 0, y = 0; //, z = 0;

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {

                // avoid String allocation (by getDouble...)
                double c = this.parseNumberForJp(jp);

                if (pos == 0)
                    x = c;
                if (pos == 1)
                    y = c;
                //if (pos == 2)
                //z = c;

                pos++;
                continue;
            }

            if (t == END_ARRAY)
                break;
        }

        float dx = (float) ((longitudeToX(x) - mTileX) * mTileScale);
        float dy = (float) ((latitudeToY(y) - mTileY) * mTileScale);
        mapElement.addPoint(dx, dy);
//        log.debug("Added point ({},{}) ({},{}) {}", new Object[]{dx, dy,mTileX,mTileY,mTileScale});
    }

    private void parseStairs(JsonParser jp, PlateStackPerTile perTile) throws IOException {
//        log.debug("parseStairs");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
                String stairId = jp.getText();

                t = jp.nextToken();
                if (t == START_OBJECT) {
                    Stair stair = new Stair();
                    this.parseStair(jp, stair);
                    perTile.getStairs().put(stairId, stair);
//                    log.debug("  put stair {}", stairId);
                }
            }
            if (t == END_OBJECT) {
//                log.debug("~parseStairs");
                break;
            }
        }
    }

    private void parseStair(JsonParser jp, Stair stair) throws IOException {
//        log.debug("parseStair");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
//                log.debug("parseStair::{}", jp.getText());

                if (match(jp, FROM_LATITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        stair.setFromLatitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_LATITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        stair.setToLatitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, FROM_LONGITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        stair.setFromLongitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_LONGITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        stair.setToLongitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, FROM_ALTITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        stair.setFromAltitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_ALTITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        stair.setToAltitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, EXTRUSION_BEARING)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        stair.setExtrusionBearing(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, EXTRUSION_WIDTH)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        stair.setExtrusionWidth(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, STEPS_PER_SLOPE)) {
                    t = jp.nextToken();
                    if (t == START_ARRAY) {
                        List<Integer> stepss = new ArrayList<>();
                        for (; (t = jp.nextToken()) != null; ) {
                            if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                                int steps = (int) this.parseNumberForJp(jp);
                                stepss.add(steps);
                            }
                            if (t == END_ARRAY) {
                                int[] stepssi = new int[stepss.size()];
                                for (int i = 0; i < stepss.size(); i++) {
                                    stepssi[i] = stepss.get(i);
                                }
                                stair.setStepsPerSlope(stepssi);
                                break;
                            }
                        }
                    }
                } else if (match(jp, KNOT_RS)) {
                    t = jp.nextToken();
                    if (t == START_ARRAY) {
                        List<Double> ts = new ArrayList<>();
                        for (; (t = jp.nextToken()) != null; ) {
                            if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                                double ttmp = this.parseNumberForJp(jp);
                                ts.add(ttmp);
                            }
                            if (t == END_ARRAY) {
                                double[] tsd = new double[ts.size()];
                                for (int i = 0; i < ts.size(); i++) {
                                    tsd[i] = ts.get(i);
                                }
                                stair.setKnotRs(tsd);
                                break;
                            }
                        }
                    }
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseStair");
                break;
            }
        }
    }

    private void parseEscalators(JsonParser jp, PlateStackPerTile perTile) throws IOException {
//        log.debug("parseEscalators");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
                String escalatorId = jp.getText();

                t = jp.nextToken();
                if (t == START_OBJECT) {
                    Escalator escalator = new Escalator();
                    this.parseEscalator(jp, escalator);
                    perTile.getEscalators().put(escalatorId, escalator);
//                    log.debug("  put escalator {}", escalatorId);
                }
            }
            if (t == END_OBJECT) {
//                log.debug("~parseEscalators");
                break;
            }
        }
    }

    private void parseEscalator(JsonParser jp, Escalator escalator) throws IOException {
//        log.debug("parseEscalator");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
//                log.debug("parseEscalator::{}", jp.getText());

                if (match(jp, FROM_LATITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setFromLatitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_LATITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setToLatitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, FROM_LONGITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setFromLongitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_LONGITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setToLongitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, FROM_ALTITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setFromAltitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_ALTITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setToAltitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, EXTRUSION_BEARING)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setExtrusionBearing(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, EXTRUSION_WIDTH)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setExtrusionWidth(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, IS_DIRECTION_FROM_TO_TO)) {
                    t = jp.nextToken();
                    if (t == VALUE_TRUE) {
                        escalator.setIsDirectionOrderFromTo(true);
                    } else if (t == VALUE_FALSE) {
                        escalator.setIsDirectionOrderFromTo(false);
                    }
                } else if (match(jp, PLATE_DEPTH)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setPlateDepth(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, VELOCITY)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setVelocity(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, VERTICAL_ACCEL_HORIZONTAL_DISTANCE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        escalator.setVerticalAccelHorizontalDistance(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, KNOT_RS)) {
                    t = jp.nextToken();
                    if (t == START_ARRAY) {
                        List<Double> ts = new ArrayList<>();
                        for (; (t = jp.nextToken()) != null; ) {
                            if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                                double ttmp = this.parseNumberForJp(jp);
                                ts.add(ttmp);
                            }
                            if (t == END_ARRAY) {
                                double[] tsd = new double[ts.size()];
                                for (int i = 0; i < ts.size(); i++) {
                                    tsd[i] = ts.get(i);
                                }
                                escalator.setKnotRs(tsd);
                                break;
                            }
                        }
                    }
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseEscalator");
                break;
            }
        }
    }

    private void parseSlopes(JsonParser jp, PlateStackPerTile perTile) throws IOException {
//        log.debug("parseSlopes");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
                String slopeId = jp.getText();

                t = jp.nextToken();
                if (t == START_OBJECT) {
                    Slope slope = new Slope();
                    this.parseSlope(jp, slope);
                    perTile.getSlopes().put(slopeId, slope);
//                    log.debug("  put slope {}", slopeId);
                }
            }
            if (t == END_OBJECT) {
//                log.debug("~parseSlopes");
                break;
            }
        }
    }

    private void parseSlope(JsonParser jp, Slope slope) throws IOException {
//        log.debug("parseSlope");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
//                log.debug("parseSlope::{}", jp.getText());

                if (match(jp, FROM_LATITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        slope.setFromLatitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_LATITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        slope.setToLatitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, FROM_LONGITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        slope.setFromLongitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_LONGITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        slope.setToLongitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, FROM_ALTITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        slope.setFromAltitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_ALTITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        slope.setToAltitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, EXTRUSION_BEARING)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        slope.setExtrusionBearing(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, EXTRUSION_WIDTH)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        slope.setExtrusionWidth(this.parseNumberForJp(jp));
                    }
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseSlope");
                break;
            }
        }
    }

    private void parseElevators(JsonParser jp, PlateStackPerTile perTile) throws IOException {
//        log.debug("parseElevators");
        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
                String elevatorId = jp.getText();

                t = jp.nextToken();
                if (t == START_OBJECT) {
                    Elevator elevator = new Elevator();
                    this.parseElevator(jp, elevator);
                    perTile.getElevators().put(elevatorId, elevator);
//                    log.debug("  put elevator {}", elevatorId);
                }
            }
            if (t == END_OBJECT) {
//                log.debug("~parseElevators");
                break;
            }
        }
    }

    private void parseElevator(JsonParser jp, Elevator elevator) throws IOException {
//        log.debug("parseElevator");

        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
//                log.debug("parseElevator::{}", jp.getText());

                if (match(jp, FROM_ALTITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        elevator.setFromAltitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, TO_ALTITUDE)) {
                    t = jp.nextToken();
                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                        elevator.setToAltitude(this.parseNumberForJp(jp));
                    }
                } else if (match(jp, SHAPE)) {
                    t = jp.nextToken();
                    if (t == START_ARRAY) {
                        List<Double> ts = new ArrayList<>();
                        for (; (t = jp.nextToken()) != null; ) {
                            if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                                double ttmp = this.parseNumberForJp(jp);
                                ts.add(ttmp);
                            }
                            if (t == END_ARRAY) {
                                double[] tsd = new double[ts.size()];
                                for (int i = 0; i < ts.size(); i++) {
                                    tsd[i] = ts.get(i);
                                }
                                elevator.setLlseq(tsd);
                                break;
                            }
                        }
                    }
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseElevator");
                break;
            }
        }
    }

    private void parsePlatforms(JsonParser jp, PlateStackPerTile perTile) throws IOException {
        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
                String floorId = jp.getText();
//                log.debug("platformId={}", floorId);

                t = jp.nextToken();
                if (t == START_OBJECT) {
                    Platform platform = new Platform();
                    this.parsePlatform(jp, platform);
                    perTile.getPlatforms().put(floorId, platform);
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parsePlatforms");
                break;
            }
        }
    }

    private void parsePlatform(JsonParser jp, Platform platform) throws IOException {
        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
//                log.debug("parsePlatform::{}", jp.getText());

                if (match(jp, NAME)) {
                    t = jp.nextToken();
                    if (t == VALUE_STRING) {
                        platform.setName(jp.getText());
                    }
                }
                if (match(jp, COORDS)) {
                    t = jp.nextToken();
                    if (t == START_ARRAY) {
                        for (; (t = jp.nextToken()) != null; ) {
                            boolean isCoordEnd = false;
                            if (t == START_ARRAY) {
                                Platform.Point p = new Platform.Point();
                                for (int dimension = 0; (t = jp.nextToken()) != null; ) {
                                    if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                                        double xyz = this.parseNumberForJp(jp);
                                        switch (dimension) {
                                            case 0:
                                                p.setLongitude(xyz);
                                                break;
                                            case 1:
                                                p.setLatitude(xyz);
                                                break;
                                            case 2:
                                                p.setAltitude(xyz);
                                                break;
                                        }
                                        dimension++;
                                    }
                                    if (t == END_ARRAY) {
                                        isCoordEnd = true;
                                        break;
                                    }
                                }
                                platform.getPoints().add(p);
                            }
                            if (isCoordEnd) {
                                isCoordEnd = false;
                                continue;
                            } else if (t == END_ARRAY) {
                                break;
                            }
                        }
                    }
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parsePlatform");
                break;
            }
        }
    }

    private void parseAmenities(JsonParser jp, PlateStackPerTile perTile) throws IOException {
        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
                String floorId = jp.getText();
//                log.debug("amenityId={}", floorId);

                t = jp.nextToken();
                if (t == START_OBJECT) {
                    Amenity amenity = new Amenity();
                    this.parseAmenity(jp, amenity);
                    perTile.getAmenities().put(floorId, amenity);
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseAmenities");
                break;
            }
        }
    }

    private void parseAmenity(JsonParser jp, Amenity amenity) throws IOException {
        for (JsonToken t; (t = jp.nextToken()) != null; ) {
            if (t == FIELD_NAME) {
//                log.debug("parseAmenity::{}", jp.getText());

                if (match(jp, ID)) {
                    t = jp.nextToken();
                    if (t == VALUE_STRING) {
                        amenity.setId(jp.getText());
                    }
                } else if (match(jp, COORDS)) {
                    t = jp.nextToken();
                    if (t == START_ARRAY) {
                        double longitude = 0;
                        double latitude = 0;
                        double altitude = 0;
                        for (int dimension = 0; (t = jp.nextToken()) != null; ) {
                            if (t == VALUE_NUMBER_FLOAT || t == VALUE_NUMBER_INT) {
                                double xyz = this.parseNumberForJp(jp);
                                switch (dimension) {
                                    case 0:
                                        longitude = xyz;
                                        break;
                                    case 1:
                                        latitude = xyz;
                                        break;
                                    case 2:
                                        altitude = xyz;
                                        break;
                                }
                                dimension++;
                            }
                            if (t == END_ARRAY) {
                                break;
                            }
                        }
                        amenity.setLongitude(longitude);
                        amenity.setLongitude(latitude);
                        amenity.setAltitude(altitude);
                    }
                } else {
                    String key = jp.getText();
                    t = jp.nextToken();
                    if (t == VALUE_STRING) {
                        amenity.getProperties().put(key, jp.getText());
                    }
                }
                continue;
            }
            if (t == END_OBJECT) {
//                log.debug("~parseAmenity");
                break;
            }
        }
    }

    private double parseNumberForJp(JsonParser jp) throws IOException {
        char[] val = jp.getTextCharacters();
        int offset = jp.getTextOffset();
        int length = jp.getTextLength();
        return ArrayUtils.parseNumber(val, offset, offset + length);
    }

    public final static boolean match(JsonParser jp, char[] fieldName)
            throws IOException {

        int length = jp.getTextLength();
        if (length != fieldName.length)
            return false;

        char[] val = jp.getTextCharacters();
        int offset = jp.getTextOffset();

        for (int i = 0; i < length; i++) {
            if (fieldName[i] != val[i + offset])
                return false;
        }

        return true;
    }
}
