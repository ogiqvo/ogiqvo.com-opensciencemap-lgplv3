package com.ogiqvo;

import com.ogiqvo.lib.bean.Car;
import com.ogiqvo.lib.bean.Carmodel;
import com.ogiqvo.lib.bean.Formation;
import com.ogiqvo.lib.bean.Lnglat;
import com.ogiqvo.lib.bean.Route;
import com.ogiqvo.lib.bean.Trip;

import org.oscim.backend.CanvasAdapter;
import org.oscim.backend.GL;
import org.oscim.backend.canvas.Canvas;
import org.oscim.backend.canvas.Color;
import org.oscim.backend.canvas.Paint;
import org.oscim.core.MapPosition;
import org.oscim.core.Point;
import org.oscim.core.Tile;
import org.oscim.layers.tile.MapTileJob;
import org.oscim.layers.tile.TileRenderer;
import org.oscim.renderer.GLMatrix;
import org.oscim.renderer.GLState;
import org.oscim.renderer.GLUtils;
import org.oscim.renderer.GLViewport;
import org.oscim.renderer.MapRenderer;
import org.oscim.renderer.bucket.BitmapBucket;
import org.oscim.renderer.bucket.TextureItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import static org.oscim.backend.GLAdapter.gl;

/**
 * Created by xor on 15/09/26.
 */
public class OgiqvoCubeLabelRenderer extends TileRenderer {
    static final Logger log = LoggerFactory.getLogger(OgiqvoCubeLabelRenderer.class);

    public final static int TEXTURE_HEIGHT = 4096;
    public final static int TEXTURE_WIDTH = 512;
    final static int POOL_FILL = 4;
    private int textureXPointOffset = 0;
    private int textureFoundMaxWidthInCurrentColumn = 0;
    private int textureYPointOffset = 0;
    private BitmapBucket.Shader textureShader;

    private final static float ROW0_FONT_SIZE = 13;
    private final static float ROW1_FONT_SIZE = 20;
    private final static float ROW1RANK_FONT_SIZE = 15;
    private final static float ROW2_FONT_SIZE = 32;
    private final static float ROW3_FONT_SIZE = 12;
    private final static float ROWV_FONT_SIZE = 11;

    private final static float LINE_COLOR_WIDTH = 15;

    private static float row0_height;
    private static float row1_height;
    private static float row1rank_height;
    private static float row2_height;
    private static float row3_height;
    private static float rowv_height;

    private static float row0_descent;
    private static float row1_descent;
    private static float row1rank_descent;
    private static float row2_descent;
    private static float row3_descent;
    private static float rowv_descent;

    protected FloatBuffer planeTexCoordBuffer;
    protected FloatBuffer planeVerticesBuffer;

    protected final Canvas mCanvas;
    public final static TextureItem.TexturePool pool = new TextureItem.TexturePool(POOL_FILL,
            TEXTURE_WIDTH,
            TEXTURE_HEIGHT);
    private final Paint framePaint;
    private final Paint routePaint;
    private final Paint rankPaint;
    private final Paint line0Paint;
    private final Paint line1Paint;
    private final Paint line1rankPaint;
    private final Paint line2Paint;
    private final Paint line3Paint;
    private final Paint linevPaint;
    int renderTextureId;
    int frameBufferId;
    private Map<String, LabelContent> currentLabelContents;
    private GLMatrix mTmpMatrix = new GLMatrix();

    private List<FormationContext> fcs0;
    private List<FormationContext> fcs1;
    private Collection<FormationContext> currentFormationContexts;
    private Object fcSwapLockObj;

    private AltitudeStretcher altitudeStretcher = new AltitudeStretcher();

    public OgiqvoCubeLabelRenderer() {
        super();

        this.fcSwapLockObj = new Object();

        // current-formation-contexts double buffer
        this.fcs0 = new ArrayList<>();
        this.fcs1 = new ArrayList<>();
        this.currentFormationContexts = this.fcs0;

        // Used to generate text as texture
        mCanvas = CanvasAdapter.newCanvas();

        framePaint = CanvasAdapter.newPaint();
        framePaint.setStyle(Paint.Style.STROKE);
        framePaint.setStrokeWidth(1);
        framePaint.setColor(0xff000000);

        routePaint = CanvasAdapter.newPaint();
        routePaint.setStyle(Paint.Style.FILL);

        rankPaint = CanvasAdapter.newPaint();
        rankPaint.setStyle(Paint.Style.STROKE);
        rankPaint.setStrokeWidth(1);
        rankPaint.setColor(0xff000000);

        line0Paint = CanvasAdapter.newPaint();
        line0Paint.setTextAlign(Paint.Align.LEFT);
        line0Paint.setTextSize(ROW0_FONT_SIZE);
        line0Paint.setColor(0xff000000);
        line0Paint.setTypeface(Paint.FontFamily.HELVETICA, Paint.FontStyle.NORMAL);
        row0_descent = line0Paint.getFontDescent();
        row0_height = line0Paint.getFontHeight() - row0_descent;

        line1Paint = CanvasAdapter.newPaint();
        line1Paint.setTextAlign(Paint.Align.LEFT);
        line1Paint.setTextSize(ROW1_FONT_SIZE);
        line1Paint.setColor(0xff000000);
        line1Paint.setTypeface(Paint.FontFamily.HELVETICA, Paint.FontStyle.NORMAL);
        row1_descent = line1Paint.getFontDescent();
        row1_height = line1Paint.getFontHeight() - row1_descent;

        line1rankPaint = CanvasAdapter.newPaint();
        line1rankPaint.setTextAlign(Paint.Align.LEFT);
        line1rankPaint.setTextSize(ROW1RANK_FONT_SIZE);
        line1rankPaint.setColor(0xff000000);
        line1rankPaint.setTypeface(Paint.FontFamily.HELVETICA, Paint.FontStyle.NORMAL);
        row1rank_descent = line1rankPaint.getFontDescent();
        row1rank_height = line1rankPaint.getFontHeight() - row1rank_descent;

        line2Paint = CanvasAdapter.newPaint();
        line2Paint.setTextAlign(Paint.Align.LEFT);
        line2Paint.setTextSize(ROW2_FONT_SIZE);
        line2Paint.setColor(0xff000000);
        line2Paint.setTypeface(Paint.FontFamily.HELVETICA, Paint.FontStyle.BOLD);
        row2_descent = line2Paint.getFontDescent();
        row2_height = line2Paint.getFontHeight() - row2_descent;

        line3Paint = CanvasAdapter.newPaint();
        line3Paint.setTextAlign(Paint.Align.RIGHT);
        line3Paint.setTextSize(ROW3_FONT_SIZE);
        line3Paint.setColor(0xff000000);
        line3Paint.setTypeface(Paint.FontFamily.HELVETICA, Paint.FontStyle.NORMAL);
        row3_descent = line3Paint.getFontDescent();
        row3_height = line3Paint.getFontHeight() - row3_descent;

        linevPaint = CanvasAdapter.newPaint();
        linevPaint.setTextAlign(Paint.Align.LEFT);
        linevPaint.setTextSize(ROWV_FONT_SIZE);
        linevPaint.setColor(0xff000000);
        linevPaint.setTypeface(Paint.FontFamily.HELVETICA, Paint.FontStyle.NORMAL);
        rowv_descent = linevPaint.getFontDescent();
        rowv_height = linevPaint.getFontHeight() - rowv_descent;

        planeTexCoordBuffer = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();

        float u = Tile.SIZE / 32; // cube unit
        float minu = u * 0.4f;
        float maxu = u * 0.6f;
        float[] planeVertices = {
                -u, minu, 0,
                -u, maxu, 0,
                u, minu, 0,
                u, maxu, 0
        };
        planeVerticesBuffer = ByteBuffer.allocateDirect(planeVertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        planeVerticesBuffer.put(planeVertices).position(0);
    }

    public void notifyNewAltitudeStretcher(AltitudeStretcher altitudeStretcher) {
        synchronized (altitudeStretcher) {
            this.altitudeStretcher = altitudeStretcher;
        }
    }

    @Override
    public boolean setupOnGLThread() {
        super.setupOnGLThread();

        textureShader = new BitmapBucket.Shader("texture_alpha");
        this.setupTextTexture();

        currentLabelContents = new HashMap<>();

        return true;
    }

    private void setupTextTexture() {
        IntBuffer buf = MapRenderer.getIntBuffer(1);

        // Create frame buffer
        gl.genFramebuffers(1, buf);
        frameBufferId = buf.get(0);
        gl.bindFramebuffer(GL.FRAMEBUFFER, frameBufferId);
        log.debug("Created (texture transferring) frame buffer {}", frameBufferId);

        // Create and setup texture buffers
        buf.clear();
        gl.genTextures(1, buf);
        renderTextureId = buf.get(0);
        log.debug("Created (buffered) texture buffer {}", renderTextureId);

        gl.bindTexture(GL.TEXTURE_2D, renderTextureId);
        gl.texImage2D(GL.TEXTURE_2D, 0,
                GL.RGBA, TEXTURE_WIDTH, TEXTURE_HEIGHT, 0, GL.RGBA,
                GL.UNSIGNED_BYTE, null); // Passing null will let it point the frame buffer
        GLUtils.setTextureParameter(
                GL.LINEAR,
                GL.LINEAR,
                GL.CLAMP_TO_EDGE,
                GL.CLAMP_TO_EDGE);

        // Create depth render buffer
        buf.clear();
        gl.genRenderbuffers(1, buf);
        int depthRenderbuffer = buf.get(0);

        gl.bindRenderbuffer(GL.RENDERBUFFER, depthRenderbuffer);
        gl.renderbufferStorage(GL.RENDERBUFFER,
                GL.DEPTH_COMPONENT16,
                TEXTURE_WIDTH, TEXTURE_HEIGHT);
        gl.framebufferRenderbuffer(GL.FRAMEBUFFER,
                GL.DEPTH_ATTACHMENT,
                GL.RENDERBUFFER,
                depthRenderbuffer);

        // Finally, configure our frame buffer
        gl.framebufferTexture2D(GL.FRAMEBUFFER,
                GL.COLOR_ATTACHMENT0,
                GL.TEXTURE_2D,
                renderTextureId, 0);

        // Check if framebuffer is ok
        int status = gl.checkFramebufferStatus(GL.FRAMEBUFFER);
        if (status != GL.FRAMEBUFFER_COMPLETE) {
            log.error("invalid framebuffer! " + status);
            return;
        }

        gl.bindFramebuffer(GL.FRAMEBUFFER, 0);
        gl.bindTexture(GL.TEXTURE_2D, 0);

        log.debug("Frame buffers & texture buffers are prepared properly!");
    }

    List<Queue<FormationContext>> fcCaches = new ArrayList<>();

    private Queue<FormationContext> fcqForCarCount(int carCount) {
        while (fcCaches.size() < carCount) {
            fcCaches.add(new ConcurrentLinkedQueue<FormationContext>());
        }
        return fcCaches.get(carCount - 1);
    }


    public void safelyReviseFormationContextsBuffer(Iterable<FormationContext> newFcs) {
        List<FormationContext> nextFcs;
        synchronized (this.fcSwapLockObj) {
            if (this.currentFormationContexts == this.fcs0) {
                nextFcs = fcs1;
            } else {
                nextFcs = fcs0;
            }

            // Previous FCs might be touched by GL thread.
            // Next FCs is not touched, so can safely be modified.

            // Release previous fc
            for (FormationContext fc : nextFcs) {
                int carCount = fc.getCarCount();
                Queue<FormationContext> fcq = this.fcqForCarCount(carCount);
                fcq.add(fc);
            }

            nextFcs.clear();

            for (FormationContext fc : newFcs) {
                assert fc != null;

                Formation formation = fc.getFormation();

                int carCount = formation.getCars().size();
                Queue<FormationContext> fcq = this.fcqForCarCount(carCount);

                FormationContext nextLocalFc;
                if (fcq.isEmpty()) {
                    nextLocalFc = new FormationContext(formation);
                } else {
                    nextLocalFc = fcq.poll();
                }

                fc.deepCopyBogieLnglatsTo(nextLocalFc);
                fc.deepCopyIsAvailableTo(nextLocalFc);
                fc.deepCopyBogieAltitudesTo(nextLocalFc);
                com.ogiqvo.lib.bean.instruction.FromServer instruction = fc.getCurrentInstruction();
                com.ogiqvo.lib.bean.wait.FromServer wait = fc.getCurrentWait();
                nextLocalFc.setCurrentInstruction(instruction);
                nextLocalFc.setCurrentWait(wait);

                Car car = formation.getCars().get(0);
                Carmodel carmodel = car.getCarmodel();
                nextLocalFc.getCarHeightsUntilCenter()[0] = carmodel.getWheelHeight() + carmodel.getHeight() / 2.0;

                nextFcs.add(nextLocalFc);
            }
            Collections.sort(nextFcs);

            this.currentFormationContexts = nextFcs;
        }
    }

    List<LabelContent> labelContents = new ArrayList<>();

    @Override
    public void renderOnGLThread(GLViewport v) {
        GLState.blend(true);
        GLState.test(false, false);

        GLState.bindElementBuffer(0);
        GLState.bindVertexBuffer(0);

        MapTileJob[] tiles = drawingTileSet.tileJobs;
        MapTileJob tile = tiles[0];

        int z = tile.zoomLevel;
        MapPosition pos = v.pos;
        double tileScale = Tile.SIZE * v.pos.scale;
        float heightScale = (float) (v.pos.scale / (1 << z));

        labelContents.clear();
        synchronized (this.fcSwapLockObj) {
            for (FormationContext formationContext : this.currentFormationContexts) {
                Trip trip = null;
                com.ogiqvo.lib.bean.instruction.FromServer instruction = null;
                com.ogiqvo.lib.bean.wait.FromServer wait = null;

                if (formationContext.getCurrentInstruction() != null) {
                    instruction = formationContext.getCurrentInstruction();
                    trip = instruction.getTrip();
                } else if (formationContext.getCurrentWait() != null) {
                    wait = formationContext.getCurrentWait();
                    trip = wait.getTrip();
                }

                if (trip != null) {
                    // Calculate translation
                    Lnglat firstLnglat = formationContext.getBogieLnglats()[0];
                    if (firstLnglat == null) {
                        continue;
                    }
                    double originalAltitude = formationContext.getCarHeightsUntilCenter()[0] + formationContext.getBogieAltitudes()[0];
                    double stretchedAltitude = this.altitudeStretcher.getStretchedAltitude(originalAltitude);
                    float mapAffineX = getMapAffineX(firstLnglat.get4326lng(), tileScale, pos);
                    float mapAffineY = getMapAffineY(firstLnglat.get4326lat(), tileScale, pos);
                    float mapAffineZ = heightScale * (float) stretchedAltitude;

                    v.mvp.setIdentity();
                    mTmpMatrix.setTranslation(mapAffineX, mapAffineY, mapAffineZ);
                    v.mvp.multiplyLhs(mTmpMatrix);
                    v.mvp.multiplyLhs(v.viewproj);

                    float[] coord = new float[]{0, 0, 0};
                    v.mvp.prj(coord); // Project

                    if (coord[0] > 1 || coord[0] < -1 || coord[1] > 1 || coord[1] < -1) {
                        continue;
                    }

                    double xrate = coord[0] * 0.5 + 0.5;
                    double yrate = coord[1] * 0.5 + 0.5;
                    double xpos = v.getWidth() * xrate;
                    double ypos = v.getHeight() * yrate;

                    // Build label context
                    LabelContent lc = new LabelContent();
                    lc.trip = trip;
                    lc.point = new Point(xpos, ypos);
                    lc.instruction = instruction;
                    lc.wait = wait;

//                    lc.alpha = this.altitudeStretcher.getStretchedAlpha(originalAltitude);
                    labelContents.add(lc);
                }
            }

            boolean isTextureRefreshNeeded = false;
            for (LabelContent lc : labelContents) {
                String lcHash = lc.toString();
                if (!currentLabelContents.containsKey(lcHash)) {
                    isTextureRefreshNeeded = true;
                    break;
                }
            }

            // Generate texture
            GLState.bindTex2D(renderTextureId);
            if (isTextureRefreshNeeded) {
                TextureItem t = pool.get();
                t.bitmap.eraseColor(0xffffffff);
                mCanvas.setBitmap(t.bitmap);
                textureYPointOffset = 0;
                textureXPointOffset = 0;
                textureFoundMaxWidthInCurrentColumn = 0;
                currentLabelContents.clear();
                for (LabelContent lc : labelContents) {
                    String lcHash = lc.toString();
                    this.generateLabelTexture(lc, mCanvas);
                    currentLabelContents.put(lcHash, lc);
                }
                t.bitmap.uploadToTexture(true);
            }

            // Draw sprites
            for (LabelContent lc : labelContents) {
                String lcHash = lc.toString();
                LabelContent lcn = currentLabelContents.get(lcHash);
                lcn.point = lc.point;
//                lcn.alpha = lc.alpha;
                this.renderLabel(lcn, lcn.width, lcn.height, lcn.xOffset, lcn.yOffset, v);
            }
        }
    }

    class LabelContent {
        public Point point;
        public Trip trip;
        public com.ogiqvo.lib.bean.wait.FromServer wait;
        public com.ogiqvo.lib.bean.instruction.FromServer instruction;
        public double width;
        public double height;
        public int yOffset;
        public int xOffset;

//        public float alpha;

        private String strCache;

        @Override
        public String toString() {
            if (strCache == null) {
                StringBuilder sb = new StringBuilder();
                sb.append(trip.getCid());
                if (instruction != null) {
                    sb.append(instruction.getCid());
                }
                if (wait != null) {
                    sb.append(wait.getCid());
                }
                strCache = sb.toString();
            }
            return strCache;
        }
    }

    private float[] textCoords = new float[8];
    float[] vertices = new float[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    short[] indices = new short[]{0, 1, 2, 3};
    FloatBuffer verticesBuffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    ShortBuffer indicesBuffer = ByteBuffer.allocateDirect(indices.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();

    private void generateLabelTexture(LabelContent labelContent, Canvas canvas) {
        // Build line 0
        String line0;
        if (labelContent.instruction != null) {
            line0 = "";
        } else {
            line0 = "";
        }

        // Build line 1
        StringBuilder sb = new StringBuilder();
        Trip trip = labelContent.trip;
        Route route = trip.getRoute();
        if (trip.getExplicitName() != null && !trip.getExplicitName().equals("")) {
            sb.append(trip.getExplicitName());
        } else {
            sb.append(route.getShortName());
            sb.append(" ");
            sb.append(route.getLongName());
        }
        String line1 = sb.toString();

        // Build line 1 rank
        String line1rank;
        if (trip.getExplicitName() != null && !trip.getExplicitName().equals("")) {
            line1rank = "";
        } else {
            line1rank = trip.getRankName().toUpperCase();
        }

        // Build line 2
        String line2 = trip.getHeadsign();

        // Build line3
        String line3 = trip.getCid();

        // Build line-vertical
        String linev = "";
        if (labelContent.instruction != null) {
            int jstSeconds = (int) (labelContent.instruction.lastTime()) + 32400;
            int hours = jstSeconds / 3600;
            int minutes = (jstSeconds - hours * 3600) / 60;
            linev = hours + ":" + ((minutes >= 10 ? "" : "0") + minutes);
        }

        // Calculate each line's width (height is already calculated)
        double line0width = line0Paint.measureText(line0);
        double line1width = line1Paint.measureText(line1);
        double line1rankWidth = line1rankPaint.measureText(line1rank);
        double line2width = line2Paint.measureText(line2);
        double line3width = line3Paint.measureText(line3);
        double linevwidth = linevPaint.measureText(linev);

        // Calculate x-delimiters
        float xd0 = 0;
        float xd1 = xd0 + LINE_COLOR_WIDTH + 5; // left end + line color bar
        float xd2 = (float) (xd1 + line1width) + 3; // line name end
        float xd31 = (float) (xd2 + line1rankWidth); // rank name end
        float xd32 = (float) (xd1 + line2width); // headsign end
        float xd3 = (xd31 > xd32) ? xd31 : xd32;
        float xd4 = xd3 + rowv_height;

        // Calculate y-delimiters
        float yd0 = 0;
        float yd1 = yd0 + row0_height - 7;
        float yd2 = yd1 + row1_height;
        float yd3 = yd2 + row2_height;
        float yd4 = yd3 + row3_height - 4;

        // Allocating texture region
        double textureHeight = yd4;
        double textureWidth = xd4;

        // Draw to canvas
        int routeColor = 0;
        if (!route.is32set()) {
            String routeColorStr = route.getColor();
            routeColor = Color.parseColor("#" + routeColorStr);
            route.setColor32(routeColor);
            route.setIs32set(true);
        } else {
            routeColor = route.getColor32();
        }

        routePaint.setColor(routeColor);
        canvas.drawRectangle(xd0 + textureXPointOffset, yd0 + textureYPointOffset, xd0 + LINE_COLOR_WIDTH + textureXPointOffset, yd4 + textureYPointOffset, routePaint);

        canvas.drawRectangle(xd0 + textureXPointOffset, yd0 + textureYPointOffset, xd4 + textureXPointOffset, yd4 + textureYPointOffset - 1, framePaint);
        canvas.drawText(line0, xd0 + textureXPointOffset, yd0 + textureYPointOffset + row0_height, line0Paint, null);
        canvas.drawText(line1, xd1 + textureXPointOffset, yd1 + textureYPointOffset + row1_height, line1Paint, null);
        if (line1rank != "") {
            int rankColor = 0xffffffff;
            int rankTextColor = 0xff000000;
            if (!trip.is32set()) {
                if (trip.getRankColor() != null) {
                    rankColor = Color.parseArgbColor(trip.getRankColor());
                    trip.setRankColor32(rankColor);
                }
                if (trip.getRankTextColor() != null) {
                    rankTextColor = Color.parseArgbColor(trip.getRankTextColor());
                    trip.setRankTextColor32(rankTextColor);
                }
                trip.setIs32set(true);
            } else {
                rankColor = trip.getRankColor32();
                rankTextColor = trip.getRankTextColor32();
            }

            rankPaint.setStyle(Paint.Style.FILL);
            rankPaint.setColor(rankColor);
            canvas.drawRectangle(xd2 - 2 + textureXPointOffset, yd1 + textureYPointOffset, xd31 + 2 + textureXPointOffset, yd2 + textureYPointOffset, rankPaint);

            rankPaint.setStyle(Paint.Style.STROKE);
            rankPaint.setColor(rankTextColor);
            canvas.drawRectangle(xd2 - 2 + textureXPointOffset, yd1 + textureYPointOffset, xd31 + 2 + textureXPointOffset, yd2 + textureYPointOffset, rankPaint);

            line1rankPaint.setColor(rankTextColor);
            canvas.drawText(line1rank, xd2 + textureXPointOffset, yd1 + textureYPointOffset + row1rank_height + 2, line1rankPaint, null);
        }
        canvas.drawText(line2, xd1 + textureXPointOffset, yd2 + textureYPointOffset + row2_height, line2Paint, null);
//        canvas.drawText(line3, xd3, yd3 + textureYPointOffset + row3_height, line3Paint, null);
//        canvas.drawText(linev, xd0, yd0, linevPaint, null);

        labelContent.width = textureWidth;
        labelContent.height = textureHeight;
        labelContent.xOffset = textureXPointOffset;
        labelContent.yOffset = textureYPointOffset;

        if (textureWidth > textureFoundMaxWidthInCurrentColumn) {
            textureFoundMaxWidthInCurrentColumn = (int) textureWidth;
        }

        textureYPointOffset += textureHeight;
        if (textureYPointOffset > TEXTURE_HEIGHT) {
            textureYPointOffset = 0;
            textureXPointOffset += textureFoundMaxWidthInCurrentColumn;
            textureFoundMaxWidthInCurrentColumn = 0;
        }
    }

    private void renderLabel(LabelContent labelContext, double width, double height, int xOffset, int yOffset, GLViewport v) {
        textureShader.useProgram();

//        gl.uniform1f(textureShader.uAlpha, labelContext.alpha);
        gl.uniform1f(textureShader.uAlpha, 1.0f);

        v.mvp.setIdentity();
        v.mvp.setAsUniform(textureShader.uMVP);

        // Set texture ranges
        float minX = (float) xOffset / (float) TEXTURE_WIDTH;
        float maxX = (float) ((xOffset + width) / TEXTURE_WIDTH);
        float minY = (float) yOffset / (float) TEXTURE_HEIGHT;
        float maxY = (float) ((yOffset + height) / TEXTURE_HEIGHT);
        textCoords[0] = minX;
        textCoords[1] = maxY;
        textCoords[2] = minX;
        textCoords[3] = minY;
        textCoords[4] = maxX;
        textCoords[5] = maxY;
        textCoords[6] = maxX;
        textCoords[7] = minY;

        // Set vertex ranges
        float pointxmin = (float) (labelContext.point.x - width / 2);
        float pointxmax = (float) (labelContext.point.x + width / 2);
        float pointymin = (float) (labelContext.point.y - height / 2);
        float pointymax = (float) (labelContext.point.y + height / 2);
        float xmin = (float) ((pointxmin / v.getWidth()) * 2.0 - 1.0);
        float xmax = (float) ((pointxmax / v.getWidth()) * 2.0 - 1.0);
        float ymin = (float) ((pointymin / v.getHeight()) * 2.0 - 1.0);
        float ymax = (float) ((pointymax / v.getHeight()) * 2.0 - 1.0);

        vertices[0] = xmin;
        vertices[1] = ymin;
        vertices[3] = xmin;
        vertices[4] = ymax;
        vertices[6] = xmax;
        vertices[7] = ymin;
        vertices[9] = xmax;
        vertices[10] = ymax;

        verticesBuffer.put(vertices).position(0);
        indicesBuffer.put(indices).position(0);

        planeTexCoordBuffer.put(textCoords).position(0);
        gl.vertexAttribPointer(textureShader.aTexCoord, 2, GL.FLOAT, false, 0, planeTexCoordBuffer);

        gl.vertexAttribPointer(textureShader.aPos, 3, GL.FLOAT, false, 0, verticesBuffer); // 3 = 3-dimensional
        gl.drawElements(GL.TRIANGLE_STRIP, indices.length, GL.UNSIGNED_SHORT, indicesBuffer);
    }
}
