package com.ogiqvo;

/**
 * Created by xor on 15/09/08.
 */
public class TriangleAndLineVboIbo {
    boolean isVboIboIdSet = false;

    float[] vbo;
    int vboid;

    short[] ibo; // index 0 is always triangle ibo, 1,2 ... is for line ibo.
    int[] iboPointOffsets;
    int iboid;

    public TriangleAndLineVboIbo() {
        isVboIboIdSet = false;
    }

    public boolean getIsVboIboIdSet() {
        return isVboIboIdSet;
    }

    public void setVboIboid(int vboid, int iboid) {
        this.vboid = vboid;
        this.iboid = iboid;
        isVboIboIdSet = true;
    }

    public float[] getVbo() {
        return vbo;
    }

    public void setVbo(float[] vbo) {
        this.vbo = vbo;
    }

    public int getVboid() {
        return vboid;
    }

    public short[] getIbo() {
        return ibo;
    }

    public void setIbo(short[] ibo) {
        this.ibo = ibo;
    }

    public int[] getIboPointOffsets() {
        return iboPointOffsets;
    }

    public void setIboPointOffsets(int[] iboPointOffsets) {
        this.iboPointOffsets = iboPointOffsets;
    }

    public int getIboid() {
        return iboid;
    }
}
