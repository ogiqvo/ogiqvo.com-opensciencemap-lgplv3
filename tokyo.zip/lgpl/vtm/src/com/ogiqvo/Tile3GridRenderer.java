package com.ogiqvo;

import org.oscim.renderer.BucketRenderer;
import org.oscim.renderer.GLViewport;

/**
 * Created by xor on 15/05/18.
 */
public class Tile3GridRenderer extends BucketRenderer {

    private int curX, curY, curZ;

    @Override
    public void updateOnGLThread(GLViewport v) {
		/* scale coordinates relative to current 'zoom-level' to
		 * get the position as the nearest tile coordinate */
        int z = 1 << v.pos.zoomLevel;
        int x = (int) (v.pos.x * z);
        int y = (int) (v.pos.y * z);

		/* updateOnGLThread buckets when map moved by at least one tile */
        if (x == curX && y == curY && z == curZ)
            return;

        curX = x;
        curY = y;
        curZ = z;

        mapPosition.copy(v.pos);
        mapPosition.x = (double) x / z;
        mapPosition.y = (double) y / z;
        mapPosition.scale = z;

        if (!getIsReadyToRender())
            compile();
    }
}
