package com.ogiqvo;

import com.ogiqvo.lib.bean.Bezier;
import com.ogiqvo.lib.bean.Platform;

import org.oscim.layers.tile.MapTileJob;
import org.oscim.layers.tile.TileRenderer;
import org.oscim.renderer.GLMatrix;
import org.oscim.renderer.GLViewport;
import org.oscim.renderer.bucket.BitmapBucket;
import org.oscim.renderer.bucket.TextureItem;
import org.oscim.utils.RTree;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.FloatBuffer;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by xor on 05/04/15.
 */
public class OgiqvoTileRenderer extends TileRenderer {
    static final Logger log = LoggerFactory.getLogger(OgiqvoTileRenderer.class);

    private PrimitiveShader primitiveShader;
    private BitmapBucket.Shader textureShader;

    private Map<Bezier, MapTileJob> foundBeziersAndItsTile = new ConcurrentHashMap<>();
    private Map<Platform, MapTileJob> foundPlatformsAndItsTile = new ConcurrentHashMap<>();
    private Collection<Platform> foundPlatforms;
    private Collection<Platform> foundPlatformsTmp;

    private RTree<Platform> foundPlatformSpatialIndex;

    private GLMatrix mTmpMatrix = new GLMatrix();

    public final static int TEXTURE_HEIGHT = 1024;
    public final static int TEXTURE_WIDTH = 256;
    public final static float TEXT_HEIGHT = 20;
    final static int POOL_FILL = 4;

//    protected final Canvas mCanvas;
    public final static TextureItem.TexturePool pool = new TextureItem.TexturePool(POOL_FILL,
            TEXTURE_WIDTH,
            TEXTURE_HEIGHT);
//    private final Paint textPaint;
    int renderTextureId;
    int frameBufferId;

    protected FloatBuffer planeTexCoordBuffer;

    private Object lastRequestedViewPortLockObj = new Object();
    private GLViewport lastRequestedViewPort;

    public OgiqvoTileRenderer() {
        super();

//        foundPlatforms = new HashSet<>();
//        foundPlatformsTmp = new HashSet<>();
//        foundPlatformSpatialIndex = new RTree<>();
//
//        // Used to generate text as texture
//        mCanvas = CanvasAdapter.newCanvas();
//        textPaint = CanvasAdapter.newPaint();
//        textPaint.setTextAlign(Paint.Align.LEFT);
//        textPaint.setTextSize(TEXT_HEIGHT-2);
//        textPaint.setColor(0xffffffff);
//        textPaint.setTypeface(Paint.FontFamily.SANS_SERIF, Paint.FontStyle.NORMAL);
//
//        float u = Tile.SIZE / 32; // cube unit
//        float minu = u * 0.4f;
//        float maxu = u * 0.6f;
//        float[] planeVertices = {
//                -u, minu, 0,
//                -u, maxu, 0,
//                u, minu, 0,
//                u, maxu, 0
//        };
//        planeVerticesBuffer = ByteBuffer.allocateDirect(planeVertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
//        planeVerticesBuffer.put(planeVertices).position(0);
//
//        planeTexCoordBuffer = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    @Override
    public boolean setupOnGLThread() {
        super.setupOnGLThread();

        primitiveShader = new PrimitiveShader("base_shader");
//        textureShader = new BitmapBucket.Shader("texture_alpha");

//        this.setupTextTexture();

        return true;
    }

//    private void setupTextTexture() {
//        IntBuffer buf = MapRenderer.getIntBuffer(1);
//
//        // Create frame buffer
//        gl.genFramebuffers(1, buf);
//        frameBufferId = buf.get(0);
//        gl.bindFramebuffer(GL.FRAMEBUFFER, frameBufferId);
//        log.debug("Created (texture transferring) frame buffer {}", frameBufferId);
//
//        // Create and setup texture buffers
//        buf.clear();
//        gl.genTextures(1, buf);
//        renderTextureId = buf.get(0);
//        log.debug("Created (buffered) texture buffer {}", renderTextureId);
//
//        gl.bindTexture(GL.TEXTURE_2D, renderTextureId);
//        gl.texImage2D(GL.TEXTURE_2D, 0,
//                GL.RGBA, TEXTURE_WIDTH, TEXTURE_HEIGHT, 0, GL.RGBA,
//                GL.UNSIGNED_BYTE, null); // Passing null will let it point the frame buffer
//        GLUtils.setTextureParameter(
//                GL.LINEAR,
//                GL.LINEAR,
//                GL.CLAMP_TO_EDGE,
//                GL.CLAMP_TO_EDGE);
//
//        // Create depth render buffer
//        buf.clear();
//        gl.genRenderbuffers(1, buf);
//        int depthRenderbuffer = buf.get(0);
//
//        gl.bindRenderbuffer(GL.RENDERBUFFER, depthRenderbuffer);
//        gl.renderbufferStorage(GL.RENDERBUFFER,
//                GL.DEPTH_COMPONENT16,
//                TEXTURE_WIDTH, TEXTURE_HEIGHT);
//        gl.framebufferRenderbuffer(GL.FRAMEBUFFER,
//                GL.DEPTH_ATTACHMENT,
//                GL.RENDERBUFFER,
//                depthRenderbuffer);
//
//        // Finally, configure our frame buffer
//        gl.framebufferTexture2D(GL.FRAMEBUFFER,
//                GL.COLOR_ATTACHMENT0,
//                GL.TEXTURE_2D,
//                renderTextureId, 0);
//
//        // Check if framebuffer is ok
//        int status = gl.checkFramebufferStatus(GL.FRAMEBUFFER);
//        if (status != GL.FRAMEBUFFER_COMPLETE) {
//            log.error("invalid framebuffer! " + status);
//            return;
//        }
//
//        gl.bindFramebuffer(GL.FRAMEBUFFER, 0);
//        gl.bindTexture(GL.TEXTURE_2D, 0);
//
//        log.debug("Frame buffers & texture buffers are prepared properly!");
//
//    }

    @Override
    public void renderOnGLThread(GLViewport v) {
//        synchronized (lastRequestedViewPortLockObj) {
//            lastRequestedViewPort = v; // lastRequestedViewPort will be shared between GL thread and main thread, so it should be locked
//        }
//
//        GLState.blend(true);
//
//        GLState.test(false, false);
//
//        primitiveShader.set(v);
//
//        foundBeziersAndItsTile.clear();
//        foundPlatformsAndItsTile.clear();
//
//        foundPlatformsTmp.clear();
//
//        MapTileJob[] tiles = drawingTileSet.tileJobs;
//
//        for (int i = 0; i < tiles.length; i++) {
//            MapTileJob tile = tiles[i];
//            if (tile == null) {
//                continue;
//            }
//            if (tile.isVisible && tile.containsState(READY)) {
//                // Gather beziers which is required to addRenderingRequestToMainThread
//
//		        /* use holder proxy when it is set */
//                OgiqvoTileBucket bucket = (OgiqvoTileBucket) ((tile.holder == null)
//                        ? tile.getBuckets()
//                        : tile.holder.getBuckets());
//                if (bucket == null) {
//                    continue;
//                }
//
//                Pool.PerCommitTile commitTile = bucket.getTile();
//                if (commitTile == null) {
//                } else if (commitTile.referringBeziers == null) {
//                } else {
//                    for (Bezier bezier : commitTile.referringBeziers) {
//                        if (foundBeziersAndItsTile.containsKey(bezier)) {
//                            continue;
//                        }
//                        foundBeziersAndItsTile.put(bezier, tile);
//                    }
//                    for (Platform platform : commitTile.referringPlatforms) {
//                        if (foundPlatformsAndItsTile.containsKey(platform)) {
//                            continue;
//                        }
//                        foundPlatformsAndItsTile.put(platform, tile);
//                        foundPlatformsTmp.add(platform);
//                    }
//                }
//            } else if (!tile.isVisible) {
//            } else {
//            }
//        }
//
//        // Render beziers
//        GLState.bindElementBuffer(0);
//        GLState.bindVertexBuffer(0);
//        for (Map.Entry<Bezier, MapTileJob> kv : foundBeziersAndItsTile.entrySet()) {
//            Bezier bezier = kv.getKey();
//            MapTileJob tile = kv.getValue();
//            drawBezierObjOnGLThread(v, bezier, tile);
//        }
//
//        if (!foundPlatformsTmp.equals(foundPlatforms)) {
//            Collection<Platform> pt = foundPlatformsTmp;
//            foundPlatformsTmp = foundPlatforms;
//            foundPlatforms = pt;
//
//            foundPlatformSpatialIndex.clear();
//            for (Platform p : foundPlatforms) {
//                Lnglat ll = p.getLnglat();
//                ProjCoordinate ll3857 = ll.getLnglat3857();
//                Box b = new Box(ll3857.x, ll3857.y, ll3857.x, ll3857.y);
//                foundPlatformSpatialIndex.insert(b, p);
//            }
//        }
//
//        // Render platforms
//        TextureItem t = pool.get();
//        t.bitmap.eraseColor(0xff333333);
//        mCanvas.setBitmap(t.bitmap);
//
//        int stationIndex = 0;
//        for (Map.Entry<Platform, MapTileJob> kv : foundPlatformsAndItsTile.entrySet()) {
//            Platform platform = kv.getKey();
//            if (this.renderTextToBitmap(platform, stationIndex)) {
//                stationIndex++;
//            }
//        }
//
//        if (stationIndex > 0) {
//            GLState.bindTex2D(renderTextureId);
//            t.bitmap.uploadToTexture(true);
//        }
//
//        stationIndex = 0;
//        for (Map.Entry<Platform, MapTileJob> kv : foundPlatformsAndItsTile.entrySet()) {
//            Platform platform = kv.getKey();
//            MapTileJob tile = kv.getValue();
//            drawPlatformObjOnGLThread(v, stationIndex, platform, tile);
//            stationIndex++;
//        }
//
//        gl.bindFramebuffer(GL.FRAMEBUFFER, 0);
//        gl.bindTexture(GL.TEXTURE_2D, 0);
    }

//    private boolean renderTextToBitmap(Platform platform, int yIndex) {
//        if(platform.getName().equals("")){return false;}
//        StringBuilder sb = new StringBuilder();
//        sb.append(platform.getName());
//        mCanvas.drawText(sb.toString(), 2, 20 * (yIndex + 1) - 2, textPaint, null);
//        return true;
//    }

    private void drawBezierObjOnGLThread(GLViewport v, Bezier bezierObj, MapTileJob tile) {
//        MapPosition pos = v.pos;
//
//        // Calculate mapAffineX/Y transport from viewport position and model location
//        double tileScale = Tile.SIZE * v.pos.scale;
//
//        Gradient g0 = bezierObj.getGradient0();
//        Gradient g3 = bezierObj.getGradient3();
//        double altitude0 = g0.getAltitude();
//        double altitude3 = g3.getAltitude();
//        double altitude1 = (altitude0 * 2.0 + altitude3) / 3.0;
//        double altitude2 = (altitude3 * 2.0 + altitude0) / 3.0;
//
//        float x0 = (float) ((MercatorProjection.longitudeToX(bezierObj.getGradient0().getLnglat().get4326lng()) - pos.x) * tileScale);
//        float y0 = (float) ((MercatorProjection.latitudeToY(bezierObj.getGradient0().getLnglat().get4326lat()) - pos.y) * tileScale);
//        float x1 = (float) ((MercatorProjection.longitudeToX(bezierObj.getLnglat1().get4326lng()) - pos.x) * tileScale);
//        float y1 = (float) ((MercatorProjection.latitudeToY(bezierObj.getLnglat1().get4326lat()) - pos.y) * tileScale);
//        float x2 = (float) ((MercatorProjection.longitudeToX(bezierObj.getLnglat2().get4326lng()) - pos.x) * tileScale);
//        float y2 = (float) ((MercatorProjection.latitudeToY(bezierObj.getLnglat2().get4326lat()) - pos.y) * tileScale);
//        float x3 = (float) ((MercatorProjection.longitudeToX(bezierObj.getGradient3().getLnglat().get4326lng()) - pos.x) * tileScale);
//        float y3 = (float) ((MercatorProjection.latitudeToY(bezierObj.getGradient3().getLnglat().get4326lat()) - pos.y) * tileScale);
//
//        float[] bezierVertices = {
//                x0, y0, (float) altitude0,
//                x1, y1, (float) altitude1,
//                x2, y2, (float) altitude2,
//                x3, y3, (float) altitude3
//        };
//        FloatBuffer bezierVerticesBuffer = ByteBuffer.allocateDirect(bezierVertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
//        bezierVerticesBuffer.put(bezierVertices).position(0);
//
//        short[] bezierIndices = {
//                0, 1, 2, 3
//        };
//        ShortBuffer bezierIndicesBuffer = ByteBuffer.allocateDirect(bezierIndices.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
//        bezierIndicesBuffer.put(bezierIndices).position(0);
//
//        // Calculate scale from viewport scale
//        int z = tile.zoomLevel;
//
//        // Set to trans-scale matrix
//        v.mvp.setIdentity();
//
//        // Fix-ups before drawing elements
//        v.mvp.multiplyLhs(v.viewproj);
//        v.mvp.setAsUniform(primitiveShader.uMVP);
//
//        // Draw model
//        GLUtils.setColor(primitiveShader.uColor, Color.GRAY, 0.7f);
//        gl.lineWidth(1);
//        gl.vertexAttribPointer(primitiveShader.aPos, 3, gl.FLOAT, false, 0, bezierVerticesBuffer);
//        gl.drawElements(gl.LINE_STRIP, 4, gl.UNSIGNED_SHORT, bezierIndicesBuffer);
    }

//    private void drawPlatformObjOnGLThread(GLViewport v, int yIndex, Platform platformObj, MapTileJob tile) {
//        if(platformObj.getName().equals("")){return;}
//
//        textureShader.useProgram();
//
//        double lon = platformObj.getLnglat().get4326lng();
//        double lat = platformObj.getLnglat().get4326lat();
//        double alt = 20; // 20m
//
//        int z = tile.zoomLevel;
//
//        MapPosition pos = v.pos;
//        double tileScale = Tile.SIZE * v.pos.scale;
//
//        // Translate
//        float heightScale = (float) (v.pos.scale / (1 << z));
//        float mapAffineX = getMapAffineX(lon, tileScale, pos);
//        float mapAffineY = getMapAffineY(lat, tileScale, pos);
//        float mapAffineZ = (float) alt / SCALE_MAGIC_NUMBER;
//
//        // Build "billboard" into v.mvp (for temporary)
//        // http://stackoverflow.com/questions/5467007/inverting-rotation-in-3d-to-make-an-object-always-face-the-camera/5487981#5487981
//        v.mvp.setIdentity();
//
//        mTmpMatrix.setTranslation(mapAffineX, mapAffineY, mapAffineZ);
//        v.mvp.multiplyLhs(mTmpMatrix);
//
//        // Projection
//        v.mvp.multiplyLhs(v.viewproj);
//
//        // Remove rotation
//        float[] m = new float[16];
//        v.mvp.get(m);
//        float xx = m[0];
//        float yx = m[4];
//        float zx = m[8];
//        float d = (float) Math.sqrt(xx * xx + yx * yx + zx * zx);
//
//        // Set diagonal values
//        v.mvp.setValue(0, d);
//        v.mvp.setValue(5, d);
//        v.mvp.setValue(10, d);
//        // Set non-diagonal values
//        v.mvp.setValue(1, 0);
//        v.mvp.setValue(2, 0);
//        v.mvp.setValue(4, 0);
//        v.mvp.setValue(6, 0);
//        v.mvp.setValue(8, 0);
//        v.mvp.setValue(9, 0);
//
//        mTmpMatrix.copy(v.mvp); // Billboard matrix inside
//
//        v.mvp.setIdentity();
//
//        float scale = 10;//1f / Tile.SIZE;
//        v.mvp.setScale(scale, scale * v.getWidth() / v.getHeight(), scale);
//        v.mvp.multiplyLhs(mTmpMatrix); // Apply billboard here
//
//        v.mvp.setAsUniform(textureShader.uMVP);
//
//        gl.uniform1f(textureShader.uAlpha, 0.9f);
//
//        GLState.bindElementBuffer(0);
//        GLState.bindVertexBuffer(0);
//
//        float minY = (TEXT_HEIGHT / (float) TEXTURE_HEIGHT * (float) yIndex);
//        float maxY = (TEXT_HEIGHT / (float) TEXTURE_HEIGHT * (float) (yIndex + 1));
//        float[] textCoords = {
//                0, maxY,
//                0, minY,
//                1, maxY,
//                1, minY
//        };
//
//        planeTexCoordBuffer.put(textCoords).position(0);
//        gl.vertexAttribPointer(textureShader.aTexCoord, 2, GL.FLOAT, false, 0, planeTexCoordBuffer);
//        gl.vertexAttribPointer(textureShader.aPos, 3, GL.FLOAT, false, 0, planeVerticesBuffer); // 3 = 3-dimensional
//        gl.drawElements(GL.TRIANGLE_STRIP, planeIndicesBufferLength, GL.UNSIGNED_SHORT, planeIndicesBuffer);
//    }
//
//    // Used when map is clicked at (x,y).
//    public void fillPlatformsInExtent(float x, float y, float minx, float maxx, float miny, float maxy, List<Platform> resultPlatforms) {
//        synchronized (lastRequestedViewPortLockObj) {
//            if (lastRequestedViewPort == null) {
//                return;
//            }
//            GeoPoint mingp = lastRequestedViewPort.fromScreenPoint(minx, miny);
//            GeoPoint maxgp = lastRequestedViewPort.fromScreenPoint(maxx, maxy);
//            ProjCoordinate mingppc = new ProjCoordinate(mingp.getLongitude(), mingp.getLatitude());
//            ProjCoordinate maxgppc = new ProjCoordinate(maxgp.getLongitude(), maxgp.getLatitude());
//
//            ProjCoordinate mingppc3857 = new ProjCoordinate();
//            Lnglat.EPSG4326to3857.transform(mingppc, mingppc3857);
//            ProjCoordinate maxgppc3857 = new ProjCoordinate();
//            Lnglat.EPSG4326to3857.transform(maxgppc, maxgppc3857);
//
//            if (mingppc3857.x > maxgppc3857.x) {
//                double dt = mingppc3857.x;
//                mingppc3857.x = maxgppc3857.x;
//                maxgppc3857.x = dt;
//            }
//            if (mingppc3857.y > maxgppc3857.y) {
//                double dt = mingppc3857.y;
//                mingppc3857.y = maxgppc3857.y;
//                maxgppc3857.y = dt;
//            }
//            Box searchBox = new Box(mingppc3857.x, mingppc3857.y, maxgppc3857.x, maxgppc3857.y);
//
//            foundPlatformSpatialIndex.search(searchBox, resultPlatforms);
//        }
//    }
}
