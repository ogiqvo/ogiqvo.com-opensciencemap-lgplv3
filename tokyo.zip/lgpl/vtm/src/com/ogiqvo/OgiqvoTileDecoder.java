package com.ogiqvo;

import com.ogiqvo.lib.Pool;
import com.ogiqvo.lib.loader.ITileLoadable;
import com.ogiqvo.lib.pool.CommitTile;

import org.oscim.tiling.ITileDataLoadCallbackable;
import org.oscim.tiling.source.ITileDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;

public class OgiqvoTileDecoder implements ITileDecoder {
    static final Logger log = LoggerFactory.getLogger(OgiqvoTileDecoder.class);
    private Pool pool;
    private String commitId;
    private ITileLoadable loader;

    public OgiqvoTileDecoder(Pool ogiqvoPool, String commitId, ITileLoadable loader) {
        this.pool = ogiqvoPool;
        this.commitId = commitId;
        this.loader = loader;
    }

    @Override
    public synchronized boolean decodeOnLoadingThread(org.oscim.core.Tile tile, ITileDataLoadCallbackable sink, InputStream is) throws IOException {
        com.ogiqvo.lib.Tile otile = new com.ogiqvo.lib.Tile();
        otile.x = tile.tileX;
        otile.y = tile.tileY;
        otile.z = tile.zoomLevel;
        CommitTile ct = new CommitTile(otile, this.commitId);
        this.loader.loadCommitTileIntoPool(ct, this.pool); // Load tile JSON from inputEventDispatcher stream and put it into pool
        Pool.PerCommitTile pct = this.pool.perCommitTileForCommitTile(ct);
        sink.setPerCommitTileOnLoadingThread(pct);

        return true;
    }
}
