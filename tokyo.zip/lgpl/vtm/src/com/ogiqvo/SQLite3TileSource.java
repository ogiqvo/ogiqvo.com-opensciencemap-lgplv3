package com.ogiqvo;

import org.oscim.tiling.TileSource;

/**
 * Created by xor on 15/11/11.
 */
public abstract class SQLite3TileSource extends TileSource {
    public SQLite3TileSource(int zoomMin, int zoomMax) {
        super(zoomMin, zoomMax);
    }

    @Override
    public OpenResult open() {
        // Since it's a local file, it always exist. Return true.
        return OpenResult.SUCCESS;
    }

    @Override
    public void close() {

    }
}
