package com.ogiqvo;

import com.ogiqvo.lib.Pool;
import com.ogiqvo.lib.loader.ITileLoadable;

import org.oscim.tiling.ITileDataSource;

/**
 * Created by xor on 05/04/15.
 */
public class SQLite3OgiqvoTileSource extends SQLite3TileSource {
    private Pool pool;
    ITileLoadable tileLoadable;
    String commitId;

    public SQLite3OgiqvoTileSource(Pool pool, ITileLoadable tileLoadable, String commitId) {
        super(0, OgiqvoTileLayer.SRC_MAX_ZOOM);

        this.pool = pool;
        this.tileLoadable = tileLoadable;
        this.commitId = commitId;
    }

    @Override
    public ITileDataSource getDataSourceOnMainThread() {
        return new OgiqvoTileDataSource(this.pool, this.tileLoadable, this.commitId);
    }
}
