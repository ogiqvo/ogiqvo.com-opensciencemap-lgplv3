package com.ogiqvo;

import com.google.common.collect.BoundType;
import com.google.common.collect.Range;
import com.ogiqvo.platestack.bean.Amenity;
import com.ogiqvo.platestack.bean.Elevator;
import com.ogiqvo.platestack.bean.Escalator;
import com.ogiqvo.platestack.bean.Floor;
import com.ogiqvo.platestack.bean.Platform;
import com.ogiqvo.platestack.bean.Slope;
import com.ogiqvo.platestack.bean.Stair;
import com.ogiqvo.platestack.bean.Wc;

import net.sf.geographiclib.Geodesic;
import net.sf.geographiclib.GeodesicData;

import org.oscim.backend.CanvasAdapter;
import org.oscim.backend.GL;
import org.oscim.backend.canvas.Canvas;
import org.oscim.backend.canvas.Color;
import org.oscim.backend.canvas.Paint;
import org.oscim.core.MapPosition;
import org.oscim.core.MercatorProjection;
import org.oscim.core.Point;
import org.oscim.core.Tile;
import org.oscim.layers.tile.MapTileJob;
import org.oscim.layers.tile.TileRenderer;
import org.oscim.renderer.GLMatrix;
import org.oscim.renderer.GLState;
import org.oscim.renderer.GLUtils;
import org.oscim.renderer.GLViewport;
import org.oscim.renderer.MapRenderer;
import org.oscim.renderer.bucket.BitmapBucket;
import org.oscim.renderer.bucket.HairLineBucket;
import org.oscim.renderer.bucket.LineBucket;
import org.oscim.renderer.bucket.LineTexBucket;
import org.oscim.renderer.bucket.MeshBucket;
import org.oscim.renderer.bucket.PlateStackTileBucket;
import org.oscim.renderer.bucket.PolygonBucket;
import org.oscim.renderer.bucket.RenderBucket;
import org.oscim.renderer.bucket.RenderBuckets;
import org.oscim.renderer.bucket.TextureItem;
import org.oscim.utils.FastMath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListMap;

import static org.oscim.backend.GLAdapter.gl;
import static org.oscim.layers.tile.MapTileJob.State.READY;
import static org.oscim.renderer.bucket.RenderBucket.BITMAP;
import static org.oscim.renderer.bucket.RenderBucket.HAIRLINE;
import static org.oscim.renderer.bucket.RenderBucket.LINE;
import static org.oscim.renderer.bucket.RenderBucket.MESH;
import static org.oscim.renderer.bucket.RenderBucket.POLYGON;
import static org.oscim.renderer.bucket.RenderBucket.TEXLINE;

/**
 * Created by xor on 15/08/27.
 */
public class PlateStackTileRenderer extends TileRenderer {
    static final Logger log = LoggerFactory.getLogger(PlateStackTileRenderer.class);

    public final static int TEXTURE_HEIGHT = 2048;
    public final static int TEXTURE_WIDTH = 64;
    final static int POOL_FILL = 4;
    private int textureYPointOffset = 0;

    protected FloatBuffer planeTexCoordBuffer;

    protected final Canvas mCanvas;
    public final static TextureItem.TexturePool pool = new TextureItem.TexturePool(POOL_FILL,
            TEXTURE_WIDTH,
            TEXTURE_HEIGHT);
    private final Paint platformBgPaint;
    private final Paint platformPaint;
    private static float platform_height;
    private static float platform_descent;
    private final static float PLATFORM0_FONT_SIZE = 24;
    int renderTextureId;
    int frameBufferId;
    private Map<String, PlatformContent> currentPlatformContents;
    private BitmapBucket.Shader textureShader;

    static final int upperColor = 0xffffffee;
    static final int lowerColor = 0xff999977;

    static final int upperColorR = Color.r(upperColor);
    static final int upperColorG = Color.g(upperColor);
    static final int upperColorB = Color.b(upperColor);
    static final int lowerColorR = Color.r(lowerColor);
    static final int lowerColorG = Color.g(lowerColor);
    static final int lowerColorB = Color.b(lowerColor);

    private PrimitiveShader primitiveShader;
    private Map<Stair, MapTileJob> foundStairsAndItsTile = new ConcurrentHashMap<>();
    private Map<Escalator, MapTileJob> foundEscalatorsAndItsTile = new ConcurrentHashMap<>();
    private Map<Escalator, EscalatorContext> escalator2context = new ConcurrentHashMap<>();
    private Map<Floor, MapTileJob> foundFloorsAndItsTile = new ConcurrentSkipListMap<>();
    private Map<Elevator, MapTileJob> foundElevatorsAndItsTile = new ConcurrentHashMap<>();
    private Map<Slope, MapTileJob> foundSlopesAndItsTile = new ConcurrentHashMap<>();
    private Map<Platform, MapTileJob> foundPlatformsAndItsTile = new ConcurrentHashMap<>();
    private Map<Amenity, MapTileJob> foundAmenitiesAndItsTile = new ConcurrentHashMap<>();

    private AltitudeRanges altitudeRanges;
    private AltitudeStretcher altitudeStretcher = new AltitudeStretcher();

    private PriorityQueue pq = new PriorityQueue(1000, new Comparator() {
        private double lowerAltitudeForStair(Stair stair) {
            return Math.min(stair.getFromAltitude(), stair.getToAltitude());
        }

        private double lowerAltitudeForEscalator(Escalator escalator) {
            return Math.min(escalator.getFromAltitude(), escalator.getToAltitude());
        }

        private double altitudeForObj(Object obj) {
            if (obj instanceof Floor) {
                return ((Floor) obj).getAltitude();
            } else if (obj instanceof Stair) {
                return lowerAltitudeForStair((Stair) obj);
            } else if (obj instanceof Escalator) {
                return lowerAltitudeForEscalator((Escalator) obj);
            } else if (obj instanceof Slope) {
                Slope sl = (Slope) obj;
                return (sl.getToAltitude() + sl.getFromAltitude()) / 2.0;
            } else if (obj instanceof Amenity) {
                Amenity am = (Amenity) obj;
                return (am.getAltitude()) / 2.0;
            }
            return 0;
        }

        @Override
        public int compare(Object o, Object t1) {
            return Double.compare(this.altitudeForObj(o), this.altitudeForObj(t1));
        }

        @Override
        public boolean equals(Object o) {
            return false;
        }
    });
    private Map<Floor, Integer> floor2altitudeIndex = new HashMap<>();
    private List<Double> floorAltitudes = new ArrayList<>();
    private Set<PlatformContent> requiredPlatformContents = new HashSet<>();

    private GLMatrix mTmpMatrix = new GLMatrix();

    static private int PARABOLA_SEGMENT_COUNT = 8;

    public PlateStackTileRenderer(AltitudeRanges altitudeRanges) {
        super();
        this.altitudeRanges = altitudeRanges;

        // Used to generate text as texture
        mCanvas = CanvasAdapter.newCanvas();

        platformBgPaint = CanvasAdapter.newPaint();
        platformBgPaint.setColor(0xff666666);
        platformBgPaint.setStyle(Paint.Style.FILL);

        platformPaint = CanvasAdapter.newPaint();
        platformPaint.setTextAlign(Paint.Align.LEFT);
        platformPaint.setTextSize(PLATFORM0_FONT_SIZE);
        platformPaint.setColor(0xffffffff);
        platformPaint.setTypeface(Paint.FontFamily.HELVETICA, Paint.FontStyle.NORMAL);
        platform_descent = platformPaint.getFontDescent();
        platform_height = platformPaint.getFontHeight() - platform_descent;

        planeTexCoordBuffer = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    public void notifyNewAltitudeStretcher(AltitudeStretcher altitudeStretcher) {
        synchronized (altitudeStretcher) {
            this.altitudeStretcher = altitudeStretcher;
        }
    }

    @Override
    public boolean setupOnGLThread() {
        super.setupOnGLThread();

        primitiveShader = new PrimitiveShader("base_shader");

        textureShader = new BitmapBucket.Shader("texture_alpha");
        this.setupTextTexture();

        currentPlatformContents = new HashMap<>();

        return true;
    }

    private void setupTextTexture() {
        IntBuffer buf = MapRenderer.getIntBuffer(1);

        // Create frame buffer
        gl.genFramebuffers(1, buf);
        frameBufferId = buf.get(0);
        gl.bindFramebuffer(GL.FRAMEBUFFER, frameBufferId);
        log.debug("Created (texture transferring) frame buffer {}", frameBufferId);

        // Create and setup texture buffers
        buf.clear();
        gl.genTextures(1, buf);
        renderTextureId = buf.get(0);
        log.debug("Created (buffered) texture buffer {}", renderTextureId);

        gl.bindTexture(GL.TEXTURE_2D, renderTextureId);
        gl.texImage2D(GL.TEXTURE_2D, 0,
                GL.RGBA, TEXTURE_WIDTH, TEXTURE_HEIGHT, 0, GL.RGBA,
                GL.UNSIGNED_BYTE, null); // Passing null will let it point the frame buffer
        GLUtils.setTextureParameter(
                GL.LINEAR,
                GL.LINEAR,
                GL.CLAMP_TO_EDGE,
                GL.CLAMP_TO_EDGE);

        // Create depth render buffer
        buf.clear();
        gl.genRenderbuffers(1, buf);
        int depthRenderbuffer = buf.get(0);

        gl.bindRenderbuffer(GL.RENDERBUFFER, depthRenderbuffer);
        gl.renderbufferStorage(GL.RENDERBUFFER,
                GL.DEPTH_COMPONENT16,
                TEXTURE_WIDTH, TEXTURE_HEIGHT);
        gl.framebufferRenderbuffer(GL.FRAMEBUFFER,
                GL.DEPTH_ATTACHMENT,
                GL.RENDERBUFFER,
                depthRenderbuffer);

        // Finally, configure our frame buffer
        gl.framebufferTexture2D(GL.FRAMEBUFFER,
                GL.COLOR_ATTACHMENT0,
                GL.TEXTURE_2D,
                renderTextureId, 0);

        // Check if framebuffer is ok
        int status = gl.checkFramebufferStatus(GL.FRAMEBUFFER);
        if (status != GL.FRAMEBUFFER_COMPLETE) {
            log.error("invalid framebuffer! " + status);
            return;
        }

        gl.bindFramebuffer(GL.FRAMEBUFFER, 0);
        gl.bindTexture(GL.TEXTURE_2D, 0);

        log.debug("Frame buffers & texture buffers are prepared properly!");
    }

    @Override
    public void renderOnGLThread(GLViewport v) {
        int objectCount = 0;
        MapTileJob[] tiles = drawingTileSet.tileJobs;
        for (int i = 0; i < tiles.length; i++) {
            MapTileJob tile = tiles[i];
            if (tile != null && tile.isVisible && tile.containsState(READY) && tile.isActive()) {
                // Gather beziers which is required to addRenderingRequestToMainThread

		        /* use holder proxy when it is set */
                PlateStackTileBucket bucket = (PlateStackTileBucket) ((tile.holder == null)
                        ? tile.getBuckets()
                        : tile.holder.getBuckets());
                if (bucket == null) {
                    continue;
                }

                PlateStackPerTile commitTile = bucket.getTile();
                if (commitTile == null) {
                } else if (commitTile.getFloors() == null) {
                } else {
                    for (Map.Entry<String, Floor> kv : commitTile.getFloors().entrySet()) {
                        objectCount++;
                        Floor floor = kv.getValue();
                        if (foundFloorsAndItsTile.containsKey(floor)) {
                            continue;
                        }
                        foundFloorsAndItsTile.put(floor, tile);
                    }
//                    for (Map.Entry<String, Stair> kv : commitTile.getStairs().entrySet()) {
//                        objectCount++;
//                        Stair stair = kv.getValue();
//                        if (foundStairsAndItsTile.containsKey(stair)) {
//                            continue;
//                        }
//                        foundStairsAndItsTile.put(stair, tile);
//                    }
//                    for (Map.Entry<String, Escalator> kv : commitTile.getEscalators().entrySet()) {
//                        objectCount++;
//                        Escalator escalator = kv.getValue();
//                        if (foundEscalatorsAndItsTile.containsKey(escalator)) {
//                            continue;
//                        }
//                        foundEscalatorsAndItsTile.put(escalator, tile);
//                    }
//                    for (Map.Entry<String, Elevator> kv : commitTile.getElevators().entrySet()) {
//                        objectCount++;
//                        Elevator elevator = kv.getValue();
//                        if (foundElevatorsAndItsTile.containsKey(elevator)) {
//                            continue;
//                        }
//                        foundElevatorsAndItsTile.put(elevator, tile);
//                    }
//                    for (Map.Entry<String, Slope> kv : commitTile.getSlopes().entrySet()) {
//                        objectCount++;
//                        Slope slope = kv.getValue();
//                        if (foundSlopesAndItsTile.containsKey(slope)) {
//                            continue;
//                        }
//                        foundSlopesAndItsTile.put(slope, tile);
//                    }
//                    for (Map.Entry<String, Platform> kv : commitTile.getPlatforms().entrySet()) {
//                        objectCount++;
//                        Platform platform = kv.getValue();
//                        if (foundPlatformsAndItsTile.containsKey(platform)) {
//                            continue;
//                        }
//                        foundPlatformsAndItsTile.put(platform, tile);
//                    }
//                    for (Map.Entry<String, Amenity> kv : commitTile.getAmenities().entrySet()) {
//                        objectCount++;
//                        Amenity amenity = kv.getValue();
//                        if (foundAmenitiesAndItsTile.containsKey(amenity)) {
//                            continue;
//                        }
//                        foundAmenitiesAndItsTile.put(amenity, tile);
//                    }
                }
            }
        }

        // Since rendering should be done in altitude order (no matter what object it is), we'll prepare a priority queue.
        double minAltitude = Double.MAX_VALUE;
        double maxAltitude = Double.MIN_VALUE;
        floorAltitudes.clear();
        synchronized (this.altitudeStretcher) {
            for (Map.Entry<Floor, MapTileJob> kv : foundFloorsAndItsTile.entrySet()) {
                Floor floor = kv.getKey();

                double altitude = floor.getAltitude();
                floorAltitudes.add(altitude);
                if (minAltitude > altitude) {
                    minAltitude = altitude;
                }
                if (maxAltitude < altitude) {
                    maxAltitude = altitude;
                }
                if (pq != null) {
                    pq.add(floor);
                }
            }
        }

        synchronized (this.altitudeRanges) {
            this.altitudeRanges.clear();
//                log.debug("Found altitudes {} .. {}", new Object[]{minAltitude, maxAltitude});
            if (minAltitude != Double.MAX_VALUE) {
                Range<Double> range = Range.range(minAltitude, BoundType.CLOSED, maxAltitude, BoundType.CLOSED);
                this.altitudeRanges.addAltitudeRange(range);
            }
            this.altitudeRanges.notifyAddingComplete();
        }

        // Kill yourself after altitude range is fixed.
        if (objectCount == 0) {
//            log.debug("Nothing to render");
            return;
        }

        if (v.pos.getZoomLevel() < 15) {
            return;
        }

//        for (Map.Entry<Stair, MapTileJob> kv : foundStairsAndItsTile.entrySet()) {
//            pq.add(kv.getKey());
//        }
//
//        for (Map.Entry<Escalator, MapTileJob> kv : foundEscalatorsAndItsTile.entrySet()) {
//            pq.add(kv.getKey());
//        }
//
//        for (Map.Entry<Slope, MapTileJob> kv : foundSlopesAndItsTile.entrySet()) {
//            pq.add(kv.getKey());
//        }
//
//        for (Map.Entry<Amenity, MapTileJob> kv : foundAmenitiesAndItsTile.entrySet()) {
//            pq.add(kv.getKey());
//        }

        // Detect altitude index for each floor
        floor2altitudeIndex.clear();
        for (Map.Entry<Floor, MapTileJob> kv : foundFloorsAndItsTile.entrySet()) {
            Floor floor = kv.getKey();
            int altitudeIndex = floorAltitudes.indexOf(floor.getAltitude());
            floor2altitudeIndex.put(floor, altitudeIndex);
        }

        // Detect from-to floor indices for each elevators
        for (Map.Entry<Elevator, MapTileJob> kv : foundElevatorsAndItsTile.entrySet()) {
            Elevator elevator = kv.getKey();
            int fromAltitudeIndex = floorAltitudes.indexOf(elevator.getFromAltitude());
            int toAltitudeIndex = floorAltitudes.indexOf(elevator.getToAltitude());
            Range<Integer> range = Range.closed(fromAltitudeIndex, toAltitudeIndex);
            elevator.setAltitudeIndexRange(range);
        }

        // Render

        primitiveShader.set(v);
        GLState.test(true, false);
        gl.depthFunc(GL.LEQUAL);
        GLState.blend(true);

        Object obj;
        while ((obj = pq.poll()) != null) {
            if (obj instanceof Floor) {
                Floor floor = (Floor) obj;
                double altitude = floor.getAltitude();
                double altitudeRate = (altitude - minAltitude) / (maxAltitude - minAltitude);
                int r = (int) ((double) upperColorR * altitudeRate + (double) lowerColorR * (1.0 - altitudeRate));
                int g = (int) ((double) upperColorG * altitudeRate + (double) lowerColorG * (1.0 - altitudeRate));
                int b = (int) ((double) upperColorB * altitudeRate + (double) lowerColorB * (1.0 - altitudeRate));
                int color = Color.get(r, g, b);
                // Render floors
                MapTileJob tile = foundFloorsAndItsTile.get(obj);
                this.renderFloorsInTile(v, floor, color, tile);

                // Render elevator
                GLState.test(true, false);
                GLState.bindElementBuffer(0);
                GLState.bindVertexBuffer(0);

                int altitudeIndex = floor2altitudeIndex.get(floor);
                double fromAltitude = floorAltitudes.get(altitudeIndex);
                double toAltitude = fromAltitude + 2;
                if (altitudeIndex < floor2altitudeIndex.size() - 1) {
                    toAltitude = floorAltitudes.get(altitudeIndex + 1);
                }
                for (Map.Entry<Elevator, MapTileJob> kv : foundElevatorsAndItsTile.entrySet()) {
                    Elevator elevator = kv.getKey();
                    Range<Integer> altitudeIndexRange = elevator.getAltitudeIndexRange();
                    if (!altitudeIndexRange.contains(altitudeIndex)) {
                        continue;
                    }
                    double fixedToAltitude = toAltitude;
                    if (altitudeIndexRange.upperEndpoint() == altitudeIndex) {
                        fixedToAltitude = fromAltitude + 2;
                    }
                    this.renderElevatorsInTile(v, elevator, kv.getValue(), fromAltitude, fixedToAltitude);
                }
//            } else if (obj instanceof Stair) {
//                // Render stairs
//                GLState.bindElementBuffer(0);
//                GLState.bindVertexBuffer(0);
//
//                MapTileJob tile = foundStairsAndItsTile.get(obj);
//                this.renderStairsInTile(v, (Stair) obj, tile);
//
//            } else if (obj instanceof Escalator) {
//                // Render escalators
//                GLState.bindElementBuffer(0);
//                GLState.bindVertexBuffer(0);
//
//                MapTileJob tile = foundEscalatorsAndItsTile.get(obj);
//                this.renderEscalatorsInTile(v, (Escalator) obj, tile);
//
//            } else if (obj instanceof Slope) {
//                // Render slopes
//                GLState.bindElementBuffer(0);
//                GLState.bindVertexBuffer(0);
//
//                MapTileJob tile = foundSlopesAndItsTile.get(obj);
//                this.renderSlopesInTile(v, (Slope) obj, tile);
//
//            } else if (obj instanceof Platform) {
//                // Render platforms
//                GLState.bindElementBuffer(0);
//                GLState.bindVertexBuffer(0);
//
//                MapTileJob tile = foundPlatformsAndItsTile.get(obj);
            }
        }

        // Draw platforms (no depth test needed, always on top)
//        for (PlatformContent pc : requiredPlatformContents) {
//            try {
//                plateformContentPool.returnObject(pc);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        requiredPlatformContents.clear();
//        for (Map.Entry<Platform, MapTileJob> kv : foundPlatformsAndItsTile.entrySet()) {
//            MapTileJob tile = kv.getValue();
//            this.generatePlatformContents(v, kv.getKey(), tile, requiredPlatformContents);
//            pq.add(kv.getKey());
//        }
//        boolean isRedrawingNeeded = false;
//        for (PlatformContent requiredPlatformContent : requiredPlatformContents) {
//            if (!this.currentPlatformContents.containsKey(requiredPlatformContent.toString())) {
//                isRedrawingNeeded = true;
//                break;
//            }
//        }
//        GLState.bindTex2D(renderTextureId);
//        if (isRedrawingNeeded) {
//            this.generatePlatformTextures(requiredPlatformContents);
//        }
//
//        for (PlatformContent requiredPlatformContent : requiredPlatformContents) {
//            PlatformContent lpc = this.currentPlatformContents.get(requiredPlatformContent.toString());
//            lpc.point = requiredPlatformContent.point;
//            this.renderPlatform(lpc, lpc.width, lpc.height, lpc.xOffset, lpc.yOffset, v);
//        }
    }

    private void renderFloorsInTile(GLViewport v,
                                    Floor floor,
                                    int color,
                                    MapTileJob tile) {
        TriangleAndLineVboIbo talvi = (TriangleAndLineVboIbo) floor.getTalvi();
        if (talvi == null) {
//            log.debug("no buckets {} {}", new Object[]{tile, talvi});
            return;
        }

        GLState.blend(true);
        GLState.test(true, false);
        gl.depthFunc(GL.LEQUAL);

        v.mvp.setIdentity();

        MapPosition pos = v.pos;
		/* place tileJob relative to map position */
        int z = tile.zoomLevel;
        float div = FastMath.pow(z - pos.zoomLevel);
        double tileScale = Tile.SIZE * pos.scale;
        float x = (float) ((tile.x - pos.x) * tileScale);
        float y = (float) ((tile.y - pos.y) * tileScale);
        float scale = (float) (pos.scale / (1 << z));

		/* scale relative to zoom-level of this tileJob */
        mTmpMatrix.setScale(scale, scale, scale);
        v.mvp.multiplyLhs(mTmpMatrix);

        double originalAltitude = floor.getAltitude();
//        double stretchedAltitude = this.altitudeStretcher.getStretchedAltitude(originalAltitude);
        float mapAffineZ = scale*0.27f * (float) originalAltitude;
        mTmpMatrix.setTranslation(x, y, mapAffineZ);
        v.mvp.multiplyLhs(mTmpMatrix);
        v.mvp.multiplyLhs(v.viewproj);
        v.mvp.setAsUniform(primitiveShader.uMVP);

        // Bind VBO & IBO if not ready
        if (!talvi.getIsVboIboIdSet()) {
            int[] bufferIds = GLUtils.glGenBuffers(2);
            int vboid = bufferIds[0];
            int iboid = bufferIds[1];

            GLState.bindVertexBuffer(vboid);
            float[] vertices = talvi.getVbo();
            FloatBuffer verticesBuffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            verticesBuffer.put(vertices).position(0);
            gl.bufferData(GL.ARRAY_BUFFER,
                    vertices.length * 4, verticesBuffer,
                    GL.STATIC_DRAW);
            GLState.bindVertexBuffer(0);

            GLState.bindElementBuffer(iboid);
            short[] indices = talvi.getIbo();
            ShortBuffer indicesBuffer = ByteBuffer.allocateDirect(indices.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
            indicesBuffer.put(indices).position(0);
            gl.bufferData(GL.ELEMENT_ARRAY_BUFFER,
                    indices.length * 2, indicesBuffer,
                    GL.STATIC_DRAW);
            GLState.bindElementBuffer(0);

            talvi.setVboIboid(vboid, iboid);
//            log.debug("Created vbo/ibo {} {}", new Object[]{vboid, iboid});
//            log.debug("VBO={}", vertices);
//            log.debug("IBO={}", indices);
        }

        GLState.bindVertexBuffer(talvi.getVboid());
        GLState.enableVertexArrays(primitiveShader.aPos, -1);
        gl.vertexAttribPointer(primitiveShader.aPos, 2, GL.FLOAT, false, 0, 0);
        GLState.bindElementBuffer(talvi.getIboid());

        int[] iboPointOffsets = talvi.getIboPointOffsets();
        for (int i = 0; i < iboPointOffsets.length - 1; i++) {
            int iboPointCounts = iboPointOffsets[i + 1] - iboPointOffsets[i];

            if (i == 0) {
                // Render triangles
//                log.debug("Ibo#{} with points {}-{} ({})", new Object[]{i, iboPointOffsets[i], iboPointOffsets[i + 1], iboPointCounts});
                GLUtils.setColor(primitiveShader.uColor, color, 0.95f);
                gl.drawElements(gl.TRIANGLES, iboPointCounts, gl.UNSIGNED_SHORT, iboPointOffsets[i] * 2);
            } else {
                // Render lines
                GLUtils.setColor(primitiveShader.uColor, Color.DKGRAY, 1f);
                gl.drawElements(gl.LINE_LOOP, iboPointCounts, gl.UNSIGNED_SHORT, iboPointOffsets[i] * 2);
            }
        }

        for (Map.Entry<Wc.Type, Wc> wckv : floor.wcsEntrySet()) {
//            renderWc(v, floor, tile, wckv.getValue(), div, scale);
        }
    }

    private void renderWc(GLViewport v,
                          Floor floor,
                          MapTileJob tile, Wc wc, float div, float scale) {
        // No need to set matrix again, they're already set!

        RenderBuckets buckets = (RenderBuckets) wc.getRenderBucket();
        if (buckets == null) {
//            log.debug("no buckets {} {}", new Object[]{tile, buckets});
            return;
        }

        if (buckets.vbo == null) {
            buckets.compile(true);
        }
        buckets.bind();

        PolygonBucket.Renderer.clip(v.mvp, PolygonBucket.CLIP_STENCIL);
        boolean first = true;

        for (RenderBucket b = buckets.get(); b != null; ) {
            switch (b.type) {
                case POLYGON:
                    b = PolygonBucket.Renderer.draw(b, v, div, first);
                    first = false;
					/* set test for clip to tileJob region */
                    gl.stencilFunc(GL.EQUAL, 0x80, 0x80);
                    break;
                case LINE:
                    b = LineBucket.Renderer.draw(b, v, scale, buckets);
                    break;
                case TEXLINE:
                    b = LineTexBucket.Renderer.draw(b, v, div, buckets);
                    break;
                case MESH:
                    b = MeshBucket.Renderer.draw(b, v);
                    break;
                case HAIRLINE:
                    b = HairLineBucket.Renderer.draw(b, v);
                    break;
                case BITMAP:
                    b = BitmapBucket.Renderer.draw(b, v, 1, layerAlpha);
                    break;
                default:
					/* just in case */
//                    log.error("unknown layer {}", b.type);
                    b = b.next;
                    break;
            }

			/* make sure buffers are bound again */
            buckets.bind();
        }
    }

    private void prepareStairCacheIfNotExists(Stair stair) {
        // Generate stair model if cache is not ready
        if (stair.isCacheSet()) {
            return;
        }
        double lat0 = stair.getFromLatitude();
        double lon0 = stair.getFromLongitude();
        double alt0 = stair.getFromAltitude();
        double latl = stair.getToLatitude();
        double lonl = stair.getToLongitude();
        double altl = stair.getToAltitude();
        List<List<Double>> latss = new ArrayList<>();
        List<List<Double>> lonss = new ArrayList<>();
        List<List<Double>> altss = new ArrayList<>();
        int slopeCount = stair.getStepsPerSlope().length;
        double[] rs = stair.getKnotRs();

        double altrSigma = 0.0;

        // Generate stair latitudes, longitudes
        for (int s = 0; s < slopeCount; s++) {
            List<Double> lats = new ArrayList<>();
            List<Double> lons = new ArrayList<>();

            int stepCount = stair.getStepsPerSlope()[s];
            double fromR = rs[s * 2];
            double toR = rs[s * 2 + 1];
            double rDelta = toR - fromR;

            // Generate horizontal split count, where partial should be split into n-1 points
            int horizontalSplitCount = stepCount - 1;
//            log.debug("Generate horizontal {} steps for {}->{}", new Object[]{horizontalSplitCount, fromR, toR});
            for (int i = 0; i < horizontalSplitCount + 1; i++) {
                double dr = (double) i / (double) horizontalSplitCount;
                double r = dr * rDelta + fromR;
//                    log.debug("r={}", new Object[]{r});
                double latr = latl * r + lat0 * (1.0 - r);
                double lonr = lonl * r + lon0 * (1.0 - r);
                lats.add(latr);
                lons.add(lonr);
            }
            latss.add(lats);
            lonss.add(lons);

//                log.debug("  done");
            altrSigma += rDelta;
        }

        // Generate stair altitudes
        double altrIntegral = 0.0;
        for (int s = 0; s < slopeCount; s++) {
            List<Double> alts = new ArrayList<>();

            int stepCount = stair.getStepsPerSlope()[s];
            double fromR = rs[s * 2];
            double toR = rs[s * 2 + 1];
            double rDelta = toR - fromR;

            double altrFrom = altrIntegral;
            double altrTo = altrIntegral + rDelta;
            double altrFromR = altrFrom / altrSigma;
            double altrToR = altrTo / altrSigma;
            double altrDeltaR = altrToR - altrFromR;

            int verticalSplitCount = stepCount;
//                log.debug("Generate vertical {} steps for {}->{}", new Object[]{verticalSplitCount, altrFromR, altrToR});
            for (int i = 0; i < verticalSplitCount + 1; i++) {
                double dr = (double) i / (double) verticalSplitCount;
                double r = dr * altrDeltaR + altrFromR;
//                    log.debug("r={}", new Object[]{r});
                double altr = altl * r + alt0 * (1.0 - r);
                alts.add(altr);
            }
            altss.add(alts);

            altrIntegral = altrTo;
        }

        // Generate opposite side latitude, longitudes
        double extrudeWidth = stair.getExtrusionWidth();
        double extrudeBearing = stair.getExtrusionBearing();
        List<List<Double>> olatss = new ArrayList<>();
        List<List<Double>> olonss = new ArrayList<>();
        for (int i = 0; i < latss.size(); i++) {
            List<Double> lats = latss.get(i);
            List<Double> lons = lonss.get(i);
            List<Double> olats = new ArrayList<>();
            List<Double> olons = new ArrayList<>();
            for (int j = 0; j < lats.size(); j++) {
                double lat = lats.get(j);
                double lon = lons.get(j);

                GeodesicData d;
                synchronized (Geodesic.WGS84) {
                    d = Geodesic.WGS84.Direct(lat, lon, extrudeBearing, extrudeWidth);
                }
                double olat = d.lat2;
                double olon = d.lon2;

                olats.add(olat);
                olons.add(olon);
            }
            olatss.add(olats);
            olonss.add(olons);
        }

        // Set and finish.
        stair.setLatss(latss);
        stair.setLonss(lonss);
        stair.setOlatss(olatss);
        stair.setOlonss(olonss);
        stair.setAltss(altss);
    }

    private void renderStairsInTile(GLViewport v,
                                    Stair stair,
                                    MapTileJob tile) {
        this.prepareStairCacheIfNotExists(stair);

        int z = tile.zoomLevel;

        MapPosition pos = v.pos;
        double tileScale = Tile.SIZE * v.pos.scale;

        float heightScale = (float) (v.pos.scale / (1 << z));

        // If there are n steps, there requires 4n vertices, 6n-2 indices.
        int totalSteps = 0;
        for (int partialSteps : stair.getStepsPerSlope()) {
            totalSteps += partialSteps;
        }
        int vertexCount = totalSteps * 4;
        int indexCount = totalSteps * 12 - 3;

        // Generate indices
        short[] indices = new short[indexCount];
        for (int i = 0; i < totalSteps; i++) {
            indices[i * 12] = (short) (i * 4 + 1);
            indices[i * 12 + 1] = (short) (i * 4 + 3);
            indices[i * 12 + 2] = (short) (i * 4 + 0);
            indices[i * 12 + 3] = (short) (i * 4 + 3);
            indices[i * 12 + 4] = (short) (i * 4 + 0);
            indices[i * 12 + 5] = (short) (i * 4 + 2);
            if (i != totalSteps - 1) {
                indices[i * 12 + 6] = (short) (i * 4 + 3);
                indices[i * 12 + 7] = (short) (i * 4 + 2);
                indices[i * 12 + 8] = (short) (i * 4 + 4);
                indices[i * 12 + 9] = (short) (i * 4 + 3);
                indices[i * 12 + 10] = (short) (i * 4 + 4);
                indices[i * 12 + 11] = (short) (i * 4 + 5);
            }
        }

        // Generate vertices
        float[] vertices = new float[vertexCount * 3];
        int integralStepCount = 0;
        for (int i = 0; i < stair.getStepsPerSlope().length; i++) {
//            log.debug("Generate vertex for slope {}",i);

            List<Double> lats = stair.getLatss().get(i);
            List<Double> lons = stair.getLonss().get(i);
            List<Double> olats = stair.getOlatss().get(i);
            List<Double> olons = stair.getOlonss().get(i);
            List<Double> alts = stair.getAltss().get(i);

            int stepCount = stair.getStepsPerSlope()[i];
//            log.debug("  slope {} has {} steps alt {}",new Object[]{i,stepCount,alts});

            for (int j = 0; j < stepCount; j++) {
                double lat = lats.get(j);
                double lon = lons.get(j);
                double olat = olats.get(j);
                double olon = olons.get(j);

                double objAbsRateX = MercatorProjection.longitudeToX(lon);
                double objAbsRateY = MercatorProjection.latitudeToY(lat);
                double rateXDelta = objAbsRateX - pos.x;
                double rateYDelta = objAbsRateY - pos.y;
                float mapAffineX = (float) (rateXDelta * tileScale);
                float mapAffineY = (float) (rateYDelta * tileScale);

                double oobjAbsRateX = MercatorProjection.longitudeToX(olon);
                double oobjAbsRateY = MercatorProjection.latitudeToY(olat);
                double orateXDelta = oobjAbsRateX - pos.x;
                double orateYDelta = oobjAbsRateY - pos.y;
                float omapAffineX = (float) (orateXDelta * tileScale);
                float omapAffineY = (float) (orateYDelta * tileScale);

                double alt0 = alts.get(j);
                double alt1 = alts.get(j + 1);

                double stretchedAltitude0 = this.altitudeStretcher.getStretchedAltitude(alt0);
                double stretchedAltitude1 = this.altitudeStretcher.getStretchedAltitude(alt1);
                float stretchedMapAffineZ0 = heightScale * (float) stretchedAltitude0;
                float stretchedMapAffineZ1 = heightScale * (float) stretchedAltitude1;

                // Vertex 4n+0
                vertices[integralStepCount * 12 + 0] = mapAffineX;
                vertices[integralStepCount * 12 + 1] = mapAffineY;
                vertices[integralStepCount * 12 + 2] = stretchedMapAffineZ0;

                // Vertex 4n+1
                vertices[integralStepCount * 12 + 3] = omapAffineX;
                vertices[integralStepCount * 12 + 4] = omapAffineY;
                vertices[integralStepCount * 12 + 5] = stretchedMapAffineZ0;

                // Vertex 4n+2
                vertices[integralStepCount * 12 + 6] = mapAffineX;
                vertices[integralStepCount * 12 + 7] = mapAffineY;
                vertices[integralStepCount * 12 + 8] = stretchedMapAffineZ1;

                // Vertex 4n+2
                vertices[integralStepCount * 12 + 9] = omapAffineX;
                vertices[integralStepCount * 12 + 10] = omapAffineY;
                vertices[integralStepCount * 12 + 11] = stretchedMapAffineZ1;

                integralStepCount++;
            }

            totalSteps += stair.getStepsPerSlope()[i];
        }

//        log.debug("{} {}", new Object[]{vertices, indices});

        FloatBuffer verticesBuffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        verticesBuffer.put(vertices).position(0);

        ShortBuffer indicesBuffer = ByteBuffer.allocateDirect(indices.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
        indicesBuffer.put(indices).position(0);

        v.mvp.setIdentity();

        // Fix-ups before drawing elements
        v.mvp.multiplyLhs(v.viewproj);
        v.mvp.setAsUniform(primitiveShader.uMVP);

        GLUtils.setColor(primitiveShader.uColor, Color.WHITE, 0.9f);
        gl.vertexAttribPointer(primitiveShader.aPos, 3, GL.FLOAT, false, 0, verticesBuffer); // 3 = 3-dimensional
        gl.drawElements(GL.TRIANGLES, indices.length, GL.UNSIGNED_SHORT, indicesBuffer);

        GLUtils.setColor(primitiveShader.uColor, Color.DKGRAY, 0.9f);
        gl.lineWidth(1);
        gl.drawElements(GL.LINES, indices.length, GL.UNSIGNED_SHORT, indicesBuffer);
    }

    private void prepareEscalatorCacheIfNotExists(Escalator escalator) {
        if (escalator.isCacheSet()) {
            return;
        }

        double[] ts = escalator.getKnotRs();
        int slopeCount = (ts.length - 2) / 2;
        double[] exRs = new double[slopeCount * 4 + 2];

        // Put first and last rs
        exRs[0] = ts[0];
        exRs[exRs.length - 1] = ts[ts.length - 1];

        double fromLatitude = escalator.getFromLatitude();
        double fromLongitude = escalator.getFromLongitude();
        double fromAltitude = escalator.getFromAltitude();
        double toLatitude = escalator.getToLatitude();
        double toLongitude = escalator.getToLongitude();
        double toAltitude = escalator.getToAltitude();

        double altitudeDelta = toAltitude - fromAltitude;

        // Calculate horizontal distance
        GeodesicData gd;
        synchronized (Geodesic.WGS84) {
            gd = Geodesic.WGS84.Inverse(fromLatitude, fromLongitude, toLatitude, toLongitude);
        }
        double horizontalDistance = gd.s12;

        double parabolaGeneratingHorizontalDistance = escalator.getVerticalAccelHorizontalDistance();
        double parabolaGeneratingHorizontalTDelta = parabolaGeneratingHorizontalDistance / horizontalDistance;

//        log.debug("###################################");
//        log.debug("Prepare escalator with knots {} distance {}", new Object[]{ts, horizontalDistance});

        // Calculate r-denominator used for altitude division
        double altitudeTDenominator = 0.0;
        for (int s = 0; s < slopeCount; s++) {
            double tFrom = ts[s * 2 + 1];
            double tTo = ts[s * 2 + 2];
            double tDelta = tTo - tFrom;
            altitudeTDenominator += tDelta;
        }

        double[] integralLengthDelimiters = new double[slopeCount * 4 + 2];
        integralLengthDelimiters[0] = 0;

        double[] slopes = new double[slopeCount];
        Double[][] parabolaPaddingXs = new Double[slopeCount][];
        Double[][] parabolaPaddingYs = new Double[slopeCount][];
        Double[][] parabolaPaddingLengthDelimiters = new Double[slopeCount][];
        double[] altitudes = new double[slopeCount + 1];

        double altrIntegral = 0.0;
        double prevToTEnd = 0.0;
        double foundSlope = 0;
        for (int s = 0; s < slopeCount; s++) {
            double segmentFromT = ts[s * 2 + 1];
            double segmentToT = ts[s * 2 + 2];
            double segmentTDelta = segmentToT - segmentFromT;

//            log.debug("  ---------------------------------------");
//            log.debug("  FROM R {}->{}", new Object[]{segmentFromT, segmentToT});

            double segmentAltitutdeTFromHorizontalFrom = altrIntegral;
            double segmentAltitudeTFromHorizontalTo = altrIntegral + segmentTDelta;
            double segmentAltitudeTFrom = segmentAltitutdeTFromHorizontalFrom / altitudeTDenominator;
            double segmentAltitudeTTo = segmentAltitudeTFromHorizontalTo / altitudeTDenominator;

            double segmentHorizontalDistanceFrom = horizontalDistance * segmentFromT;
            double segmentHorizontalDistanceTo = horizontalDistance * segmentToT;
            double segmentHorizontalDistanceDelta = segmentHorizontalDistanceTo - segmentHorizontalDistanceFrom;

            double segmentAltitudeOffsetFrom = altitudeDelta * segmentAltitudeTFrom;
            double segmentAltitudeOffsetTo = altitudeDelta * segmentAltitudeTTo;
            double segmentAltitudeDelta = segmentAltitudeOffsetTo - segmentAltitudeOffsetFrom;
            double segmentAltitudeFrom = segmentAltitudeOffsetFrom + fromAltitude;
            double segmentAltitudeTo = segmentAltitudeOffsetTo + fromAltitude;

            altitudes[s] = segmentAltitudeFrom;
            altitudes[s + 1] = segmentAltitudeTo;

            double segmentSlope = segmentAltitudeDelta / segmentHorizontalDistanceDelta;

//            log.debug("    horiz={}={}-{} (r={}..{}) alt={}={}-{} (r={}..{})", new Object[]{
//                    segmentHorizontalDistanceDelta, segmentHorizontalDistanceTo, segmentHorizontalDistanceFrom,
//                    segmentFromT, segmentToT,
//                    segmentAltitudeDelta, segmentAltitudeOffsetTo, segmentAltitudeOffsetFrom,
//                    segmentAltitudeTFrom, segmentAltitudeTTo
//            });
//            log.debug("    slope={}={}/{}", new Object[]{segmentSlope, segmentAltitudeDelta, segmentHorizontalDistanceDelta});

            foundSlope = slopes[s] = segmentSlope;

            double halfParabolaGeneratingHorizontalTDelta = parabolaGeneratingHorizontalTDelta / 2.0;

            double parabola1TFrom = segmentFromT - halfParabolaGeneratingHorizontalTDelta;
            double parabola1TTo = segmentFromT + halfParabolaGeneratingHorizontalTDelta;
            double parabola2TFrom = segmentToT - halfParabolaGeneratingHorizontalTDelta;
            double parabola2TTo = segmentToT + halfParabolaGeneratingHorizontalTDelta;

            double parabola1TDelta = parabola1TTo - parabola1TFrom;

//            log.debug("    generate parabola rs={}->{}->{}->{}", new Object[]{parabola1TFrom, parabola1TTo, parabola2TFrom, parabola2TTo});

            // Generate first and last parabola accel
            double a = segmentSlope / parabolaGeneratingHorizontalDistance / 2.0;

            // Generate padding
            Double[] parabolaPaddingX = new Double[PARABOLA_SEGMENT_COUNT + 1];
            Double[] parabolaPaddingY = new Double[PARABOLA_SEGMENT_COUNT + 1];
            Double[] parabolaPaddingLengthDelimiter = new Double[PARABOLA_SEGMENT_COUNT + 1];
            double prevY = 0;
            double dx = parabola1TDelta * horizontalDistance / (double) PARABOLA_SEGMENT_COUNT;
            for (int i = 0; i < PARABOLA_SEGMENT_COUNT + 1; i++) {
                double x = (double) i * dx;
                parabolaPaddingX[i] = x;
                double y = a * x * x;
                parabolaPaddingY[i] = y;
                if (i == 0) {
                    parabolaPaddingLengthDelimiter[0] = new Double(0);
                } else {
                    double dy = y - prevY;
                    double distance = Math.sqrt(dx * dx + dy * dy);
                    parabolaPaddingLengthDelimiter[i] = parabolaPaddingLengthDelimiter[i - 1] + distance;
                }
                prevY = y;
            }
            parabolaPaddingXs[s] = parabolaPaddingX;
            parabolaPaddingYs[s] = parabolaPaddingY;
            parabolaPaddingLengthDelimiters[s] = parabolaPaddingLengthDelimiter;

//            log.debug("      accel delimiters x={} y={} l={}", new Object[]{parabolaPaddingX, parabolaPaddingY, parabolaPaddingLengthDelimiter});

            // Prev last - Current first flat length
            double flatLength = (parabola1TFrom - prevToTEnd) * horizontalDistance;
//            log.debug("      flat length {}={}*{}", new Object[]{flatLength, parabola1TFrom - prevToTEnd, horizontalDistance});

            // Calculate parabola length
            double parabolaArcLength = parabolaPaddingLengthDelimiter[parabolaPaddingLengthDelimiter.length - 1];
//            log.debug("      parabola length={}", new Object[]{parabolaArcLength});

            // Calculate slope length
            double slopeAltitudeDelta = segmentAltitudeDelta * (parabola2TFrom - parabola1TTo);
            double slopeHorizontalDistanceDelta = horizontalDistance * (parabola2TFrom - parabola1TTo);
            double slopeLength = Math.sqrt(slopeAltitudeDelta * slopeAltitudeDelta + slopeHorizontalDistanceDelta * slopeHorizontalDistanceDelta);
//            log.debug("      slope length x{} y{} l{}", new Object[]{slopeHorizontalDistanceDelta, slopeAltitudeDelta, slopeLength});

            integralLengthDelimiters[s * 4 + 1] = integralLengthDelimiters[s * 4] + flatLength;
            integralLengthDelimiters[s * 4 + 2] = integralLengthDelimiters[s * 4 + 1] + parabolaArcLength;
            integralLengthDelimiters[s * 4 + 3] = integralLengthDelimiters[s * 4 + 2] + slopeLength;
            integralLengthDelimiters[s * 4 + 4] = integralLengthDelimiters[s * 4 + 3] + parabolaArcLength;

            exRs[s * 4 + 1] = parabola1TFrom;
            exRs[s * 4 + 2] = parabola1TTo;
            exRs[s * 4 + 3] = parabola2TFrom;
            exRs[s * 4 + 4] = parabola2TTo;

            altrIntegral = segmentAltitudeTFromHorizontalTo;
            prevToTEnd = parabola2TTo;
        }
        double lastRateDelta = (1.0 - prevToTEnd);
        integralLengthDelimiters[integralLengthDelimiters.length - 1] = integralLengthDelimiters[integralLengthDelimiters.length - 2] + lastRateDelta * horizontalDistance;

        escalator.setIntegralLengthDelimiters(integralLengthDelimiters);
        escalator.setHorizontalTs(exRs);
        escalator.setAccelXs(parabolaPaddingXs);
        escalator.setAccelYs(parabolaPaddingYs);
        escalator.setAccelLengthDelimiters(parabolaPaddingLengthDelimiters);
        escalator.setAltitudes(altitudes);

        double slopeParabolaAltitudeDelta = foundSlope != 0 ? parabolaGeneratingHorizontalDistance * foundSlope / 2.0 : 0;
        escalator.setSlopeParabolaAltitudeDelta(slopeParabolaAltitudeDelta);
    }

    private EscalatorContext contextPerEscalatorIfNotExists(Escalator escalator) {
        if (this.escalator2context.containsKey(escalator)) {
            return this.escalator2context.get(escalator);
        }
        EscalatorContext ec = new EscalatorContext();
        ec.setEscalator(escalator);
        this.escalator2context.put(escalator, ec);
        return ec;
    }

    // Called from non-GL thread
    public boolean updateEscalatorContextForUtcMilliseconds(long utcMilliseconds) {
        boolean hasEvenSingleUpdate = false;
//
//        for (Map.Entry<Escalator, EscalatorContext> kv : this.escalator2context.entrySet()) {
//            Escalator e = kv.getKey();
//            EscalatorContext ec = kv.getValue();
//            if (ec.getLastUtcMilliseconds() == utcMilliseconds) {
//                continue;
//            }
//            hasEvenSingleUpdate = true;
//
//            double[] wholeLengthDelimiters = e.getIntegralLengthDelimiters();
//            double totalLength = wholeLengthDelimiters[wholeLengthDelimiters.length - 1];
//            double plateDepth = e.getPlateDepth();
//            int requiredPlateCount = (int) Math.ceil(totalLength / plateDepth);
//
//            double[] plateLengths = ec.getPlateDistances();
//            if (plateLengths == null || plateLengths.length != requiredPlateCount) {
//                plateLengths = new double[requiredPlateCount];
//                ec.setPlateDistances(plateLengths);
//            }
//
//            double velocity = e.getVelocity(); // meters per second
//            double movedLengthSince197011 = utcMilliseconds * velocity / 1000d;
//            int currentPlateNumber = (int) (movedLengthSince197011 / plateDepth);
//            double currentPlateOffsetLength = movedLengthSince197011 - currentPlateNumber * plateDepth;
//
//            // Build boxed list
//            Double[] lengthDelimitersBoxed = new Double[wholeLengthDelimiters.length];
//            for (int i = 0; i < wholeLengthDelimiters.length; i++) {
//                lengthDelimitersBoxed[i] = wholeLengthDelimiters[i];
//            }
//
//            double[] horizontalTs = e.getHorizontalTs();
//
//            double wholeLatitudeFrom = e.getFromLatitude();
//            double wholeLongitudeFrom = e.getFromLongitude();
//            double wholeLatitudeTo = e.getToLatitude();
//            double wholeLongitudeTo = e.getToLongitude();
//
//            double[] altitudes = e.getAltitudes();
//
//            Double[][] parabolaPaddingXs = e.getAccelXs();
//            Double[][] parabolaPaddingYs = e.getAccelYs();
//            Double[][] parabolaPaddingLengthDelimiters = e.getAccelLengthDelimiters();
//
//            double slopeParabolaAltitudeDelta = e.getSlopeParabolaAltitudeDelta();
//
////            log.debug("distance dels {}", ld);
////            log.debug("horizontal t dels {}", htds);
////            log.debug("altitudes {}", altitudes);
//
//            double wholeLatitudeDelta = wholeLatitudeTo - wholeLatitudeFrom;
//            double wholeLongitudeDelta = wholeLongitudeTo - wholeLongitudeFrom;
//
//            double[] latResults = new double[requiredPlateCount];
//            double[] lonResults = new double[requiredPlateCount];
//            double[] altResults = new double[requiredPlateCount];
//
//            for (int i = 0; i < requiredPlateCount; i++) {
//                double integralPlateLength = plateLengths[i] = currentPlateOffsetLength + i * plateDepth;
//                int index = ArrayUtil.linearSearch(lengthDelimitersBoxed, integralPlateLength);
//                if (index >= lengthDelimitersBoxed.length - 1) {
//                    continue;
//                }
//
//                double latitude = 0, longitude = 0, altitude = 0;
//
//                double segmentHorizontalTFrom = horizontalTs[index];
//                double segmentHorizontalTTo = horizontalTs[index + 1];
//                double segmentLengthFrom = wholeLengthDelimiters[index];
//                double segmentLengthTo = wholeLengthDelimiters[index + 1];
//                double segmentLength = segmentLengthTo - segmentLengthFrom;
//                double plateLengthInSegment = integralPlateLength - segmentLengthFrom;
//
////                log.debug("  distance {} index {}", distance, index);
//                switch (index % 4) {
//                    case 0: { // flat, where it's linear
//                        double r = plateLengthInSegment / segmentLength;
//                        double integralFlatT = segmentHorizontalTTo * r + segmentHorizontalTFrom * (1.0 - r);
//                        latitude = wholeLatitudeFrom + wholeLatitudeDelta * integralFlatT;
//                        longitude = wholeLongitudeFrom + wholeLongitudeDelta * integralFlatT;
//                        altitude = altitudes[index / 4]; // on index=0, use altitudes[0]. on index=4, use altitudes[1].
////                        log.debug("  r={}", r);
//                        break;
//                    }
//                    case 1: { // begin accel
//                        double fromAltitude = altitudes[(index - 1) / 4]; // on index=1, use altitudes[0] on index=5, use altitudes[1].
//
//                        // x means horizontal distance!
//                        Double[] parabolaPaddingLengthDelimiter = parabolaPaddingLengthDelimiters[(index - 1) / 4];
//                        Double[] parabolaPaddingX = parabolaPaddingXs[(index - 1) / 4];
//                        Double[] parabolaPaddingY = parabolaPaddingYs[(index - 1) / 4];
//
//                        int parabolaPaddingIndex = ArrayUtil.linearSearch(parabolaPaddingLengthDelimiter, plateLengthInSegment);
//                        if (parabolaPaddingIndex >= parabolaPaddingLengthDelimiter.length - 1) {
//                            parabolaPaddingIndex = parabolaPaddingLengthDelimiter.length - 2;
//                        }
//                        double paddingLengthFrom = parabolaPaddingLengthDelimiter[parabolaPaddingIndex];
//                        double paddingLengthTo = parabolaPaddingLengthDelimiter[parabolaPaddingIndex + 1];
//                        double rateInPadding = (plateLengthInSegment - paddingLengthFrom) / (paddingLengthTo - paddingLengthFrom);
////                        log.debug("Find distance {} from {} to {} rate {}", new Object[]{plateLengthInSegment, paddingLengthFrom, paddingLengthTo, rateInPadding});
//
//                        double paddingXFrom = parabolaPaddingX[parabolaPaddingIndex];
//                        double paddingXTo = parabolaPaddingX[parabolaPaddingIndex + 1];
//                        double paddingYFrom = parabolaPaddingY[parabolaPaddingIndex];
//                        double paddingYTo = parabolaPaddingY[parabolaPaddingIndex + 1];
//                        double x = paddingXTo * rateInPadding + paddingXFrom * (1.0 - rateInPadding);
//                        double y = paddingYTo * rateInPadding + paddingYFrom * (1.0 - rateInPadding);
//
//                        // x means horizontal distance!
//                        double distr = x / segmentLength;
//
//                        double integralFlatT = segmentHorizontalTTo * distr + segmentHorizontalTFrom * (1.0 - distr);
//                        latitude = wholeLatitudeFrom + wholeLatitudeDelta * integralFlatT;
//                        longitude = wholeLongitudeFrom + wholeLongitudeDelta * integralFlatT;
//                        altitude = fromAltitude + y;
//                        break;
//                    }
//                    case 2: { // slope, where it's linear
//                        double distr = plateLengthInSegment / segmentLength;
//                        double integralT = segmentHorizontalTTo * distr + segmentHorizontalTFrom * (1.0 - distr);
//
//                        latitude = wholeLatitudeFrom + wholeLatitudeDelta * integralT;
//                        longitude = wholeLongitudeFrom + wholeLongitudeDelta * integralT;
//
//                        double fromAltitude = altitudes[(index - 2) / 4] + slopeParabolaAltitudeDelta; // on index=2, use altitudes[0]-altitudes[1], on index=6, use altitudes[1]-altitudes[2]
//                        double toAltitude = altitudes[(index - 2) / 4 + 1] - slopeParabolaAltitudeDelta;
//
//                        altitude = toAltitude * distr + fromAltitude * (1.0 - distr);
//                        break;
//                    }
//                    case 3: { // End accel
//                        double toAltitude = altitudes[(index - 3) / 4 + 1]; // on index=1, use altitudes[0] on index=5, use altitudes[1].
//
//                        // x means horizontal distance!
//                        Double[] parabolaPaddingLengthDelimiter = parabolaPaddingLengthDelimiters[(index - 3) / 4];
//                        Double[] parabolaPaddingX = parabolaPaddingXs[(index - 3) / 4];
//                        Double[] parabolaPaddingY = parabolaPaddingYs[(index - 3) / 4];
//
//                        double reversePlateLengthInSegment = segmentLength - plateLengthInSegment;
//                        int parabolaPaddingReverseIndex = ArrayUtil.linearSearch(parabolaPaddingLengthDelimiter, reversePlateLengthInSegment);
//                        if (parabolaPaddingReverseIndex >= parabolaPaddingLengthDelimiter.length - 1) {
//                            parabolaPaddingReverseIndex = parabolaPaddingLengthDelimiter.length - 2;
//                        }
//                        double paddingReverseLengthFrom = parabolaPaddingLengthDelimiter[parabolaPaddingReverseIndex];
//                        double paddingReverseLengthTo = parabolaPaddingLengthDelimiter[parabolaPaddingReverseIndex + 1];
//                        double reverseRateInPadding = (reversePlateLengthInSegment - paddingReverseLengthFrom) / (paddingReverseLengthTo - paddingReverseLengthFrom);
////                        log.debug("Find distance {} from {} to {} rate {}", new Object[]{reversePlateLengthInSegment, paddingReverseLengthFrom, paddingReverseLengthTo, reverseRateInPadding});
//
//                        double paddingReverseXFrom = parabolaPaddingX[parabolaPaddingReverseIndex];
//                        double paddingReverseXTo = parabolaPaddingX[parabolaPaddingReverseIndex + 1];
//                        double paddingReverseYFrom = parabolaPaddingY[parabolaPaddingReverseIndex];
//                        double paddingReverseYTo = parabolaPaddingY[parabolaPaddingReverseIndex + 1];
//                        double reverseX = paddingReverseXTo * reverseRateInPadding + paddingReverseXFrom * (1.0 - reverseRateInPadding);
//                        double reverseY = paddingReverseYTo * reverseRateInPadding + paddingReverseYFrom * (1.0 - reverseRateInPadding);
//
//                        // x means horizontal distance!
//                        double reverseDistR = reverseX / segmentLength;
//
//                        double distR = 1.0 - reverseDistR;
//                        double integralFlatT = segmentHorizontalTTo * distR + segmentHorizontalTFrom * (1.0 - distR);
//
//                        latitude = wholeLatitudeFrom + wholeLatitudeDelta * integralFlatT;
//                        longitude = wholeLongitudeFrom + wholeLongitudeDelta * integralFlatT;
//                        altitude = toAltitude - reverseY;
//                        break;
//                    }
//                }
//
//                latResults[i] = latitude;
//                lonResults[i] = longitude;
//                altResults[i] = altitude;
//            }
//
//            ec.setLastUtcMilliseconds(utcMilliseconds);
//            ec.setLatitudes(latResults);
//            ec.setLongitudes(lonResults);
//            ec.setAltitudes(altResults);
//        }

        return hasEvenSingleUpdate;
    }

    private void renderEscalatorsInTile(GLViewport v,
                                        Escalator escalator,
                                        MapTileJob tile) {
        this.prepareEscalatorCacheIfNotExists(escalator);
        EscalatorContext ec = this.contextPerEscalatorIfNotExists(escalator);

        int z = tile.zoomLevel;
        MapPosition pos = v.pos;
        double tileScale = Tile.SIZE * v.pos.scale;

        float scale = (float) (pos.scale / (1 << z));

        double[] latitudes = ec.getLatitudes();
        double[] longitudes = ec.getLongitudes();
        double[] altitudes = ec.getAltitudes();

        if (latitudes == null) {
            return;
        }// Clock inside is not updated yet.

        int plateCount = latitudes.length;

        int indexCount = plateCount * 6;
        short[] indices = new short[indexCount];
        for (int i = 0; i < plateCount; i++) {
            int indexBase = i * 6;
            int vertexBase = i * 4;

            indices[indexBase + 0] = (short) (vertexBase + 0);
            indices[indexBase + 1] = (short) (vertexBase + 1);
            indices[indexBase + 2] = (short) (vertexBase + 2);
            indices[indexBase + 3] = (short) (vertexBase + 1);
            indices[indexBase + 4] = (short) (vertexBase + 2);
            indices[indexBase + 5] = (short) (vertexBase + 3);
        }

        double extrusionBearing = escalator.getExtrusionBearing();
        double extrudeWidth = escalator.getExtrusionWidth();
        double plateDepth = escalator.getPlateDepth();

        int vertexCount = plateCount * 4;
        float[] vertices = new float[vertexCount * 3];
        for (int i = 0; i < plateCount; i++) {
            double latitude = latitudes[i];
            double longitude = longitudes[i];
            double altitude = altitudes[i];

            double stretchedAltitude = (float) this.altitudeStretcher.getStretchedAltitude(altitude);
            float stretchedMapAffineZ0 = scale * (float) stretchedAltitude;

            double objAbsRateX = MercatorProjection.longitudeToX(longitude);
            double objAbsRateY = MercatorProjection.latitudeToY(latitude);
            double rateXDelta = objAbsRateX - pos.x;
            double rateYDelta = objAbsRateY - pos.y;
            float mapAffineX = (float) (rateXDelta * tileScale);
            float mapAffineY = (float) (rateYDelta * tileScale);

            vertices[i * 12 + 0] = mapAffineX;
            vertices[i * 12 + 1] = mapAffineY;
            vertices[i * 12 + 2] = stretchedMapAffineZ0;

            GeodesicData d;
            synchronized (Geodesic.WGS84) {
                d = Geodesic.WGS84.Direct(latitude, longitude, extrusionBearing, extrudeWidth);
            }
            double olat = d.lat2;
            double olon = d.lon2;

            double oobjAbsRateX = MercatorProjection.longitudeToX(olon);
            double oobjAbsRateY = MercatorProjection.latitudeToY(olat);
            double orateXDelta = oobjAbsRateX - pos.x;
            double orateYDelta = oobjAbsRateY - pos.y;
            float omapAffineX = (float) (orateXDelta * tileScale);
            float omapAffineY = (float) (orateYDelta * tileScale);

            vertices[i * 12 + 3] = omapAffineX;
            vertices[i * 12 + 4] = omapAffineY;
            vertices[i * 12 + 5] = stretchedMapAffineZ0;

            synchronized (Geodesic.WGS84) {
                d = Geodesic.WGS84.Direct(latitude, longitude, extrusionBearing + 90, plateDepth);
            }
            double alat = d.lat2;
            double alon = d.lon2;

            double aobjAbsRateX = MercatorProjection.longitudeToX(alon);
            double aobjAbsRateY = MercatorProjection.latitudeToY(alat);
            double arateXDelta = aobjAbsRateX - pos.x;
            double arateYDelta = aobjAbsRateY - pos.y;
            float amapAffineX = (float) (arateXDelta * tileScale);
            float amapAffineY = (float) (arateYDelta * tileScale);

            vertices[i * 12 + 6] = amapAffineX;
            vertices[i * 12 + 7] = amapAffineY;
            vertices[i * 12 + 8] = stretchedMapAffineZ0;
            synchronized (Geodesic.WGS84) {
                d = Geodesic.WGS84.Direct(olat, olon, extrusionBearing + 90, plateDepth);
            }
            double blat = d.lat2;
            double blon = d.lon2;

            double bobjAbsRateX = MercatorProjection.longitudeToX(blon);
            double bobjAbsRateY = MercatorProjection.latitudeToY(blat);
            double brateXDelta = bobjAbsRateX - pos.x;
            double brateYDelta = bobjAbsRateY - pos.y;
            float bmapAffineX = (float) (brateXDelta * tileScale);
            float bmapAffineY = (float) (brateYDelta * tileScale);

            vertices[i * 12 + 9] = bmapAffineX;
            vertices[i * 12 + 10] = bmapAffineY;
            vertices[i * 12 + 11] = stretchedMapAffineZ0;
        }

        FloatBuffer verticesBuffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        verticesBuffer.put(vertices).position(0);

        ShortBuffer indicesBuffer = ByteBuffer.allocateDirect(indices.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
        indicesBuffer.put(indices).position(0);

        v.mvp.setIdentity();

        // Fix-ups before drawing elements
        v.mvp.multiplyLhs(v.viewproj);
        v.mvp.setAsUniform(primitiveShader.uMVP);

        GLUtils.setColor(primitiveShader.uColor, Color.BLUE, 0.9f);
        gl.vertexAttribPointer(primitiveShader.aPos, 3, GL.FLOAT, false, 0, verticesBuffer); // 3 = 3-dimensional
        gl.drawElements(GL.TRIANGLES, indices.length, GL.UNSIGNED_SHORT, indicesBuffer);

        GLUtils.setColor(primitiveShader.uColor, Color.CYAN, 0.9f);
        gl.lineWidth(1);
        gl.drawElements(GL.LINES, indices.length, GL.UNSIGNED_SHORT, indicesBuffer);
    }

    private void renderSlopesInTile(GLViewport v,
                                    Slope slope,
                                    MapTileJob tile) {
        double extrusionBearing = slope.getExtrusionBearing();
        double extrusionWidth = slope.getExtrusionWidth();

        int z = tile.zoomLevel;

        MapPosition pos = v.pos;
        double tileScale = Tile.SIZE * v.pos.scale;

        float heightScale = (float) (v.pos.scale / (1 << z));

        short[] indices = new short[]{0, 1, 2, 3};

        double fromLatitude = slope.getFromLatitude();
        double fromLongitude = slope.getFromLongitude();
        double fromAltitude = slope.getFromAltitude();
        double toLatitude = slope.getToLatitude();
        double toLongitude = slope.getToLongitude();
        double toAltitude = slope.getToAltitude();


        GeodesicData ad;
        synchronized (Geodesic.WGS84) {
            ad = Geodesic.WGS84.Direct(fromLatitude, fromLongitude, extrusionBearing, extrusionWidth);
        }
        double alat = ad.lat2;
        double alon = ad.lon2;

        GeodesicData bd;
        synchronized (Geodesic.WGS84) {
            bd = Geodesic.WGS84.Direct(toLatitude, toLongitude, extrusionBearing, extrusionWidth);
        }
        double blat = bd.lat2;
        double blon = bd.lon2;

        double stretchedAltitude0 = this.altitudeStretcher.getStretchedAltitude(fromAltitude);
        float z0 = heightScale * (float) stretchedAltitude0;
        double tstretchedAltitude0 = this.altitudeStretcher.getStretchedAltitude(toAltitude);
        float z1 = heightScale * (float) tstretchedAltitude0;

        double objAbsRateX = MercatorProjection.longitudeToX(fromLongitude);
        double objAbsRateY = MercatorProjection.latitudeToY(fromLatitude);
        double rateXDelta = objAbsRateX - pos.x;
        double rateYDelta = objAbsRateY - pos.y;
        float x0 = (float) (rateXDelta * tileScale);
        float y0 = (float) (rateYDelta * tileScale);

        double tobjAbsRateX = MercatorProjection.longitudeToX(toLongitude);
        double tobjAbsRateY = MercatorProjection.latitudeToY(toLatitude);
        double trateXDelta = tobjAbsRateX - pos.x;
        double trateYDelta = tobjAbsRateY - pos.y;
        float x1 = (float) (trateXDelta * tileScale);
        float y1 = (float) (trateYDelta * tileScale);

        double aobjAbsRateX = MercatorProjection.longitudeToX(alon);
        double aobjAbsRateY = MercatorProjection.latitudeToY(alat);
        double arateXDelta = aobjAbsRateX - pos.x;
        double arateYDelta = aobjAbsRateY - pos.y;
        float x2 = (float) (arateXDelta * tileScale);
        float y2 = (float) (arateYDelta * tileScale);

        double bobjAbsRateX = MercatorProjection.longitudeToX(blon);
        double bobjAbsRateY = MercatorProjection.latitudeToY(blat);
        double brateXDelta = bobjAbsRateX - pos.x;
        double brateYDelta = bobjAbsRateY - pos.y;
        float x3 = (float) (brateXDelta * tileScale);
        float y3 = (float) (brateYDelta * tileScale);

        float[] vertices = new float[]{
                x0, y0, z0,
                x1, y1, z1,
                x2, y2, z0,
                x3, y3, z1
        };

        FloatBuffer verticesBuffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        verticesBuffer.put(vertices).position(0);

        ShortBuffer indicesBuffer = ByteBuffer.allocateDirect(indices.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
        indicesBuffer.put(indices).position(0);

        gl.vertexAttribPointer(primitiveShader.aPos, 3, GL.FLOAT, false, 0, verticesBuffer); // 3 = 3-dimensional

        v.mvp.setIdentity();

        // Fix-ups before drawing elements
        v.mvp.multiplyLhs(v.viewproj);
        v.mvp.setAsUniform(primitiveShader.uMVP);

        GLUtils.setColor(primitiveShader.uColor, Color.LTGRAY, 1.0f);
        gl.drawElements(GL.TRIANGLE_STRIP, indices.length, GL.UNSIGNED_SHORT, indicesBuffer);

        GLUtils.setColor(primitiveShader.uColor, Color.BLACK, 0.5f);
        gl.drawElements(GL.LINE_STRIP, indices.length, GL.UNSIGNED_SHORT, indicesBuffer);
    }

    private void renderElevatorsInTile(GLViewport v,
                                       Elevator elevator,
                                       MapTileJob tile, double fromAltitude, double toAltitude
    ) {
        int z = tile.zoomLevel;

        MapPosition pos = v.pos;
        double tileScale = Tile.SIZE * v.pos.scale;

        float heightScale = (float) (v.pos.scale / (1 << z));

        double stretchedAltitude0 = this.altitudeStretcher.getStretchedAltitude(fromAltitude);
        double tstretchedAltitude0 = this.altitudeStretcher.getStretchedAltitude(toAltitude);
        if (stretchedAltitude0 > tstretchedAltitude0) {
            stretchedAltitude0 += 2;
        } else {
            tstretchedAltitude0 += 2;
        }
        float alt0 = heightScale * (float) stretchedAltitude0;
        float alt1 = heightScale * (float) tstretchedAltitude0;

        double[] coords = elevator.getLlseq();
        double lat0 = coords[1];
        double lon0 = coords[0];
        double lat1 = coords[3];
        double lon1 = coords[2];
        double lat2 = coords[5];
        double lon2 = coords[4];
        double lat3 = coords[7];
        double lon3 = coords[6];

        double objAbsRateX = MercatorProjection.longitudeToX(lon0);
        double objAbsRateY = MercatorProjection.latitudeToY(lat0);
        double rateXDelta = objAbsRateX - pos.x;
        double rateYDelta = objAbsRateY - pos.y;
        float x0 = (float) (rateXDelta * tileScale);
        float y0 = (float) (rateYDelta * tileScale);

        double tobjAbsRateX = MercatorProjection.longitudeToX(lon1);
        double tobjAbsRateY = MercatorProjection.latitudeToY(lat1);
        double trateXDelta = tobjAbsRateX - pos.x;
        double trateYDelta = tobjAbsRateY - pos.y;
        float x1 = (float) (trateXDelta * tileScale);
        float y1 = (float) (trateYDelta * tileScale);

        double aobjAbsRateX = MercatorProjection.longitudeToX(lon2);
        double aobjAbsRateY = MercatorProjection.latitudeToY(lat2);
        double arateXDelta = aobjAbsRateX - pos.x;
        double arateYDelta = aobjAbsRateY - pos.y;
        float x2 = (float) (arateXDelta * tileScale);
        float y2 = (float) (arateYDelta * tileScale);

        double bobjAbsRateX = MercatorProjection.longitudeToX(lon3);
        double bobjAbsRateY = MercatorProjection.latitudeToY(lat3);
        double brateXDelta = bobjAbsRateX - pos.x;
        double brateYDelta = bobjAbsRateY - pos.y;
        float x3 = (float) (brateXDelta * tileScale);
        float y3 = (float) (brateYDelta * tileScale);

        float[] vertices = new float[]{
                x0, y0, alt0,
                x1, y1, alt0,
                x3, y3, alt0,
                x2, y2, alt0,
                x0, y0, alt1,
                x1, y1, alt1,
                x3, y3, alt1,
                x2, y2, alt1
        };

        FloatBuffer verticesBuffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        verticesBuffer.put(vertices).position(0);

        v.mvp.setIdentity();

        // Fix-ups before drawing elements
        v.mvp.multiplyLhs(v.viewproj);
        v.mvp.setAsUniform(primitiveShader.uMVP);

        GLUtils.setColor(primitiveShader.uColor, Color.WHITE, 0.5f);
        gl.vertexAttribPointer(primitiveShader.aPos, 3, GL.FLOAT, false, 0, verticesBuffer); // 3 = 3-dimensional
        gl.drawElements(GL.TRIANGLE_STRIP, cubeIndicesBufferLength, GL.UNSIGNED_SHORT, 0);

        GLUtils.setColor(primitiveShader.uColor, Color.DKGRAY, 0.5f);
        gl.drawElements(GL.LINE_STRIP, cubeIndicesBufferLength, GL.UNSIGNED_SHORT, 0);
    }

    class PlatformContent {
        public Point point;
        public Platform platform;
        public double width;
        public double height;
        public int yOffset;
        public int xOffset;

        public PlatformContent() {
            point = new Point();
        }

        @Override
        public String toString() {
            return platform.getName();
        }
    }

    private float[] coordPool = new float[]{0, 0, 0};

    private void generatePlatformContents(GLViewport v, Platform platform, MapTileJob tile, Set<PlatformContent> platformContents) {
        int z = tile.zoomLevel;
        MapPosition pos = v.pos;
        double tileScale = Tile.SIZE * v.pos.scale;
        float heightScale = (float) (v.pos.scale / (1 << z));

        Collection<Platform.Point> platformPoints = platform.getPoints();
        if (platformPoints == null) {
            return;
        }
        Platform.Point point = platformPoints.iterator().next();
        if (point == null) {
            return;
        }
        double originalAltitude = point.getAltitude();
        double stretchedAltitude = this.altitudeStretcher.getStretchedAltitude(originalAltitude);
        float mapAffineX = getMapAffineX(point.getLongitude(), tileScale, pos);
        float mapAffineY = getMapAffineY(point.getLatitude(), tileScale, pos);
        float mapAffineZ = heightScale * (float) stretchedAltitude;

        v.mvp.setIdentity();
        mTmpMatrix.setTranslation(mapAffineX, mapAffineY, mapAffineZ);
        v.mvp.multiplyLhs(mTmpMatrix);
        v.mvp.multiplyLhs(v.viewproj);

        coordPool[0] = 0;
        coordPool[1] = 0;
        coordPool[2] = 0;
        v.mvp.prj(coordPool); // Project

        if (coordPool[0] > 1 || coordPool[0] < -1 || coordPool[1] > 1 || coordPool[1] < -1) {
            return;
        }

        double xrate = coordPool[0] * 0.5 + 0.5;
        double yrate = coordPool[1] * 0.5 + 0.5;
        double xpos = v.getWidth() * xrate;
        double ypos = v.getHeight() * yrate;

        // Build label context
        try {
            PlatformContent pc = new PlatformContent();
            pc.platform = platform;
            pc.point.x = xpos;
            pc.point.y = ypos;
            platformContents.add(pc);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void generatePlatformTextures(Iterable<PlatformContent> ipcs) {
        TextureItem t = pool.get();
        t.bitmap.eraseColor(0xff222222);
        mCanvas.setBitmap(t.bitmap);
        textureYPointOffset = 0;
        currentPlatformContents.clear();
        for (PlatformContent pc : ipcs) {
            this.generatePlatformTexture(pc, mCanvas);
            this.currentPlatformContents.put(pc.toString(), pc);
        }
        t.bitmap.uploadToTexture(true);
    }

    private void generatePlatformTexture(PlatformContent pc, Canvas canvas) {
        String platformName = pc.platform.getName();

        double platformWidth = platformPaint.measureText(platformName);

        float xd0 = 0;
        float xd1 = xd0 + (float) platformWidth + 10;
        float yd0 = 0;
        float yd1 = yd0 + platform_height;

        // Allocating texture region
        double textureHeight = yd1;
        double textureWidth = xd1;

        canvas.drawText(platformName, xd0 + 5, yd0 + textureYPointOffset + platform_height - 3, platformPaint, null);

        pc.width = textureWidth;
        pc.height = textureHeight;
        pc.xOffset = 0;
        pc.yOffset = textureYPointOffset;

        textureYPointOffset += textureHeight;
    }

    private float[] textCoords = new float[8];
    float[] vertices = new float[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    short[] indices = new short[]{0, 1, 2, 3};
    FloatBuffer verticesBuffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    ShortBuffer indicesBuffer = ByteBuffer.allocateDirect(indices.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();

    private void renderPlatform(PlatformContent pc, double width, double height, int xOffset, int yOffset, GLViewport v) {
        GLState.blend(true);
        GLState.test(true, false);
        gl.depthFunc(GL.ALWAYS);
        gl.depthMask(true);

        textureShader.useProgram();

        v.mvp.setIdentity();
        v.mvp.setAsUniform(textureShader.uMVP);

        gl.uniform1f(textureShader.uAlpha, 1f);

        // Disable VBO/IBO
        GLState.bindElementBuffer(0);
        GLState.bindVertexBuffer(0);

        // Set texture ranges
        float minX = (float) xOffset;
        float maxX = (float) ((xOffset + width) / (float) TEXTURE_WIDTH);
        float minY = (float) yOffset / (float) TEXTURE_HEIGHT;
        float maxY = (float) ((yOffset + height) / TEXTURE_HEIGHT);
        textCoords[0] = minX;
        textCoords[1] = maxY;
        textCoords[2] = minX;
        textCoords[3] = minY;
        textCoords[4] = maxX;
        textCoords[5] = maxY;
        textCoords[6] = maxX;
        textCoords[7] = minY;

        // Set vertex ranges
        float pointxmin = (float) (pc.point.x - width / 2);
        float pointxmax = (float) (pc.point.x + width / 2);
        float pointymin = (float) (pc.point.y - height / 2);
        float pointymax = (float) (pc.point.y + height / 2);
        float xmin = (float) ((pointxmin / v.getWidth()) * 2.0 - 1.0);
        float xmax = (float) ((pointxmax / v.getWidth()) * 2.0 - 1.0);
        float ymin = (float) ((pointymin / v.getHeight()) * 2.0 - 1.0);
        float ymax = (float) ((pointymax / v.getHeight()) * 2.0 - 1.0);

        vertices[0] = xmin;
        vertices[1] = ymin;
        vertices[3] = xmin;
        vertices[4] = ymax;
        vertices[6] = xmax;
        vertices[7] = ymin;
        vertices[9] = xmax;
        vertices[10] = ymax;

        verticesBuffer.put(vertices).position(0);
        indicesBuffer.put(indices).position(0);

        planeTexCoordBuffer.put(textCoords).position(0);
        gl.vertexAttribPointer(textureShader.aTexCoord, 2, GL.FLOAT, false, 0, planeTexCoordBuffer);

        gl.vertexAttribPointer(textureShader.aPos, 3, GL.FLOAT, false, 0, verticesBuffer); // 3 = 3-dimensional
        gl.drawElements(GL.TRIANGLE_STRIP, indices.length, GL.UNSIGNED_SHORT, indicesBuffer);

    }

    private void renderAmenitiesInTile(GLViewport v, Amenity amenity, MapTileJob tile) {

    }
}
