package com.ogiqvo;

import org.oscim.layers.tile.MapTileJob;
import org.oscim.tiling.ITileDataLoadCallbackable;
import org.oscim.tiling.ITileDataSource;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import static org.oscim.tiling.ITileDataLoadCallbackable.QueryResult.FAILED;
import static org.oscim.tiling.ITileDataLoadCallbackable.QueryResult.SUCCESS;

/**
 * Created by xor on 15/11/29.
 */
public class ConstantByteArrayPlateStackTileDataSource implements ITileDataSource {
    final byte[] bytes;
    private final PlateStackTileDecoder decoder;

    public ConstantByteArrayPlateStackTileDataSource(byte[] bytes) {
        this.bytes = bytes;
        this.decoder = new PlateStackTileDecoder();
    }

    @Override
    public void queryTileJobOnLoadingThread(MapTileJob tile, ITileDataLoadCallbackable sink) {
//        boolean ok = this.tileLoadable.loadCommitTileIntoPool(ct, this.pool);
        try {
            this.decoder.decodeOnLoadingThread(tile, sink, new ByteArrayInputStream(this.bytes));
            sink.notifyToLoaderThatLoadingIsCompleteOnLoadingThread(SUCCESS);
        } catch (IOException e) {
            e.printStackTrace();
            sink.notifyToLoaderThatLoadingIsCompleteOnLoadingThread(FAILED);
        }
    }

    @Override
    public void dispose() {

    }

    @Override
    public void cancel() {

    }
}
