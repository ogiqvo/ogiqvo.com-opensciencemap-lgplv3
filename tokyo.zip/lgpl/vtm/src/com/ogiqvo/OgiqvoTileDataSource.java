package com.ogiqvo;

import com.ogiqvo.lib.Pool;
import com.ogiqvo.lib.Tile;
import com.ogiqvo.lib.loader.ITileLoadable;
import com.ogiqvo.lib.pool.CommitTile;

import org.oscim.layers.tile.MapTileJob;
import org.oscim.tiling.ITileDataLoadCallbackable;
import org.oscim.tiling.ITileDataSource;

import static org.oscim.tiling.ITileDataLoadCallbackable.QueryResult.FAILED;
import static org.oscim.tiling.ITileDataLoadCallbackable.QueryResult.SUCCESS;

/**
 * Created by xor on 15/11/11.
 */
public class OgiqvoTileDataSource implements ITileDataSource {
    Pool pool;
    ITileLoadable tileLoadable;
    String commitId;

    public OgiqvoTileDataSource(Pool pool, ITileLoadable tileLoadable, String commitId) {
        this.pool = pool;
        this.tileLoadable = tileLoadable;
        this.commitId = commitId;
    }

    @Override
    public void queryTileJobOnLoadingThread(MapTileJob tile, ITileDataLoadCallbackable sink) {
        Tile t = new Tile(tile.zoomLevel, tile.tileX, tile.tileY);
        CommitTile ct = new CommitTile(t, this.commitId);
        boolean ok = this.tileLoadable.loadCommitTileIntoPool(ct, this.pool);
        sink.notifyToLoaderThatLoadingIsCompleteOnLoadingThread(ok ? SUCCESS : FAILED);
    }

    @Override
    public void dispose() {

    }

    @Override
    public void cancel() {

    }
}
