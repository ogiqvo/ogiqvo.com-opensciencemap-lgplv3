package com.ogiqvo;

import com.ogiqvo.lib.bean.Platform;

import org.oscim.layers.tile.TileLoadingThread;
import org.oscim.layers.tile.TileManager;
import org.oscim.map.Map;
import org.oscim.tiling.ITileDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xor on 05/04/15.
 */
public class OgiqvoTileLayer extends OnCompleteHooksCallableTileLayer {
    static final Logger log = LoggerFactory.getLogger(OgiqvoTileLayer.class);

    private final static int MAX_CACHE = 32;
    public final static int SRC_MIN_ZOOM = 16;
    public final static int SRC_MAX_ZOOM = 16;

    private final OgiqvoTileLoadingThread tileLoader;
    private final OgiqvoTileRenderer tileRenderer;

    public OgiqvoTileLayer(Map map, ITileDataSource tileDataSource) {
        super(map, new TileManager(map, MAX_CACHE));
        this.tileRenderer = new OgiqvoTileRenderer();
        setRenderer(this.tileRenderer);

        tileManager.setZoomLevel(SRC_MIN_ZOOM, SRC_MAX_ZOOM);
        this.tileLoader = new OgiqvoTileLoadingThread(tileManager, tileDataSource, this);
        initAndStartLoadingThreadsOnMainThread(1);
    }

    public OgiqvoTileLoadingThread getLoader() {
        return this.tileLoader;
    }

    @Override
    protected TileLoadingThread createLoaderOnMainThread() {
        return this.tileLoader;
    }

    @Override
    public boolean onTap(float x, float y, float minx, float maxx, float miny, float maxy) {
        List<Platform> platforms = new ArrayList<>();
//        this.tileRenderer.fillPlatformsInExtent(x, y, minx, maxx, miny, maxy, platforms);

        log.debug("platforms {}", platforms);

        return false;
    }
}
