package com.ogiqvo;

import org.oscim.layers.Layer;
import org.oscim.map.Map;

/**
 * Created by xor on 15/05/18.
 */
public class Tile3GridLayer extends Layer {
    Tile3GridRenderer tile3GridRenderer;

    public Tile3GridLayer(Map map) {
        super(map);

        this.tile3GridRenderer = new Tile3GridRenderer();
        this.setLayerRenderer(this.tile3GridRenderer);
    }
}
