package com.ogiqvo;

import com.ogiqvo.lib.Cube;
import com.ogiqvo.lib.Pool;
import com.ogiqvo.lib.Tile;
import com.ogiqvo.lib.Timechunk;
import com.ogiqvo.lib.bean.Carmodel;
import com.ogiqvo.lib.bean.Formation;
import com.ogiqvo.lib.bean.Lnglat;
import com.ogiqvo.lib.bean.edgeset.Base;
import com.ogiqvo.lib.loader.ICubeLoadable;
import com.ogiqvo.lib.pool.CommitCube;
import com.ogiqvo.lib.pool.CommitTile;
import com.owens.oobjloader.builder.Build;
import com.owens.oobjloader.lwjgl.Scene;
import com.owens.oobjloader.parser.Parse;

import org.oscim.event.Event;
import org.oscim.layers.Layer;
import org.oscim.layers.tile.MapTileJob;
import org.oscim.layers.tile.TileManager;
import org.oscim.utils.pool.Inlist;
import org.oscim.utils.pool.LList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OgiqvoCubeLayer extends Layer implements TileManager.TileManagerEventListener,TileManager.ScannedMapTileUpdateEventListener {
    static final Logger log = LoggerFactory.getLogger(OgiqvoCubeLayer.class);

    private final Object nullCarmodelStructObj = new Object();

    private final OgiqvoCubeRenderer cubeRenderer;
    private final Pool pool;
    private final String commitId;
    private final ICubeLoadable cubeLoadable;

    private final double MILLISECONDS_PER_TIMECHUNK = 20000.0;
    private final double MILLISECONDS_PER_DAY = 86400000.0;
    private final double TIMECHUNKS_PER_DAY = MILLISECONDS_PER_DAY / MILLISECONDS_PER_TIMECHUNK;
    private final int READING_AHEAD_TIMECHUNK_COUNT = 1;

    private int currentBaseTimechunk;
    private Collection<CommitTile> currentCommitTiles;
    private List<FormationContext> formationContexts = null;

    private long lastRenderedUtcMilliseconds = 0;
    private int lastRenderedDay1970 = 0;
    private int lastRenderedFormationContextsHash = 0;

    private final ExecutorService httpLoaderExecutorService;
    private final Queue<CommitCube> httpLoadedCommitCubes;

    final ParentLoopRunner parentLoopRunner;
    final Map<String, FormationContext> formation2context = new ConcurrentHashMap<>();

    private final BlockingQueue<Object> parentLoopRunnerNotifyingTaskQueue;
    private final Object parentLoopRunnerNotifyingObject = new Object();
    private final ExecutorService parentLoopRunnerExecutor;

    public OgiqvoCubeLayer(org.oscim.map.Map map, Pool pool, String commitId, OgiqvoTileLayer baseTileLayer, ICubeLoadable cubeLoadable) {
        super(map);

        this.cubeRenderer = new OgiqvoCubeRenderer();
        this.cubeRenderer.setTileManager(baseTileLayer.getTileManager());
        setLayerRenderer(this.cubeRenderer);

        TileManager tileManager = baseTileLayer.getTileManager();
        tileManager.getTileManagerEventOnMainThreadDispatcher().listen(this);
        baseTileLayer.addHook(new CubeSocketFilterHook());
        tileManager.getScannedMapTileUpdateOnMainThreadDispatcher().listen(this);

        // Directly copy references given as arguments
        this.pool = pool;
        this.commitId = commitId;
        this.cubeLoadable = cubeLoadable;

        // Current states
        this.currentCommitTiles = new CopyOnWriteArrayList<>();

        // Prepare HTTP workers and structures
        this.httpLoaderExecutorService = Executors.newFixedThreadPool(2);
        this.httpLoadedCommitCubes = new ConcurrentLinkedQueue<>(); // ConcurrentLinkQueue is used because it doesn't block. http://stackoverflow.com/questions/1301691/java-queue-implementations-which-one

        // Executor services
        this.parentLoopRunnerNotifyingTaskQueue = new ArrayBlockingQueue<>(1);
        this.parentLoopRunner = new ParentLoopRunner();
        this.parentLoopRunnerExecutor = Executors.newFixedThreadPool(1);
        this.parentLoopRunnerExecutor.submit(this.parentLoopRunner);
    }

    private URLConnection openConnection(String url) throws IOException {
        log.debug("Request {}", url);
        return new URL(url).openConnection();
    }

    @Override
    public void onTileManagerEvent(Event event, MapTileJob tile) {
        // Do nothing.
    }

    /**
     * Called when loading tile has done loading.
     */
    class CubeSocketFilterHook implements OgiqvoTileLayer.TileLoaderHook {
        @Override
        public void complete(MapTileJob tile, boolean success) {
            CommitTile ct = OgiqvoCubeLayer.this.returnCommitTileIfTimechunkRangeExistsForTile(tile);
            if (ct == null) {
                return;
            }
            currentCommitTiles.add(ct);
            parentLoopRunner.setIsTileUpdated();
            tryToNotifyParentLoopRunner();
        }
    }

    /**
     * Called when tile list in view are updated. It may not need to load new cubes from server, but
     * current commit tiles will be updated.
     */
    @Override
    public void onScannedMapTileUpdated(Event event, MapTileJob[] tiles) {
        currentCommitTiles.clear();
        for (MapTileJob tile : tiles) {
            CommitTile ct = returnCommitTileIfTimechunkRangeExistsForTile(tile);
            if (ct == null) {
                continue;
            }
            currentCommitTiles.add(ct);
        }
        parentLoopRunner.setIsTileUpdated();
        tryToNotifyParentLoopRunner();
    }

    /**
     * Called from main thread.
     * @param utcMilliseconds
     */
    public void onClockUpdated(final long utcMilliseconds) {
        parentLoopRunner.setUtcMilliseconds(utcMilliseconds);
        tryToNotifyParentLoopRunner();
    }

    boolean notifiedDeadlock = false;
    private void tryToNotifyParentLoopRunner() {
        try {
            parentLoopRunnerNotifyingTaskQueue.add(parentLoopRunnerNotifyingObject); // Putting object to blocking queue will notify().
        } catch (IllegalStateException ex) {
            long realUtcMilliseconds = System.currentTimeMillis();
            long frozenMillisecondsDelta = realUtcMilliseconds - this.parentLoopRunner.processingRealUtcMilliseconds;
            if (frozenMillisecondsDelta > 2000) {
                if(!notifiedDeadlock) {
                    String err = "Waiting " + realUtcMilliseconds + "-" + this.parentLoopRunner.processingRealUtcMilliseconds + "=" + frozenMillisecondsDelta + " milliseconds! Probably it's deadlocked";
                    log.error(err);
                    notifiedDeadlock = true;
                }
            }
        } // If queue is full, exception will be thrown.
    }

    class ParentLoopRunner implements Runnable {
        long processingRealUtcMilliseconds = 0;
        long utcMilliseconds = 0;
        boolean isTileUpdated = false;

        public void setIsTileUpdated() {
            this.isTileUpdated = true;
        }

        public void setUtcMilliseconds(long utcMilliseconds) {
            this.utcMilliseconds = utcMilliseconds;
        }

        /**
         * Run on parent thread
         */
        @Override
        public void run() {
            while (true) {
                try {
                    parentLoopRunnerNotifyingTaskQueue.take(); // Blocking here
                    processingRealUtcMilliseconds = System.currentTimeMillis();

                    long dayUtcMilliseconds = Timechunk.dayUtcMillisecondsFromUtcMilliseconds(utcMilliseconds);
                    int newBaseTimechunk = Timechunk.timechunkForDayUtcMilliseconds(dayUtcMilliseconds, Commit.TIMECHUNK_MILLISECONDS);
                    int formationContextHash = lastRenderedFormationContextsHash;

                    if (OgiqvoCubeLayer.this.currentBaseTimechunk != newBaseTimechunk || this.isTileUpdated) {
                        OgiqvoCubeLayer.this.currentBaseTimechunk = newBaseTimechunk;
                        this.isTileUpdated = false;
                        OgiqvoCubeLayer.this.prepareAndLoadCubesOnParentThread(OgiqvoCubeLayer.this.currentBaseTimechunk);
                        formationContexts = OgiqvoCubeLayer.this.gatherFcsForCurrentCommitTilesOnParentThread();
                        formationContextHash = formationContextsHashFrom(formationContexts);
                    } else if (OgiqvoCubeLayer.this.isNewCommitCubeWaitingOnParentThread()) {
                        formationContexts = OgiqvoCubeLayer.this.gatherFcsForCurrentCommitTilesOnParentThread();
                        formationContextHash = formationContextsHashFrom(formationContexts);
                    }

                    // If there are available formation contexts, update bogie distances and render.
                    if (formationContexts != null) {
                        OgiqvoCubeLayer.this.updateBogieDistancesAndRequestRenderingOnParentThread(utcMilliseconds, formationContexts, formationContextHash);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int formationContextsHashFrom(List<FormationContext> formationContexts){
        int h = 0;
        int length = formationContexts.size();
        for (int fci = 0; fci < length; fci++) {
            FormationContext formationContext = formationContexts.get(fci);
            h ^= formationContext.getFormation().hashCode();
        }
        return h;
    }

    /**
     * Call "try" requests for each required cubes.
     */
    private void prepareAndLoadCubesOnParentThread(int baseTimechunk) {
        Set<CommitCube> ccs = new HashSet<>();
        for (CommitTile commitTile : currentCommitTiles) {
            int minTimechunk = this.pool.minTimechunkForCommitTile(commitTile);
            int maxTimechunk = this.pool.maxTimechunkForCommitTile(commitTile);
            int minDayDelta = (int) Math.floor(minTimechunk / MILLISECONDS_PER_TIMECHUNK);
            int maxDayDelta = (int) Math.floor(maxTimechunk / MILLISECONDS_PER_TIMECHUNK);
            for (int d = minDayDelta; d <= maxDayDelta; d++) {
                int dayBaseTimechunk = baseTimechunk + d * (int) TIMECHUNKS_PER_DAY;
                if (dayBaseTimechunk < minTimechunk || dayBaseTimechunk > maxTimechunk) {
                    continue;
                }
                for (int ahead = -READING_AHEAD_TIMECHUNK_COUNT; ahead < READING_AHEAD_TIMECHUNK_COUNT + 1; ahead++) {
                    int timechunk = dayBaseTimechunk + ahead;
                    Tile tile = commitTile.getTile();
                    Cube c = new Cube(tile, timechunk);
                    CommitCube cc = new CommitCube(c, commitTile.getCommitId());
                    ccs.add(cc);
                }
            }
        }

        this.requestCubesLoad(ccs);
    }

    private void requestCubesLoad(final Set<CommitCube> ccs) {
        HttpLoaderExecutorRunnable r = new HttpLoaderExecutorRunnable(ccs);
        httpLoaderExecutorService.execute(r);
    }

    class HttpLoaderExecutorRunnable implements Runnable,Pool.OnEachCommitCubeLoadedCallback {
        Set<CommitCube> ccs;

        public HttpLoaderExecutorRunnable(Set<CommitCube> ccs) {
            this.ccs = ccs;
        }

        @Override
        public void run() {
            // onCommitCubeLoaded() will be called after each cube loading
            OgiqvoCubeLayer.this.pool.refreshCubeSet(ccs, OgiqvoCubeLayer.this.cubeLoadable, this);
        }

        @Override
        public void onCommitCubeLoaded(CommitCube cc) {
            // Load carmodels binded to each carmodel
            Pool.PerCommitCube pcc = OgiqvoCubeLayer.this.pool.perCommitCubeForCommitCube(cc);
            if (pcc != null) {
                for (Carmodel carmodel : pcc.referringCarmodels) {
                    this.parseAndFillCarmodelModelsIfNotExists(carmodel);
                }
                httpLoadedCommitCubes.add(cc); // Loader thread -> main thread bridge
            }
        }

        private void parseAndFillCarmodelModelsIfNotExists(Carmodel carmodel) {
            synchronized (carmodel) {
                byte[] cm3d = carmodel.getCm3dData();
                String cm3dMime = carmodel.getCm3dDataMime();
                if (cm3d == null || cm3dMime == null) {
                    // Carmodel doesn't contain explicit 3d model
                    return;
                }
                if (carmodel.getCm3dStruct() != null) {
                    // 3d model is already prepared
                    return;
                }
                Object structObj = null;
                switch (cm3dMime) {
                    case "text/url-list":
                        try {
                            for (String url : this.getStringListFromBytes(cm3d)) {
                                URLConnection conn = OgiqvoCubeLayer.this.openConnection(url);
                                InputStream is = conn.getInputStream();
                                String mime = conn.getHeaderField("Content-Type");
                                structObj = this.parseAndFillCarmodelModelForNonUrl(is, mime, url);
                                break;
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        InputStream is = new ByteArrayInputStream(cm3d);
                        structObj = this.parseAndFillCarmodelModelForNonUrl(is, cm3dMime, carmodel.getCid());
                        break;
                }
                carmodel.setCm3dStruct(structObj);
            }
        }

        private Collection<String> getStringListFromBytes(byte[] bytes) throws IOException {
            Collection<String> urls = new HashSet<>();
            BufferedReader r = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(bytes)));
            String line;
            while ((line = r.readLine()) != null) {
                urls.add(line.trim());
            }
            return urls;
        }

        private Object parseAndFillCarmodelModelForNonUrl(InputStream is, String mime, String filename) {
            switch (mime) {
                // Wavefront obj
                case "text/plain":
                    Parse parser = new Parse();
                    Build reader = new Build();
                    try {
                        Scene scene = parser.parse(reader, is, filename);
                        return scene;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                default:
                    log.debug("Found mime {}", mime);
                    // If you let struct empty, it will be misunderstood that struct is not loaded yet.
                    return nullCarmodelStructObj;
            }
        }
    }

    private boolean isNewCommitCubeWaitingOnParentThread() {
        boolean hasNewCubes = false;
        while (httpLoadedCommitCubes.poll() != null) {
            hasNewCubes = true;
        }
        return hasNewCubes;
    }

    /**
     * Gather all instructions/waits and formations from all cubes that are currently loaded.
     * If cube isn't loaded yet, it will just skip the non-loaded cube.
     * <p>
     * This function is expected to be called when current formation set MAY be updated. It is
     * <p>
     * 1. when maximum cube set is updated (tile range or timechunk was updated)
     * 2. when formations inside specific cube became clear (one of the requested cubes finished loading)
     * <p>
     * So what, this function is expected to be called 1. every time after cube set is changed,
     * 2. when the requested cubes finished loading & parsing.
     * <p>
     * IF YOU FORGET TO CALL THIS FUNCTION WHEN CUBE SET IS CHANGED, THERE WILL BE CONFLICTS BETWEEN
     * THE INSTRUCTIONS AND WAITS WHICH ARE EXPECTED TO BE SHOWN, AND THE INSTRUCTIONS AND WAITS THAT
     * ARE ACTUALLY SHOWN.
     */
    List<FormationContext> fcs = new ArrayList<>();
    private List<FormationContext> gatherFcsForCurrentCommitTilesOnParentThread() {
        fcs.clear();

        for (CommitTile commitTile : currentCommitTiles) {
            int minTimechunk = this.pool.minTimechunkForCommitTile(commitTile);
            int maxTimechunk = this.pool.maxTimechunkForCommitTile(commitTile);
            int minDayDelta = (int) Math.floor(minTimechunk / MILLISECONDS_PER_TIMECHUNK);
            int maxDayDelta = (int) Math.floor(maxTimechunk / MILLISECONDS_PER_TIMECHUNK);
            for (int d = minDayDelta; d <= maxDayDelta; d++) {
                int dayBaseTimechunk = this.currentBaseTimechunk + d * (int) TIMECHUNKS_PER_DAY;
                if (dayBaseTimechunk < minTimechunk || dayBaseTimechunk > maxTimechunk) {
                    continue;
                }

                Tile tile = commitTile.getTile();
                Cube c = new Cube(tile, dayBaseTimechunk);
                CommitCube cc = new CommitCube(c, commitTile.getCommitId());
                Pool.PerCommitCube pcc = this.pool.perCommitCubeForCommitCube(cc);
                if (pcc == null) {
                    continue;
                }

                // Gather instructions
                if (pcc.referringInstructions == null) {
                } else {
                    for (com.ogiqvo.lib.bean.instruction.FromServer inst : pcc.referringInstructions) {
                        Formation formation = inst.getFormation();
                        String fcid = formation.getCid();
                        FormationContext fc;
                        if (!formation2context.containsKey(fcid)) {
                            fc = new FormationContext(formation);
                            formation2context.put(fcid, fc);
                        } else {
                            fc = formation2context.get(fcid);
                        }
                        fcs.add(fc);
                        fc.setCurrentInstruction(inst);
                        fc.setDayDelta(d);
                    }
                }

                // Gather waits
                if (pcc.referringWaits == null) {
                } else {
                    for (com.ogiqvo.lib.bean.wait.FromServer wait : pcc.referringWaits) {
                        Formation formation = wait.getFormation();
                        String fcid = formation.getCid();
                        FormationContext fc;
                        if (!formation2context.containsKey(fcid)) {
                            fc = new FormationContext(formation);
                            formation2context.put(fcid, fc);
                        } else {
                            fc = formation2context.get(fcid);
                        }
                        fcs.add(fc);
                        fc.setCurrentWait(wait);
                        fc.setDayDelta(d);
                    }
                }
            }
        }
        return fcs;
    }

    // This is only used to count updated formationcontexts, which is used as a flag to know if map redrawing is required.
    final Collection<FormationContext> displayingFormationContexts = new ArrayList<>();
    com.ogiqvo.lib.bean.edgeset.Base.TAndLnglatAtDistance tAndLnglat = new com.ogiqvo.lib.bean.edgeset.Base.TAndLnglatAtDistance();
    com.ogiqvo.lib.bean.edge.Base.TAndLnglatAtDistance tAndLnglatE = new com.ogiqvo.lib.bean.edge.Base.TAndLnglatAtDistance();

    Lnglat prevLnglat = new Lnglat(0, 0);
    Lnglat lnglat = new Lnglat(0, 0);

    /**
     * @param utcMilliseconds
     */
    private void updateBogieDistancesAndRequestRenderingOnParentThread(final long utcMilliseconds, final List<FormationContext> formationContexts,int formationContextsHash) {
        final int bogieCalculatingDay1970 = Timechunk.day1970fromUtcMilliseconds(utcMilliseconds);
        final long bogieCalculatingDayUtcMilliseconds = Timechunk.dayUtcMillisecondsFromUtcMilliseconds(utcMilliseconds);

        if(bogieCalculatingDay1970 == lastRenderedDay1970 &&
                bogieCalculatingDayUtcMilliseconds == lastRenderedUtcMilliseconds &&
                 formationContextsHash == lastRenderedFormationContextsHash){
            return;
        }
//        log.debug("{}={} {}={} {}={}",new Object[]{
//                bogieCalculatingDay1970,lastRenderedDay1970,
//                bogieCalculatingDayUtcMilliseconds,lastRenderedUtcMilliseconds,
//                formationContextsHash,lastRenderedFormationContextsHash
//        });
        lastRenderedUtcMilliseconds = bogieCalculatingDayUtcMilliseconds;
        lastRenderedDay1970 = bogieCalculatingDay1970;
        lastRenderedFormationContextsHash = formationContextsHash;

        final double dayUtcSeconds = bogieCalculatingDayUtcMilliseconds / 1000.0;

        displayingFormationContexts.clear();
        int bogieUpdatedFormationContextCount = 0;

        // Distances for 1 FormationContext is calculated by 1 executor. Wait for all the
        // executors to finish, and pass the calculated result to GL renderer.
        int length = formationContexts.size();
        for (int fci = 0; fci < length; fci++) {
            FormationContext formationContext = formationContexts.get(fci);
            assert formationContext != null;

            int fixedDay1970 = bogieCalculatingDay1970-formationContext.getDayDelta();
            final double fixedDayUtcSeconds = dayUtcSeconds+formationContext.getDayDelta()*86400;

            com.ogiqvo.lib.bean.instruction.FromServer instruction = formationContext.getCurrentInstruction();
            com.ogiqvo.lib.bean.wait.FromServer wait = formationContext.getCurrentWait();

            boolean isInstructionAvailable = false;
            boolean isWaitAvailable = false;

            if (instruction != null) {
                isInstructionAvailable = instruction.isAvailableAtUtcSeconds(fixedDayUtcSeconds) && instruction.getTrip().getCalendar().isAvailableFor(fixedDay1970);
            }
            if (wait != null) {
                isWaitAvailable = wait.isAvailableAtUtcSeconds(fixedDayUtcSeconds) && wait.getTrip().getCalendar().isAvailableFor(fixedDay1970);
            }
            if (!isInstructionAvailable && !isWaitAvailable) {
//                log.error("!!Nothing inside fc {}", formationContext.getFormation().getCid());
                continue; // There are nothing to be shown for this formation.
            }

            displayingFormationContexts.add(formationContext);

            // If previous instructionorwait was wait, and it is same to the previous wait, there's no need to recalculate even the first bogie distance.
            // Non-first bogie distance calculation will be skipped if first bogie distance is same to the previous, but first bogie distance can't be prevented
            // even if it's distance is CLEARLY same. It is clear to be same if wait is continuing.
            Object previousInstructionOrWait = formationContext.getPreviousInstructionOrWait();
            if(!isInstructionAvailable && previousInstructionOrWait != null && previousInstructionOrWait.equals(wait)){
                continue;
            }

            double firstBogieDistance;
            if (isInstructionAvailable) {
                firstBogieDistance = instruction.getFirstBogieDistanceAtUtcSeconds(fixedDayUtcSeconds);
                formationContext.setPreviousInstructionOrWait(instruction);
            } else {
                firstBogieDistance = wait.getFirstBogieDistance();
                formationContext.setPreviousInstructionOrWait(wait);
            }
            com.ogiqvo.lib.bean.edgeset.Base es = isInstructionAvailable ? instruction : wait;

            lnglat.setLnglat4326(0, 0);
            prevLnglat.setLnglat4326(0, 0);

            double[] bogieDistancesVessel = formationContext.getBogieDistances();
            if (bogieDistancesVessel != null) {
                double previousFirstBogieDistance = bogieDistancesVessel[0];
                if (previousFirstBogieDistance == Double.NaN || firstBogieDistance != previousFirstBogieDistance) {
//                            log.debug("bogie updated for formation {} {} != {}", new Object[]{formationContext.getFormation().getCid(), firstBogieDistance, previousFirstBogieDistance});
                    bogieUpdatedFormationContextCount++;
                    es.fillAllCarBogieDistancesFromFirstBogieDistance(firstBogieDistance, bogieDistancesVessel, 1, tAndLnglat, tAndLnglatE, lnglat);
                    bogieDistancesVessel[0] = firstBogieDistance;

                    double prevAltitude = 0;

                    Lnglat[] bogieLnglats = formationContext.getBogieLnglats();
                    double[] bogieAltitudes = formationContext.getBogieAltitudes();
                    for (int i = 0; i < bogieDistancesVessel.length; i++) {
                        double distance = bogieDistancesVessel[i];
                        double altitude;
                        Base.TAndLnglatAtDistance rtAndLnglat = null;
                        try {
                            rtAndLnglat = es.getTAndLnglatAtDistance(distance, tAndLnglat, tAndLnglatE, lnglat);
                            if (rtAndLnglat == null) {
                                prevLnglat.copyTo(bogieLnglats[i]);
                                altitude = prevAltitude;
                            } else {
                                tAndLnglat.lnglat.copyTo(bogieLnglats[i]);
                                altitude = tAndLnglat.altitude;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            prevLnglat.copyTo(bogieLnglats[i]);
                            altitude = prevAltitude;
                        }
                        bogieAltitudes[i] = altitude;

                        bogieLnglats[i].copyTo(prevLnglat);
                        prevAltitude = altitude;
                    }
                }
            }
        }

        this.notifyCurrentFormationsToGLThreadOnParentThread(displayingFormationContexts,
                displayingFormationContexts.size() == 0 || bogieUpdatedFormationContextCount > 0); // Update if there are no formation contexts (clear all), or there are updated formation contexts.
    }

    private void notifyCurrentFormationsToGLThreadOnParentThread(Collection<FormationContext> displayingFormationContexts, boolean isMapUpdateRequired) {
        if (isMapUpdateRequired) {
            this.cubeRenderer.safelyReviseFormationContextsBuffer(displayingFormationContexts);
            this.callHooksComplete(displayingFormationContexts);
            this.getMap().requestMapUpdateOnMainThread(true);
        }
    }

    private CommitTile returnCommitTileIfTimechunkRangeExistsForTile(MapTileJob tile) {
        if (tile == null) {
            return null;
        }
        CommitTile ct = new CommitTile(new Tile(tile.zoomLevel, tile.tileX, tile.tileY), this.commitId);
        if (!this.pool.isMinTimechunkForCommitTileLoaded(ct) || !this.pool.isMaxTimechunkForCommitTileLoaded(ct)) {
            return null;
        }
        int minTimechunk = this.pool.minTimechunkForCommitTile(ct);
        int maxTimechunk = this.pool.maxTimechunkForCommitTile(ct);
        if (minTimechunk == 0 && maxTimechunk == 0) {
            return null;
        }
        return ct;
    }

    public interface FormationContextUpdaterHook{
        void update(Collection<FormationContext> formationContexts);
    }

    private Inlist.List<LList<FormationContextUpdaterHook>> updaterHooks = new Inlist.List<>();

    public void addHook(FormationContextUpdaterHook hook){
        updaterHooks.append(new LList<>(hook));
    }

    public void callHooksComplete(Collection<FormationContext> formationContexts){
        LList<FormationContextUpdaterHook> lh = updaterHooks.head();
        while (lh != null) {
            lh.data.update(formationContexts);
            lh = lh.next;
        }
    }

    public void onAltitudeStretchUpdated(AltitudeStretcher altitudeStretcher){
        AltitudeStretcher altitudeStretcherClone = altitudeStretcher.clone();
        this.cubeRenderer.notifyNewAltitudeStretcher(altitudeStretcherClone);
        this.getMap().requestMapUpdateOnMainThread(true);
    }
}
