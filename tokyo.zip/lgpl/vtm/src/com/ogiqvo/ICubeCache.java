package com.ogiqvo;

import org.oscim.core.Cube;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by xor on 15/05/06.
 */
public interface ICubeCache {

    /**
     * @param cube The accessed tile.
     * @return The CacheFile which contains the Fileoutputstream for the cache.
     */
    CubeWriter writeCubeOnLoadingThread(Cube cube);

    /**
     * @param cube The accessed tile.
     * @return The stored file for this tile or null if tile is not stored.
     */
    CubeReader getCubeOnLoadingThread(Cube cube);

    /**
     * @param size The size for the cache directionary.
     */
    void setCacheSize(long size);

    public interface CubeReader {
        Cube getCube();

        InputStream getInputStream();
    }

    public interface CubeWriter {
        Cube getCube();

        OutputStream getOutputStream();

        void complete(boolean success);
    }
}
