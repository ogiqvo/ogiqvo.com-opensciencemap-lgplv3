package com.ogiqvo;

import com.ogiqvo.lib.Pool;
import com.ogiqvo.platestack.bean.Floor;

import org.oscim.core.GeometryBuffer;
import org.oscim.core.MapElement;
import org.oscim.layers.tile.MapTileJob;
import org.oscim.layers.tile.TileLoadingThread;
import org.oscim.layers.tile.TileManager;
import org.oscim.renderer.bucket.PlateStackTileBucket;
import org.oscim.renderer.bucket.PolygonBucket;
import org.oscim.renderer.bucket.RenderBuckets;
import org.oscim.theme.IRenderTheme;
import org.oscim.theme.styles.AreaStyle;
import org.oscim.theme.styles.CircleStyle;
import org.oscim.theme.styles.ExtrusionStyle;
import org.oscim.theme.styles.LineStyle;
import org.oscim.theme.styles.RenderStyle;
import org.oscim.theme.styles.SymbolStyle;
import org.oscim.theme.styles.TextStyle;
import org.oscim.tiling.ITileDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import static org.oscim.layers.tile.MapTileJob.State.LOADING;

/**
 * Created by xor on 15/08/27.
 */
public class PlateStackTileLoadingThread extends TileLoadingThread  implements RenderStyle.Callback {
    static final Logger log = LoggerFactory.getLogger(PlateStackTileLoadingThread.class);

    private final ITileDataSource tileDataSource;

    protected IRenderTheme renderTheme;
    private MapElement mapElement;
    protected int currentBucketForAddingElements;
    protected RenderBuckets renderBuckets;

    public PlateStackTileLoadingThread(TileManager tileManager, ITileDataSource tileDataSource, IRenderTheme renderTheme) {
        super(tileManager);

        this.tileDataSource = tileDataSource;
        this.renderTheme = renderTheme;
    }

    @Override
    protected boolean loadTileOnLoadingThread(MapTileJob tile) {

        try {
			/* queryTileJobOnLoadingThread database, which calls processOnLoadingThread() callback */
            tileDataSource.queryTileJobOnLoadingThread(tile, this);
        } catch (Exception e) {
            log.debug("{}", e);
            return false;
        }
        return true;
    }

    @Override
    public void dispose() {
        tileDataSource.dispose();
    }

    @Override
    public void cancel() {
        tileDataSource.cancel();
    }

    @Override
    public void setPerCommitTileOnLoadingThread(Pool.PerCommitTile commitTile) {
    }

    @Override
    public void setPlateStackPerTileOnLoadingThread(PlateStackPerTile pspt) {
        if (isCanceled() || !tileJob.containsState(LOADING)) {
            return;
        }

        for (Map.Entry<String, Floor> kv : pspt.getFloors().entrySet()) {
            String floorId = kv.getKey();
            Floor floor = kv.getValue();
//            log.debug("Set floor {}={}", new Object[]{floorId, floor});
            mapElement = (MapElement) floor.getGeojsonObj();/* get and apply addRenderingRequestToMainThread instructions */
            if (mapElement == null) {
//                log.debug("floor mapElement is null");
                continue;
            }

            // Render "floor" buckets
            renderBuckets = new RenderBuckets();
            if (mapElement.geometryType == GeometryBuffer.GeometryType.POINT) {
            } else {
                currentBucketForAddingElements = getValidLayer(mapElement.layer) * renderTheme.getLevels();
                renderWay(renderTheme.matchElement(mapElement.geometryType, mapElement.tags, tileJob.zoomLevel));
            }
            renderBuckets.prepare();

            // Since vector maps are using stencil buffers to render, polygon+holes can be single line.
            // But floors can't be generated from stencil buffers because the depth buffer will not work
            // properly when collaborated with stairs and escalators.
            // For floor maps, we should triangulate and make it a single triangle set.
            TriangleAndLineVboIbo talvi = new TriangleAndLineVboIbo();
            mapElement.triangulate(talvi);
            floor.setTalvi(talvi);

            clearState();

//            // Render "wc" buckets if exist
//            for (Map.Entry<Wc.Type, Wc> wckv : floor.wcsEntrySet()) {
//                Wc wc = wckv.getValue();
//
//                mapElement = (MapElement) wc.getGeojsonObj();
//                if (mapElement == null) {
//                    log.debug("wc mapElement is null");
//                    continue;
//                }
//                renderBuckets = new RenderBuckets();
//                wc.setTalvi(renderBuckets);
//                if (mapElement.geometryType == GeometryBuffer.GeometryType.POINT) {
//                } else {
//                    currentBucketForAddingElements = getValidLayer(mapElement.layer) * renderTheme.getLevels();
//                    renderWay(renderTheme.matchElement(mapElement.geometryType, mapElement.tags, tileJob.zoomLevel));
//                }
//                renderBuckets.prepare();
//                clearState();
//            }
        }

        PlateStackTileBucket l = new PlateStackTileBucket(pspt);
        tileJob.data = l;
    }

    protected void renderWay(RenderStyle[] style) {
//        log.debug("Render way {}", style);
        if (style == null)
            return;

        for (int i = 0, n = style.length; i < n; i++)
            style[i].renderWay(this);
    }

    protected static final byte LAYERS = 11; // Level 11?

    protected static int getValidLayer(int layer) {
        if (layer < 0) {
            return 0;
        } else if (layer >= LAYERS) {
            return LAYERS - 1;
        } else {
            return layer;
        }
    }

    @Override
    public void renderArea(AreaStyle area, int level) {
        int nLevel = currentBucketForAddingElements + level;

        PolygonBucket pb = renderBuckets.getPolygonBucket(nLevel);
        pb.area = area;
    }

    @Override
    public void renderExtrusion(ExtrusionStyle extrusion, int level) {

    }

    @Override
    public void renderCircle(CircleStyle circle, int level) {

    }

    @Override
    public void renderSymbol(SymbolStyle symbol) {

    }

    @Override
    public void renderWay(LineStyle line, int level) {

    }

    @Override
    public void renderText(TextStyle text) {

    }

    protected void clearState() {
        mapElement = null;
    }

}
