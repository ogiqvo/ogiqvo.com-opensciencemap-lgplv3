package com.ogiqvo;

import com.ogiqvo.lib.Pool;

import org.oscim.layers.tile.MapTileJob;
import org.oscim.layers.tile.TileLoadingThread;
import org.oscim.layers.tile.TileManager;
import org.oscim.renderer.bucket.OgiqvoTileBucket;
import org.oscim.tiling.ITileDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.oscim.layers.tile.MapTileJob.State.LOADING;

/**
 * Created by xor on 05/04/15.
 */
public class OgiqvoTileLoadingThread extends TileLoadingThread {
    static final Logger log = LoggerFactory.getLogger(OgiqvoTileLoadingThread.class);

    private final ITileDataSource tileDataSource;
    private final OnCompleteHooksCallableTileLayer callbackTileLayer;

    public OgiqvoTileLoadingThread(TileManager tileManager, ITileDataSource tileDataSource, OnCompleteHooksCallableTileLayer callbackTileLayer) {
        super(tileManager);
        this.tileDataSource = tileDataSource;
        this.callbackTileLayer = callbackTileLayer;
    }

    @Override
    protected boolean loadTileOnLoadingThread(MapTileJob tile) {
        try {
			/* queryTileJobOnLoadingThread database, which calls processOnLoadingThread() callback */
            tileDataSource.queryTileJobOnLoadingThread(tile, this);
        } catch (Exception e) {
            log.debug("{}", e);
            return false;
        }

        return true;
    }

    @Override
    public void dispose() {
        tileDataSource.dispose();
    }

    @Override
    public void cancel() {
        tileDataSource.cancel();
    }

    @Override
    public void setPerCommitTileOnLoadingThread(Pool.PerCommitTile commitTile) {
        if (isCanceled() || !tileJob.containsState(LOADING)) {
            return;
        }

        OgiqvoTileBucket l = new OgiqvoTileBucket(commitTile);
        tileJob.data = l;
    }

    @Override
    public void setPlateStackPerTileOnLoadingThread(PlateStackPerTile pspt) {
    }

    @Override
    public void notifyToLoaderThatLoadingIsCompleteOnLoadingThread(QueryResult result) {
        boolean ok = (result == QueryResult.SUCCESS);

        callbackTileLayer.callHooksComplete(tileJob, ok);

        super.notifyToLoaderThatLoadingIsCompleteOnLoadingThread(result);
    }

}
