package com.ogiqvo;

import org.oscim.core.MapElement;
import org.oscim.tiling.ITileDataSource;
import org.oscim.tiling.source.UrlTileDataSource;
import org.oscim.tiling.source.UrlTileSource;

import java.util.Map;

/**
 * Created by xor on 15/08/27.
 */
public class UrlPlateStackTileSource extends UrlTileSource {
    public UrlPlateStackTileSource(String urlString) {
        super(urlString, "tokyo-{Z}-{X}-{Y}.plast", 16, 16);
        setUrlFormatter(UrlTileSource.URL_FORMATTER);
    }

    @Override
    public ITileDataSource getDataSourceOnMainThread() {
        return new UrlTileDataSource(this, new PlateStackTileDecoder(), getHttpEngine());
    }

    public void decodeTags(MapElement mapElement, Map<String, Object> properties) {
    }
}
