package com.ogiqvo;

import org.oscim.layers.Layer;
import org.oscim.layers.tile.TileManager;
import org.oscim.map.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

/**
 * Created by xor on 15/09/26.
 */
public class OgiqvoCubeLabelLayer extends Layer implements OgiqvoCubeLayer.FormationContextUpdaterHook {
    static final Logger log = LoggerFactory.getLogger(OgiqvoCubeLabelLayer.class);

    private final OgiqvoCubeLabelRenderer renderer;

    public OgiqvoCubeLabelLayer(Map map, TileManager tileManager) {
        super(map);
        this.renderer = new OgiqvoCubeLabelRenderer();
        this.renderer.setTileManager(tileManager);
        setLayerRenderer(this.renderer);
    }

    @Override
    public void update(Collection<FormationContext> formationContexts) {
        this.renderer.safelyReviseFormationContextsBuffer(formationContexts);
    }

    public void onAltitudeStretchUpdated(AltitudeStretcher altitudeStretcher){
        AltitudeStretcher altitudeStretcherClone = altitudeStretcher.clone();
        this.renderer.notifyNewAltitudeStretcher(altitudeStretcherClone);
        this.getMap().requestMapUpdateOnMainThread(true);
    }
}
