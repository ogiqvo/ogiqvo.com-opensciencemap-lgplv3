package com.ogiqvo;

import org.oscim.layers.tile.MapTileJob;
import org.oscim.layers.tile.TileLayer;
import org.oscim.layers.tile.TileManager;
import org.oscim.map.Map;
import org.oscim.utils.pool.Inlist;
import org.oscim.utils.pool.LList;

/**
 * Created by xor on 15/11/29.
 */
abstract public class OnCompleteHooksCallableTileLayer extends TileLayer {

    private Inlist.List<LList<TileLoaderHook>> loaderHooks = new Inlist.List<>();

    public OnCompleteHooksCallableTileLayer(Map map, TileManager tileManager) {
        super(map, tileManager);
    }

    public void addHook(TileLoaderHook tileLoaderHook) {
        loaderHooks.append(new LList<>(tileLoaderHook));
    }

    public void callHooksComplete(MapTileJob tile, boolean success) {
        LList<TileLoaderHook> lh = loaderHooks.head();
        while (lh != null) {
            lh.data.complete(tile, success);
            lh = lh.next;
        }
    }

    public interface TileLoaderHook {
        void complete(MapTileJob tile, boolean success);
    }
}
