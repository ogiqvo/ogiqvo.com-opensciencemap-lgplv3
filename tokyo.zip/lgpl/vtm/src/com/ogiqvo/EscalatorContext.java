package com.ogiqvo;

import com.ogiqvo.platestack.bean.Escalator;

/**
 * Created by xor on 15/08/31.
 */
public class EscalatorContext {
    Escalator escalator;
    double[] plateDistances;
    double[] latitudes;
    double[] longitudes;
    double[] altitudes;
    long lastUtcMilliseconds;

    public Escalator getEscalator() {
        return escalator;
    }

    public void setEscalator(Escalator escalator) {
        this.escalator = escalator;
    }

    public double[] getPlateDistances() {
        return plateDistances;
    }

    public void setPlateDistances(double[] plateDistances) {
        this.plateDistances = plateDistances;
    }

    public long getLastUtcMilliseconds() {
        return lastUtcMilliseconds;
    }

    public void setLastUtcMilliseconds(long lastUtcMilliseconds) {
        this.lastUtcMilliseconds = lastUtcMilliseconds;
    }

    public double[] getLatitudes() {
        return latitudes;
    }

    public void setLatitudes(double[] latitudes) {
        this.latitudes = latitudes;
    }

    public double[] getLongitudes() {
        return longitudes;
    }

    public void setLongitudes(double[] longitudes) {
        this.longitudes = longitudes;
    }

    public double[] getAltitudes() {
        return altitudes;
    }

    public void setAltitudes(double[] altitudes) {
        this.altitudes = altitudes;
    }
}
