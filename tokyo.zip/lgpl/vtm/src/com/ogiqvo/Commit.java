package com.ogiqvo;

/**
 * Created by xor on 15/05/10.
 */
public class Commit {
    static final public int TIMECHUNK_MILLISECONDS = 20000;
}
