package com.ogiqvo.timetable;

import com.ogiqvo.lib.loader.BezierCidAndT;

import org.oscim.core.GeoPoint;

/**
 * Created by xor on 15/10/24.
 */
public interface IGeoPoint2bezierCidAndTCache {
    /**
     * @param gp The accessed tile.
     * @return The CacheFile which contains the Fileoutputstream for the cache.
     */
    BezierCidAndTWriter writeTileOnLoadingThread(BezierCidAndT bezierCidAndT, GeoPoint gp);

    /**
     * @param gp The accessed tile.
     * @return The stored file for this tile or null if tile is not stored.
     */
    BezierCidAndTReader getBezierCidAndTOnLoadingThread(GeoPoint gp);

    /**
     * @param size The size for the cache directionary.
     */
    void setCacheSize(long size);

    interface BezierCidAndTReader {
        BezierCidAndT getBezierCidAndT();
    }

    interface BezierCidAndTWriter {
        GeoPoint getGeoPoint();

        BezierCidAndT getBezierCidAndT();

        void complete(boolean success);
    }
}
