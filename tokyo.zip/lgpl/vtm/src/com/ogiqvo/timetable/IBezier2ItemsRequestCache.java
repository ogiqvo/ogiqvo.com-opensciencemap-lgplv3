package com.ogiqvo.timetable;

import com.ogiqvo.lib.loader.BezierCidAndT;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by xor on 15/10/24.
 */
public interface IBezier2ItemsRequestCache {
    /**
     * @param bezierCidAndT The accessed tile.
     * @return The CacheFile which contains the Fileoutputstream for the cache.
     */
    Bezier2ItemsWriter writeTileOnLoadingThread(BezierCidAndT bezierCidAndT);

    /**
     * @param bezierCidAndT The accessed tile.
     * @return The stored file for this tile or null if tile is not stored.
     */
    Bezier2ItemsReader getTileOnLoadingThread(BezierCidAndT bezierCidAndT);

    /**
     * @param size The size for the cache directionary.
     */
    void setCacheSize(long size);

    interface Bezier2ItemsReader {
        BezierCidAndT getBezierCidAndT();

        InputStream getInputStream();
    }

    interface Bezier2ItemsWriter {
        BezierCidAndT getBezierCidAndT();

        void complete(boolean success);

        OutputStream getOutputStream();
    }
}
