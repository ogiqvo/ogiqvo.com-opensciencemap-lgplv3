package com.ogiqvo.timetable;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by xor on 15/10/25.
 */
public interface IBezierCache {
    /**
     * @param bezierCid The accessed tile.
     * @return The CacheFile which contains the Fileoutputstream for the cache.
     */
    BezierWriter writeBezierOnLoadingThread(String bezierCid);

    /**
     * @param bezierCid The accessed tile.
     * @return The stored file for this tile or null if tile is not stored.
     */
    BezierReader getBezierOnLoadingThread(String bezierCid);

    /**
     * @param size The size for the cache directionary.
     */
    void setCacheSize(long size);

    interface BezierReader {
        String getBezierCid();

        InputStream getInputStream();
    }

    interface BezierWriter {
        String getBezierCid();

        void complete(boolean success);

        OutputStream getOutputStream();
    }
}
