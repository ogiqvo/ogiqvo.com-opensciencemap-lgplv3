package com.ogiqvo.timetable;

public class Item implements Comparable<Item> {
    public double passingUtcMilliseconds;
    public String eta;

    // Either of the following values are set.
    public com.ogiqvo.lib.bean.instruction.FromServer instruction;
    public com.ogiqvo.lib.bean.wait.FromServer wait;

    @Override
    public int compareTo(Item timetableItem) {
        double d = (passingUtcMilliseconds - timetableItem.passingUtcMilliseconds);
        if (d == 0) {
            return 0;
        } else if (d > 0) {
            return 1;
        } else {
            return -1;
        }
    }
}
