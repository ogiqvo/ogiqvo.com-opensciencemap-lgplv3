package com.ogiqvo;

import com.google.common.collect.Range;
import com.google.common.collect.RangeSet;
import com.google.common.collect.TreeRangeSet;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by xor on 15/09/04.
 */
public class AltitudeRanges {
    RangeSet<Double> knownRanges;
    RangeSet<Double> previousKnownRanges;
    Collection<RangeUpdateListenable> updateListeners;

    public AltitudeRanges() {
        knownRanges = TreeRangeSet.create();
        previousKnownRanges = TreeRangeSet.create();
        updateListeners = new ArrayList<>();
    }

    public void clear() {
        // Swap
        RangeSet<Double> tmp = knownRanges;
        knownRanges = previousKnownRanges;
        previousKnownRanges = tmp;

        knownRanges.clear();
    }

    public void addAltitudeRange(Range<Double> range) {
        knownRanges.add(range);
    }

    public void notifyAddingComplete() {
        if (previousKnownRanges.equals(knownRanges)) {
            return;
        }
        fireListener(knownRanges);
    }

    public Range<Double> span(){
        return knownRanges.span();
    }

    public boolean doesAltitudeExist() {
        return !knownRanges.isEmpty();
    }

    public interface RangeUpdateListenable {
        void onAltitudeRangeUpdate(RangeSet<Double> knownRanges);
    }

    public void addListener(RangeUpdateListenable listener) {
        this.updateListeners.add(listener);
    }

    public void fireListener(RangeSet<Double> knownRanges) {
        for (RangeUpdateListenable l : this.updateListeners) {
            l.onAltitudeRangeUpdate(knownRanges);
        }
    }
}
