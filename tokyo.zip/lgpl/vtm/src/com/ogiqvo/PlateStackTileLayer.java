package com.ogiqvo;

import org.oscim.layers.tile.TileLayer;
import org.oscim.layers.tile.TileLoadingThread;
import org.oscim.layers.tile.TileManager;
import org.oscim.map.Map;
import org.oscim.theme.IRenderTheme;
import org.oscim.tiling.ITileDataSource;

/**
 * Created by xor on 15/08/27.
 */
public class PlateStackTileLayer extends TileLayer {
    private final static int MAX_CACHE = 32;
    public final static int SRC_MIN_ZOOM = 14;// Temporary using single tile. If objects are distributed per tile, change this value.
    public final static int SRC_MAX_ZOOM = 14;

    private PlateStackTileRenderer tileRenderer;
    private PlateStackTileLoadingThread tileLoader;

    public PlateStackTileLayer(Map map, ITileDataSource tileDataSource, IRenderTheme renderTheme, AltitudeRanges altitudeRanges) {
        super(map, new TileManager(map, MAX_CACHE));

        this.tileRenderer = new PlateStackTileRenderer(altitudeRanges);
        this.tileRenderer.setTileManager(tileManager);
        setRenderer(this.tileRenderer);

        tileManager.setZoomLevel(SRC_MIN_ZOOM, SRC_MAX_ZOOM);
        this.tileLoader = new PlateStackTileLoadingThread(tileManager, tileDataSource, renderTheme);
        initAndStartLoadingThreadsOnMainThread(1);
    }

    public void onAltitudeStretchUpdated(AltitudeStretcher altitudeStretcher) {
        AltitudeStretcher altitudeStretcherClone = altitudeStretcher.clone();
        this.tileRenderer.notifyNewAltitudeStretcher(altitudeStretcherClone);
        this.getMap().requestMapUpdateOnMainThread(true);
    }

    public void onClockUpdated(long utcMilliseconds) {
        boolean isNeededToBeRepainted = this.tileRenderer.updateEscalatorContextForUtcMilliseconds(utcMilliseconds);
        if (!isNeededToBeRepainted) {
            return;
        }
        this.getMap().requestMapUpdateOnMainThread(true);
    }

    @Override
    protected TileLoadingThread createLoaderOnMainThread() {
        return this.tileLoader;
    }
}
