package com.ogiqvo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by xor on 15/09/04.
 */
public class AltitudeStretcher {
    static final Logger log = LoggerFactory.getLogger(AltitudeStretcher.class);

    double realCursorAltitude;
    double realMinAltitude;
    double realMaxAltitude;
    double realAltitudeDelta;
    double stretchedMinAltitude;
    double stretchedMaxAltitude;
    double stretchingAltitudeDelta;
    boolean isNotStretching;

    public double getRealCursorAltitude() {
        return realCursorAltitude;
    }

    public void setRealCursorAltitude(double stretchAltitude) {
        this.realCursorAltitude = stretchAltitude;
    }

    public double getRealMinAltitude() {
        return realMinAltitude;
    }

    public void setRealMinAltitude(double realMinAltitude) {
        this.realMinAltitude = realMinAltitude;
    }

    public double getRealMaxAltitude() {
        return realMaxAltitude;
    }

    public void setRealMaxAltitude(double realMaxAltitude) {
        this.realMaxAltitude = realMaxAltitude;
    }

    public double getRealAltitudeDelta() {
        return realAltitudeDelta;
    }

    public void setRealAltitudeDelta(double realAltitudeDelta) {
        this.realAltitudeDelta = realAltitudeDelta;
    }

    public boolean isNotStretching() {
        return isNotStretching;
    }

    public void setIsNotStretching(boolean isNotStretching) {
        this.isNotStretching = isNotStretching;
    }

    double k; // s(x) = kx
    double m; // t(x) = {
    // 0 when x in [0,x0]
    // (-cos(theta)+1)m/2 where theta=(x-x0)/(x1-x0)pi in [x0,x1]
    // m when x in [x1,max]
    // }
    double x0;
    double x1;

    public double getK() {
        return k;
    }

    public void setK(double k) {
        this.k = k;
    }

    public double getM() {
        return m;
    }

    public void setM(double m) {
        this.m = m;
    }

    public double getX0() {
        return x0;
    }

    public void setX0(double x0) {
        this.x0 = x0;
    }

    public double getX1() {
        return x1;
    }

    public void setX1(double x1) {
        this.x1 = x1;
    }

    private double s(double x) {
        return k * x;
    }

    private double t(double x) {
        if (x < x0) {
            return 0;
        } else if (x > x1) {
            return m;
        } else {
            double theta = (x - x0) / (x1 - x0) * Math.PI;
            return (-Math.cos(theta) + 1) * m / 2.0;
        }
    }

    private double realAltitudeRate(double altitude) {
        return (altitude - this.realMinAltitude) / (this.realMaxAltitude - this.realMinAltitude);
    }

    public void recalcCoefficients() {
        double X = this.realMaxAltitude - this.realMinAltitude;
        double Y = this.stretchedMaxAltitude - this.stretchedMinAltitude;
        double deltaX = this.realAltitudeDelta;
        double deltaY = this.stretchingAltitudeDelta;
        k = (Y - deltaY) / X;
        m = deltaY;

        double x0rate = this.realAltitudeRate(this.realCursorAltitude);
        double x1rate = this.realAltitudeRate(this.realCursorAltitude + deltaX);
        x0 = x0rate * X;
        x1 = x1rate * X;

//        log.debug("set k={},m={},minx={},maxx={},cursorx={},deltax={},x0rate={},x0={},x1rate={},x1={}", new Object[]{
//                k, m,
//                this.realMinAltitude, this.realMaxAltitude,
//                this.realCursorAltitude, deltaX, x0rate, x0, x1rate, x1
//        });
    }

    public double getStretchedAltitude(double targetAltitude) {
        if (isNotStretching) {
            return targetAltitude;
        } else {
            // Actually, x can only move between [minx,maxx-deltax], but the given x will be [minx,maxx].
            // We should remap [minx,maxx-deltax] to [minx,maxx].
            double r = this.realAltitudeRate(targetAltitude);
            double constraintMaxX = this.realMaxAltitude - this.realAltitudeDelta;
            double fixedAltitude = constraintMaxX * r + this.realMinAltitude * (1.0 - r);

            // Fix range from [minx,maxx-deltax] to [0,maxx-deltax-minx]
            double fixedAltitude0 = fixedAltitude - this.realMinAltitude;

            double s = this.s(fixedAltitude0);
            double t = this.t(fixedAltitude0);
            double f = s + t;
//            log.debug("{}->{}->{} {}*{}+{}={}", new Object[]{targetAltitude, fixedAltitude, fixedAltitude0, s, k, t, f});
            return f;
        }
    }

    public float getStretchedAlpha(double targetAltitude) {
        if (isNotStretching) {
            return 1;
        }
        double absoluteAltitudeDelta = Math.abs(this.realCursorAltitude - targetAltitude) / 10.0;
        if (absoluteAltitudeDelta > 1) {
            return 0.1f;
        }
        float alpha = (float) (1.0f - absoluteAltitudeDelta) / 0.9f + 0.1f;
//        log.debug("stretch {}, {} -> {}", new Object[]{targetAltitude, this.realCursorAltitude, alpha});
        return alpha;
    }

    public double getStretchingAltitudeDelta() {
        return stretchingAltitudeDelta;
    }

    public void setStretchingAltitudeDelta(double stretchingAltitudeDelta) {
        this.stretchingAltitudeDelta = stretchingAltitudeDelta;
    }

    public double getStretchedMinAltitude() {
        return stretchedMinAltitude;
    }

    public void setStretchedMinAltitude(double stretchedMinAltitude) {
        this.stretchedMinAltitude = stretchedMinAltitude;
    }

    public double getStretchedMaxAltitude() {
        return stretchedMaxAltitude;
    }

    public void setStretchedMaxAltitude(double stretchedMaxAltitude) {
        this.stretchedMaxAltitude = stretchedMaxAltitude;
    }

    public AltitudeStretcher clone() {
        AltitudeStretcher o = new AltitudeStretcher();
        o.setIsNotStretching(this.isNotStretching);

        o.setStretchedMinAltitude(this.getStretchedMinAltitude());
        o.setStretchedMaxAltitude(this.getStretchedMaxAltitude());
        o.setStretchingAltitudeDelta(this.getStretchingAltitudeDelta());

        o.setRealMinAltitude(this.getRealMinAltitude());
        o.setRealMaxAltitude(this.getRealMaxAltitude());
        o.setRealAltitudeDelta(this.getRealAltitudeDelta());

        o.setRealCursorAltitude(this.getRealCursorAltitude());

        o.setK(this.k);
        o.setM(this.m);
        o.setX0(this.x0);
        o.setX1(this.x1);

        return o;
    }
}
