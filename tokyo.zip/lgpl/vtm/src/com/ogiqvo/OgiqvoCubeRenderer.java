package com.ogiqvo;

import com.ogiqvo.lib.bean.Car;
import com.ogiqvo.lib.bean.Carmodel;
import com.ogiqvo.lib.bean.Formation;
import com.ogiqvo.lib.bean.Lnglat;
import com.ogiqvo.lib.bean.Route;
import com.ogiqvo.lib.bean.Trip;
import com.owens.oobjloader.lwjgl.Scene;

import org.oscim.backend.GL;
import org.oscim.backend.canvas.Color;
import org.oscim.core.MapPosition;
import org.oscim.core.Tile;
import org.oscim.layers.tile.MapTileJob;
import org.oscim.layers.tile.TileRenderer;
import org.oscim.renderer.GLMatrix;
import org.oscim.renderer.GLState;
import org.oscim.renderer.GLUtils;
import org.oscim.renderer.GLViewport;
import org.oscim.renderer.MapRenderer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import static org.oscim.backend.GLAdapter.gl;

/**
 * Created by xor on 15/05/06.
 */
public class OgiqvoCubeRenderer extends TileRenderer {
    static final Logger log = LoggerFactory.getLogger(OgiqvoCubeRenderer.class);

    private PrimitiveShader primitiveShader;

    private Collection<FormationContext> fcs0 = new ConcurrentLinkedQueue<>();
    private Collection<FormationContext> fcs1 = new ConcurrentLinkedQueue<>();
    private Collection<FormationContext> currentFormationContexts;
    private Object fcSwapLockObj = new Object();

    private GLMatrix mTmpMatrix = new GLMatrix();

    private AltitudeStretcher altitudeStretcher = new AltitudeStretcher();

    public OgiqvoCubeRenderer() {
        super();

        // current-formation-contexts double buffer
        this.currentFormationContexts = this.fcs0;
    }

    public void notifyNewAltitudeStretcher(AltitudeStretcher altitudeStretcher) {
        synchronized (altitudeStretcher) {
            this.altitudeStretcher = altitudeStretcher;
        }
    }

    @Override
    public boolean setupOnGLThread() {
        super.setupOnGLThread();
        primitiveShader = new PrimitiveShader("base_shader");

        return true;
    }

    List<Queue<FormationContext>> fcCaches = new ArrayList<>();

    private Queue<FormationContext> fcqForCarCount(int carCount) {
        while (fcCaches.size() < carCount) {
            fcCaches.add(new ConcurrentLinkedQueue<FormationContext>());
        }
        return fcCaches.get(carCount - 1);
    }

    public void safelyReviseFormationContextsBuffer(Iterable<FormationContext> newFcs) {
        Collection<FormationContext> nextFcs;
        synchronized (this.fcSwapLockObj) {
            if (this.currentFormationContexts == this.fcs0) {
                nextFcs = fcs1;
            } else {
                nextFcs = fcs0;
            }

            // Previous FCs might be touched by GL thread.
            // Next FCs is not touched, so can safely be modified.

            // Release previous fc
            for (FormationContext fc : nextFcs) {
                int carCount = fc.getCarCount();
                Queue<FormationContext> fcq = this.fcqForCarCount(carCount);
                fcq.add(fc);
            }

            nextFcs.clear();

            for (FormationContext fc : newFcs) {
                assert fc != null;

                Formation formation = fc.getFormation();

                int carCount = formation.getCars().size();
                Queue<FormationContext> fcq = this.fcqForCarCount(carCount);

                FormationContext nextLocalFc;
                if (fcq.isEmpty()) {
                    nextLocalFc = new FormationContext(formation);
                } else {
                    nextLocalFc = fcq.poll();
                }

                synchronized (fc) {
                    fc.deepCopyBogieLnglatsTo(nextLocalFc);
                    fc.deepCopyIsAvailableTo(nextLocalFc);
                    fc.deepCopyBogieAltitudesTo(nextLocalFc);
                    com.ogiqvo.lib.bean.instruction.FromServer instruction = fc.getCurrentInstruction();
                    com.ogiqvo.lib.bean.wait.FromServer wait = fc.getCurrentWait();
                    nextLocalFc.setCurrentInstruction(instruction);
                    nextLocalFc.setCurrentWait(wait);
                }

                Lnglat[] bogieLnglats = fc.getBogieLnglats();
                double[] bogieAltitudes = fc.getBogieAltitudes();
                for (int i = 0; i < carCount; i++) {

                    // Calculate car bearing
                    Lnglat ll0 = bogieLnglats[2 * i];
                    Lnglat ll1 = bogieLnglats[2 * i + 1];
                    if (ll0 == null || ll1 == null) {
                        continue;
                    }

                    double centerLongitude4326 = (ll0.get4326lng() + ll1.get4326lng()) / 2.0;
                    double centerLatitude4326 = (ll0.get4326lat() + ll1.get4326lat()) / 2.0;
                    nextLocalFc.getCarCenterLnglats()[i].setLnglat4326(centerLongitude4326, centerLatitude4326);

                    double dx = ll1.getLnglat3857().x - ll0.getLnglat3857().x;
                    double dy = ll1.getLnglat3857().y - ll0.getLnglat3857().y;
                    double bearingRadian = -Math.atan2(dy, dx);
                    double ddistance = Math.sqrt(dx * dx + dy * dy);
                    double averageBearing = bearingRadian / Math.PI * 180.0 + 90.0;
                    nextLocalFc.getCarBearings()[i] = averageBearing;

                    Car car = formation.getCars().get(i);
                    Carmodel carmodel = car.getCarmodel();
                    double carWidth = carmodel.getWidth();
                    double carLength = carmodel.getLength();
                    double pureCarHeight = carmodel.getHeight() - carmodel.getWheelHeight();
                    double heightUntilCarCenter = carmodel.getWheelHeight() + carmodel.getHeight() / 2.0;

                    double a0 = bogieAltitudes[2 * i];
                    double a1 = bogieAltitudes[2 * i + 1];
                    double da = a1 - a0;
                    double centerAltitude = (a0 + a1) / 2.0;
                    double slope = Math.atan2(da, ddistance) * 180.0 / Math.PI;

                    // Copy car profiles
                    nextLocalFc.getCarWidths()[i] = carWidth;
                    nextLocalFc.getCarLengths()[i] = carLength;
                    nextLocalFc.getCarPureHeights()[i] = pureCarHeight;
                    nextLocalFc.getCarHeightsUntilCenter()[i] = heightUntilCarCenter;
                    nextLocalFc.getCarAltitudes()[i] = centerAltitude;
                    nextLocalFc.getCarSlopes()[i] = slope;
                }

                nextFcs.add(nextLocalFc);
            }

            this.currentFormationContexts = nextFcs;
        }
    }

    /**
     * Render using OpenGL
     *
     * @param v
     */
    @Override
    public void renderOnGLThread(GLViewport v) {
        synchronized (this.fcSwapLockObj) {
            if (this.currentFormationContexts.isEmpty()) {
                return;
            }

            GLState.blend(true);
            GLState.test(true, false);
            gl.depthFunc(GL.LEQUAL);
            gl.depthMask(true);
            gl.enable(GL.CULL_FACE);

            MapTileJob[] tiles = drawingTileSet.tileJobs;
            MapTileJob tile = tiles[0];

            for (FormationContext formationContext : this.currentFormationContexts) {
                Trip trip = null;

                if (formationContext.getCurrentInstruction() != null) {
                    com.ogiqvo.lib.bean.instruction.FromServer instruction = formationContext.getCurrentInstruction();
                    trip = instruction.getTrip();
                } else if (formationContext.getCurrentWait() != null) {
                    com.ogiqvo.lib.bean.wait.FromServer wait = formationContext.getCurrentWait();
                    trip = wait.getTrip();
                } else {
                }

                if (trip != null) {
                    Route route = trip.getRoute();

                    // Draw cars
                    Lnglat[] bogieLnglats = formationContext.getBogieLnglats();
                    int carCount = bogieLnglats.length / 2;
                    for (int i = 0; i < carCount; i++) {
                        Lnglat centerLl = formationContext.getCarCenterLnglats()[i];
                        if (centerLl == null) {
                            continue;
                        }
                        double carAltitude = formationContext.getCarAltitudes()[i];
                        double carSlope = formationContext.getCarSlopes()[i];
                        double bearing = formationContext.getCarBearings()[i];
                        double carWidth = formationContext.getCarWidths()[i];
                        double carLength = formationContext.getCarLengths()[i];
                        double pureHeight = formationContext.getCarPureHeights()[i];
                        double carHeightUntilCenter = formationContext.getCarHeightsUntilCenter()[i] + carAltitude;

                        Formation f = formationContext.getFormation();
                        Car car = f.getCars().get(i);
                        Carmodel carmodel = car.getCarmodel();
                        Object cm3d = carmodel.getCm3dStruct();
                        boolean isDirectionTrue = f.getIsDirectionTrues().get(i);

                        int color = 0xff000000;
                        if (route.getColor() != null) {
                            if (!route.is32set()) {
                                String routeColorStr = route.getColor();
                                color = Color.parseColor("#" + routeColorStr);
                                route.setColor32(color);
                                route.setIs32set(true);
                            } else {
                                color = route.getColor32();
                            }
                        }

                        this.renderCarInTile(v,
                                centerLl.get4326lat(), centerLl.get4326lng(), carHeightUntilCenter,
                                bearing, carSlope,
                                carWidth, carLength, pureHeight,
                                cm3d, isDirectionTrue,
                                bogieLnglats[i * 2], bogieLnglats[i * 2 + 1],
                                color, formationContext.getAlpha(),
                                tile);
                    }
                }
            }

            gl.bindFramebuffer(GL.FRAMEBUFFER, 0);
            gl.bindTexture(GL.TEXTURE_2D, 0);
            gl.disable(GL.CULL_FACE);

            GLState.bindElementBuffer(0);
            GLState.bindVertexBuffer(0);
        }
    }

    private void renderCarInTile(GLViewport v,
                                 double lat, double lon, double carCenterAltitude,
                                 double bearing, double carSlope,
                                 double carWidth, double carLength, double scaleZ,
                                 Object cm3d, boolean isDirectionTrue,
                                 Lnglat bogieLl0, Lnglat bogieLl1,
                                 int color, float alpha,
                                 MapTileJob tile) {
        primitiveShader.set(v);

        int z = tile.zoomLevel;

        MapPosition pos = v.pos;
        double tileScale = Tile.SIZE * v.pos.scale;

        // Build matrix
        v.mvp.setIdentity();

        // Scale
        float mapAffineScale = (float) (pos.scale / (1 << z) / MapRenderer.COORD_SCALE);
        if (cm3d instanceof Scene) {
            // Draw OBJ model
            mTmpMatrix.setScale(mapAffineScale, mapAffineScale, mapAffineScale);
        } else {
            mTmpMatrix.setScale(mapAffineScale * (float) carWidth / SCALE_MAGIC_NUMBER, mapAffineScale * (float) carLength / SCALE_MAGIC_NUMBER, mapAffineScale * (float) scaleZ / SCALE_MAGIC_NUMBER);
        }
        v.mvp.multiplyLhs(mTmpMatrix);

        // Rotate slope (d-z)
        mTmpMatrix.setRotation(0, (float) carSlope, 0, 1);
        v.mvp.multiplyLhs(mTmpMatrix);

        // Rotate bearing (x-y)
        if (!isDirectionTrue) {
            bearing += 180.0;
        }
        mTmpMatrix.setRotation((float) bearing, 0, 0, 1);
        v.mvp.multiplyLhs(mTmpMatrix);

        // Translate
        float scale = (float) (pos.scale / (1 << z));
        float mapAffineX = getMapAffineX(lon, tileScale, pos);
        float mapAffineY = getMapAffineY(lat, tileScale, pos);
        double originalAltitude = carCenterAltitude;
        double stretchedAltitude = this.altitudeStretcher.getStretchedAltitude(originalAltitude);
        mTmpMatrix.setTranslation(mapAffineX, mapAffineY, scale * (float) stretchedAltitude);
        v.mvp.multiplyLhs(mTmpMatrix);

        // Fix-ups before drawing elements
        v.mvp.multiplyLhs(v.viewproj);
        v.mvp.setAsUniform(primitiveShader.uMVP);

        if (cm3d instanceof Scene) {
            // Draw OBJ model
            Scene cm3dScene = (Scene) cm3d;
            cm3dScene.render(primitiveShader);
        } else {
            GLState.bindVertexBuffer(cubeVerticesBufferVboIdx);
            GLState.enableVertexArrays(primitiveShader.aPos, -1);
            gl.vertexAttribPointer(primitiveShader.aPos, 3, GL.FLOAT, false, 0, 0); // 3 = 3-dimensional

            GLState.bindElementBuffer(cubeIndicesBufferIboIdx);
            GLUtils.setColor(primitiveShader.uColor, color, 1f);
            gl.drawElements(GL.TRIANGLE_STRIP, cubeIndicesBufferLength, GL.UNSIGNED_SHORT, 0);

            GLState.bindElementBuffer(cubeEIndicesBufferIboIdx);
            GLUtils.setColor(primitiveShader.uColor, 0xff000000, 1f);
            gl.lineWidth(1);
            gl.drawElements(GL.LINES, cubeEIndicesBufferLength, GL.UNSIGNED_SHORT, 0);
        }
    }
}
