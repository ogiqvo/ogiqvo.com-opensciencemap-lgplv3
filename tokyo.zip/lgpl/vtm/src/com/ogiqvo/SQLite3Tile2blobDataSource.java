package com.ogiqvo;

import org.oscim.layers.tile.MapTileJob;
import org.oscim.tiling.ITileDataLoadCallbackable;
import org.oscim.tiling.ITileDataSource;
import org.oscim.tiling.source.oscimap4.TileDecoder;

import java.io.IOException;
import java.io.InputStream;

import static org.oscim.tiling.ITileDataLoadCallbackable.QueryResult.SUCCESS;

/**
 * Created by xor on 15/11/30.
 */
public class SQLite3Tile2blobDataSource implements ITileDataSource {
    ISQLite3Tile2blobHandler handler;
    TileDecoder tileDecoder;

    public SQLite3Tile2blobDataSource(ISQLite3Tile2blobHandler handler, TileDecoder tileDecoder) {
        this.handler = handler;
        this.tileDecoder = tileDecoder;
    }

    @Override
    public void queryTileJobOnLoadingThread(MapTileJob tileJob, ITileDataLoadCallbackable sink) {
        InputStream is = this.handler.inputStreamForTile(tileJob);
        try {
            if (tileDecoder.decodeOnLoadingThread(tileJob, sink, is)) {
                sink.notifyToLoaderThatLoadingIsCompleteOnLoadingThread(SUCCESS);
                return;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void dispose() {

    }

    @Override
    public void cancel() {

    }
}
