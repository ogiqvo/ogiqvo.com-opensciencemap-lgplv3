package com.ogiqvo;

import org.oscim.core.Cube;
import org.oscim.tiling.source.UrlTileSource;

/**
 * Created by xor on 15/05/06.
 */
public interface CubeUrlFormatter {
    String formatCubePath(UrlTileSource tileSource, Cube cube);
}
