package com.ogiqvo;

import org.oscim.core.Cube;
import org.oscim.tiling.ITileDataLoadCallbackable;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by xor on 15/05/06.
 */
public interface ICubeDecoder {

    boolean decode(Cube cube, ITileDataLoadCallbackable sink, InputStream is)
            throws IOException;
}
