package java.util.concurrent;

import java.util.ArrayList;

public class CopyOnWriteArrayList<E> extends ArrayList<E> {

	/**
     *
     */
	private static final long serialVersionUID = 1L;

}
