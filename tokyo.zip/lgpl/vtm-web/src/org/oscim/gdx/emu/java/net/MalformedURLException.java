package java.net;

public class MalformedURLException extends Exception {

	/**
     *
     */
	private static final long serialVersionUID = 1L;

}
