package java.util.concurrent;

public class CancellationException extends IllegalStateException {

	/**
	 *
	 */
    private static final long serialVersionUID = 1L;

}
