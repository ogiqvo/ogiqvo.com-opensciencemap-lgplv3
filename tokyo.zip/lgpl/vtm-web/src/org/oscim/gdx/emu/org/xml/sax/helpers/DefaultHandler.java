package org.xml.sax.helpers;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class DefaultHandler {
	public void endDocument() {

	}

	public void error(SAXParseException exception) {

	}

	public void warning(SAXParseException exception) {

	}

	public void startElement(String uri, String localName, String qName,
	        Attributes attributes) throws SAXException {

	}

	public void endElement(String uri, String localName, String qName) {

	}

}
