package org.oscim.ios.backend;

import com.badlogic.gdx.backends.iosrobovm.IOSGLES20;

import org.oscim.backend.GL20;

public class IosGLAdapter extends IOSGLES20 implements GL20 {

}
